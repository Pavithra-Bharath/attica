<?php
session_start();
include("dbConnection.php");
$id=$_GET['id'];
$status='Approved';
$afterpurity = $_POST['afterpurity'];
$purityloss = $_POST['purityloss'];
$sql="update melting set afterpurity='$afterpurity',purityloss = '$purityloss' where id='$id'";
$res=mysqli_query($con,$sql);
echo "<script>alert('Purity Updated Successfully'); window.location.href='melting.php';</script>";
?>