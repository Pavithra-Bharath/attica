<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
			<li><a href="zmnv.php"><i style="color:#990000" class="fa fa-users"></i> VM's Branch</a></li>
			<li><a href="zviewvm.php"><i style="color:#990000" class="fa fa-user-circle-o"></i> View VMs</a></li>
			<li><a href="zvmdateview.php"><i style="color:#990000" class="fa fa-clock-o"></i> VMs Log</a></li>
			<!--<li><a href="zvmadd.php"><i style="color:#990000" class="fa fa-users"></i> Add VM's</a></li>-->
			<li><a href="logout.php"><span class="nav-label"><span style="color:#990000" class="fa fa-sign-out"></span> Logout</span></a></li>
		</ul>
	</div>
</aside>