<?php 
	
	session_start();
	error_reporting(E_ERROR | E_PARSE);	
	include("dbConnection.php");
	
	if(isset($_POST['transDownload'])){
		
		$from = $_POST['from'];
		$to = $_POST['to'];
		
		$data = "";
		
		$data .= 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";';
		$data .= "\n";
		$data .= 'START TRANSACTION;';
		$data .= "\n";
		$data .= 'SET time_zone = "+00:00";';
		$data .= "\n\n";
		
		$sql = mysqli_query($con, "SELECT customerId, billId, name, phone, billCount, releases, ple, grossW, netW, netA, grossA, amountPaid, rate, date, time, branchId, type, comm, margin, purity, price, status, metal, sta, staDate, flag, kyc, ophoto, remarks, paymentType, cashA, impsA, releaseID, relDate, packetNo 
		FROM trans
		WHERE date BETWEEN '$from' AND '$to'");
		$count = mysqli_num_rows($sql);	
		for($i = 0; $i < $count; $i++){
			$row = mysqli_fetch_assoc($sql);
			if($i % 100 == 0){
				$data .= "INSERT INTO trans (customerId, billId, name, phone, billCount, releases, ple, grossW, netW, netA, grossA, amountPaid, rate, date, time, branchId, type, comm, margin, purity, price, status, metal, sta, staDate, flag, kyc, ophoto, remarks, paymentType, cashA, impsA, releaseID, relDate, packetNo) VALUES";
			}
			
			$data .= "('$row[customerId]', '$row[billId]', '$row[name]', '$row[phone]', '$row[billCount]', '$row[releases]', '$row[ple]', '$row[grossW]', '$row[netW]', '$row[netA]', '$row[grossA]', '$row[amountPaid]', '$row[rate]', '$row[date]', '$row[time]', '$row[branchId]', '$row[type]', '$row[comm]', '$row[margin]', '$row[purity]', '$row[price]', '$row[status]', '$row[metal]', '$row[sta]', '$row[staDate]', '$row[flag]', '$row[kyc]', '$row[ophoto]', '$row[remarks]', '$row[paymentType]', '$row[cashA]', '$row[impsA]', '$row[releaseID]', '$row[relDate]', '$row[packetNo]')";
			if(($i + 1) == $count || (($i + 1) % 100) == 0){
				$data .= ";";
			}
			else{
				$data .= ",";
			}	
			
			$data .= "\n";
		}
		
		$data .= "COMMIT;";
		
		$filename = $from."_to_".$to."_trans.sql";
		header('Content-Type: application/octet-stream');
		header("Content-Transfer-Encoding: Binary"); 
		header("Content-disposition: attachment; filename=\"".$filename."\"");
		echo $data; 
		exit;
		
	}
	else if(isset($_POST['walkinDownload'])){
		
		$from = $_POST['from'];
		$to = $_POST['to'];
		
		$data = "";
		
		$data .= 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";';
		$data .= "\n";
		$data .= 'START TRANSACTION;';
		$data .= "\n";
		$data .= 'SET time_zone = "+00:00";';
		$data .= "\n\n";
		
		$branch_remark = '';
		$zonal_remark = '';
		$csr_remark = '';
		
		$sql = mysqli_query($con, "SELECT name, mobile, gold, havingG, metal, issue, gwt, purity, ramt, branchId, agent_id, followUp, comment, remarks, zonal_remarks, status, emp_type, date, indate, time, quotation
		FROM walkin
		WHERE date BETWEEN '$from' AND '$to'");
		$count = mysqli_num_rows($sql);	
		for($i = 0; $i < $count; $i++){
			$row = mysqli_fetch_assoc($sql);
			if($i % 100 == 0){
				$data .= "INSERT INTO walkin (name, mobile, gold, havingG, metal, issue, gwt, purity, ramt, branchId, agent_id, followUp, comment, remarks, zonal_remarks, status, emp_type, date, indate, time, quotation) VALUES";
			}
			
			$branch_remark = addslashes($row['comment']);
			$zonal_remark = addslashes($row['zonal_remarks']);
			$csr_remark = addslashes($row['remarks']);
			
			$data .= "('$row[name]', '$row[mobile]', '$row[gold]', '$row[havingG]', '$row[metal]', '$row[issue]', '$row[gwt]', '$row[purity]', '$row[ramt]', '$row[branchId]', '$row[agent_id]', '$row[followUp]', '$branch_remark', '$csr_remark', '$zonal_remark', '$row[status]', '$row[emp_type]', '$row[date]', '$row[indate]', '$row[time]', '$row[quotation]')";
			if(($i + 1) == $count || (($i + 1) % 100) == 0){
				$data .= ";";
			}
			else{
				$data .= ",";
			}
			
			$data .= "\n";
		}
		
		$data .= "COMMIT;";
		
		$filename = $from."_to_".$to."_walkin.sql";
		header('Content-Type: application/octet-stream');
		header("Content-Transfer-Encoding: Binary"); 
		header("Content-disposition: attachment; filename=\"".$filename."\"");
		echo $data; 
		exit;
		
	}
	else{
		$data = "Virus is alive";
		
		$filename = "error.txt";
		header('Content-Type: application/octet-stream');
		header("Content-Transfer-Encoding: Binary"); 
		header("Content-disposition: attachment; filename=\"".$filename."\"");
		echo $data; 
		exit;
	}
?>