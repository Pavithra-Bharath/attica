<?php
	error_reporting(E_ERROR | E_PARSE);
    session_start();
    $type=$_SESSION['usertype'];
    if($type=='Zonal'){
        include("header.php");
        include("menuZonal.php");
	}
    else{
        include("logout.php");
	}
?>
<style>
	#wrapper{
		background: #f5f5f5;
	}	
	#wrapper h3{
		text-transform:uppercase;
		font-weight:600;
		font-size: 20px;
		color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
		background-color:#fffafa;
	}
	.text-success{
		color:#123C69;
		text-transform:uppercase;
		font-weight:bold;
		font-size: 12px;
	}
	.btn-primary{
		background-color:#123C69;
	}
	.theadRow {
		text-transform:uppercase;
		background-color:#123C69!important;
		color: #f2f2f2;
		font-size:11px;
	}	
	.dataTables_empty{
		text-align:center;
		font-weight:600;
		font-size:12px;
		text-transform:uppercase;
	}
	.btn-success{
		display:inline-block;
		padding:0.7em 1.4em;
		margin:0 0.3em 0.3em 0;
		border-radius:0.15em;
		box-sizing: border-box;
		text-decoration:none;
		font-size: 11px;
		font-family:'Roboto',sans-serif;
		text-transform:uppercase;
		color:#fffafa;
		background-color:#123C69;
		box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
		text-align:center;
		position:relative;
	}
	.fa_Icon {
		color:#ffcf40;
	}
	fieldset {
		margin-top: 1.5rem;
		margin-bottom: 1.5rem;
		border: none;
		border: 5px solid #fff;
		border-radius: 10px;
		padding: 5px;
		box-shadow: rgb(50 50 93 / 25%) 0px 50px 100px -20px, rgb(0 0 0 / 30%) 0px 30px 60px -30px, rgb(10 37 64 / 35%) 0px -2px 6px 0px inset;
		background-color:#f5f5f5;
	}
	legend{
		margin-left:8px;
		width:310px;
		background-color: #123C69;
		padding: 5px 15px;
		line-height:30px;
		font-size: 18px;
		color: white;
		text-shadow: 1px 1px 1px rgba(0,0,0,0.5);
		transform: translateX(-1.1rem);
		box-shadow: -1px 1px 1px rgba(0,0,0,0.8);
		margin-bottom:0px;
		letter-spacing: 2px;
	}
	button {
	  transform: none;
	  box-shadow: none;
	}

	button:hover {
	  background-color: gray;
	  cursor: pointer;
	}

	legend:after {
		content: "";
		height: 0;
		width:0;
		background-color: transparent;
		border-top: 0.0rem solid transparent;
		border-right:  0.35rem solid black;
		border-bottom: 0.45rem solid transparent;
		border-left: 0.0rem solid transparent;
		position:absolute;
		left:-0.075rem;
		bottom: -0.45rem;
	}
</style>
<!-- DATA LIST - BRANCH LIST -->
<datalist id="branchList"> 
	<?php
		$branches = mysqli_query($con,"SELECT branchId,branchName FROM branch where status=1");
        while($branchList = mysqli_fetch_array($branches)){
		?>
		<option value="<?php echo $branchList['branchId']; ?>" label="<?php echo $branchList['branchName']; ?>"></option>
	<?php } ?>
</datalist>
<!-- DATA LIST - EMPLOYEE LIST -->
<datalist id="bm">
	<?php 
		$emp = mysqli_query($con,"SELECT * FROM employee");
        while($empList = mysqli_fetch_array($emp)){
		?>
		<option value="<?php echo $empList['name']; ?>" label="<?php echo $empList['empId']; ?>"></option>
	<?php } ?>
</datalist>
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<fieldset>
				<legend><i style="padding-top:15px" class="fa_Icon fa fa-info-circle"></i> ADD NEW NOTIFICATION </legend>
				<div class="panel-body" style="background-color:#f5f5f5;box-shadow:10px 15px 15px #999;">
					<form method="POST" class="form-horizontal" action="add.php">
						<div class="form-group">
							<div class="col-sm-3">
								<label class="text-success">Branch Id</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-institution"></span></span>
									<input list="branchList" class="form-control" name="bran" id="bran" placeholder="Branch Id" />  
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">BM</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
									<input list="bm" class="form-control" name="bm" placeholder="Select BM" />								
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">Loss</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-caret-square-o-down"></span></span>
									<select class="form-control" style="padding:0px 8px" name="loss" id="loss">
										<option>Select Loss</option>
										<option>Individual</option>
										<option>Overall</option>
									</select>
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">Loss Date</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-calendar"></span></span>
									<input type="date" class="form-control" name="date" id="date" placeholder="Loss Date">
								</div>
							</div>
							<label class="col-sm-12"><br></label>
							<div class="col-sm-3">
								<label class="text-success">Gross Weight</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-balance-scale"></span></span>
									<input type="text" class="form-control" name="grossW" id="grossW" placeholder="Gross Weight">
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">Given Purity</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
									<input type="text" class="form-control" name="givenpurity" id="givenpurity" placeholder="Given Purity">
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">Actual Purity</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
									<input type="text" class="form-control"  name="actualpurity" id="actualpurity" placeholder="Actual Purity">
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">Stone Loss</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-diamond"></span></span>
									<input type="text" class="form-control"  name="stoneloss" id="stoneloss" placeholder="Stone Loss">
								</div>
							</div>
							<label class="col-sm-12"><br></label>
							<div class="col-sm-3">
								<label class="text-success">Purity Loss</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
									<input type="text" class="form-control"  name="purityloss" id="purityloss" placeholder="Purity Loss">
								</div>
							</div>
							<div class="col-sm-7">
								<label class="text-success">Remarks</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-edit"></span></span>
									<input type="text" class="form-control" name="noti" id="noti" placeholder="Remarks" >
								</div>
							</div>
							<div class="col-sm-2" align="right">
								<button class="btn btn-success" name="submitPurity" id="submitPurity" type="submit" style="margin-top:23px"><span style="color:#ffcf40" class="fa fa-plus"></span> Add Notification</button>
							</div>
						</div>
					</form>
					</div>
				</fieldset>
			</div>
		</div>
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-body" style="border: 5px solid #fff;border-radius: 10px;box-shadow: rgb(50 50 93 / 25%) 0px 50px 100px -20px, rgb(0 0 0 / 30%) 0px 30px 60px -30px, rgb(10 37 64 / 35%) 0px -2px 6px 0px inset;">
					<div class="form-group">
						<table id="example5" class="table table-striped table-bordered table-hover">
							<thead>
								<tr class="theadRow">
									<th>SNo</th>
									<th>BM</th>
									<th>Branch</th>
									<th>Gross Weight</th>
									<th>Given Purity</th>
									<th>Actual Purity</th>
									<th>Stone Loss</th>
									<th>Purity Loss</th>
									<th>Loss Date</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$i = 1;
									$query = mysqli_query($con,"SELECT purity.*,branch.branchName FROM purity,branch WHERE purity.branchId=branch.branchId");
									while($row = mysqli_fetch_assoc($query)){
										echo "<tr>";
										echo "<td>" . $i .  "</td>";
										echo "<td>" . $row['bm'] ."</td>";
										echo "<td>" . $row['branchName'] . "</td>";
										echo "<td>" . $row['grossW'] ."</td>";
										echo "<td>" . $row['givenpurity'] ."</td>";
										echo "<td>" . $row['actualpurity'] ."</td>";
										echo "<td>" . $row['stoneloss'] ."</td>";
										echo "<td>" . $row['purityloss'] ."</td>";
										echo "<td>" . $row['lossdate'] ."</td></tr>";
										echo "</tr>";
										$i++;
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div style="clear:both"></div>
	</div>
<?php include("footer.php"); ?>