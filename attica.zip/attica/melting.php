<?php
	session_start();
	$type=$_SESSION['usertype'];
	if($type=='Branch')
	{
		include("logout.php");
	}
	else
	{
		include("header.php");
		if($type=='Master')
		{
		    include("menumaster.php");
		}
		else if($type=='Admin')
		{
		    include("menuadmin.php");
		}
		else if($type=='Accounts')
		{
	        include("menuacc.php");
		}
		else if($type=='AccHead')
	    {
	        include("menuaccHeadPage.php");
	    }
		else if($type=='ApprovalTeam')
		{
	        include("menuapproval.php");
		}
		else if($type=='Zonal')
		{
            include("menuZonal.php");
		}
		include("dbConnection.php");
	}
	$date=date('Y-m-d');
	$prev_date=date('Y-m-d',strtotime("-1 days"));
?>
<style>
	#wrapper{
		background: #f5f5f5;
	}	
	#wrapper h3{
		text-transform:uppercase;
		font-weight:600;
		font-size: 20px;
		color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
		background-color:#fffafa;
	}
	.text-success{
		color:#123C69;
		text-transform:uppercase;
		font-weight:bold;
		font-size: 12px;
	}
	.btn-primary{
		background-color:#123C69;
	}
	.theadRow {
		text-transform:uppercase;
		background-color:#123C69!important;
		color: #f2f2f2;
		font-size:10px;
	}	
	.dataTables_empty{
		text-align:center;
		font-weight:600;
		font-size:12px;
		text-transform:uppercase;
	}
	.btn-success{
		display:inline-block;
		padding:0.7em 1.4em;
		margin:0 0.3em 0.3em 0;
		border-radius:0.15em;
		box-sizing: border-box;
		text-decoration:none;
		font-size: 11px;
		font-family:'Roboto',sans-serif;
		text-transform:uppercase;
		color:#fffafa;
		background-color:#123C69;
		box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
		text-align:center;
		position:relative;
	}
	.fa_Icon {
		color:#b8860b;
	}
	.row{
	    margin-left:0px;
	    margin-right:0px;
	}
</style>
<div id="wrapper">
	<div class="content">
		<div class="hpanel">
			<div class="panel-heading">
                <h3 class="text-success"><i style="color:#990000" class="fa fa-info-circle"></i> MELTING DETAILS</h3>
			</div>
			<div class="panel-body">
                <form method="POST" class="form-horizontal" action="add.php">
					<div class="form-group">
						<div class="col-lg-12">
							<div class="col-sm-2">
								<label class="text-success">Branch</label>
								<div class="input-group"><span class="input-group-addon"><span style="color:#990000" class="fa fa-institution"></span></span>
									<input list="cusId" class="form-control" name="bran" id="bran" required placeholder="Branch Id" />  
								</div>
							</div>
							<datalist id="cusId">
								<option value="All Branches">All Branches</option>
								<?php 
									$sql="select * from branch";
									$res=mysqli_query($con,$sql);
									while($row = mysqli_fetch_array($res))
									{
										$branch=$row['branchId'];
										$sql="select branchName from branch where branchId='$branch'";
									?>
									<option value="<?php echo $row['branchId']; ?>">
									<?php echo $row['branchName']; ?></option>
								<?php } ?>
							</datalist>
							<div class="col-sm-2" hidden><label class="text-success">BM</label>
								<div class="input-group">
									<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
									<input list="bm" class="form-control" name="bm" placeholder="Select BM" />
									<datalist id="bm">
										<?php 
											$sql1="select * from employee";
											$res1=mysqli_query($con,$sql1);
											while($row1 = mysqli_fetch_array($res1))
											{
												$empId=$row1['empId'];
												$sql1="select name from employee where empId='$empId'";
											?>
											<option value="<?php echo $row1['empId']; ?>"><?php echo $row1['name']; ?></option>
										<?php } ?>
									</datalist>
								</div></div>
								<div class="col-sm-2"><label class="text-success">Gold Send Date</label>
									<div class="input-group">
										<span class="input-group-addon"><span style="color:#990000" class="fa fa-signal"></span></span>
									<input type="text" class="form-control" name="gdate" id="gdate" required placeholder="Gold Send Date" value="<?php echo $prev_date; ?>"></div>
								</div>
								<div class="col-sm-2"><label class="text-success">Gross Weight</label>
									<div class="input-group">
										<span class="input-group-addon"><span style="color:#990000" class="fa fa-balance-scale"></span></span>
									<input type="text" class="form-control" name="grosswt" id="grosswt" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required placeholder="Gross Weight"></div>
								</div>
								<div class="col-sm-2"><label class="text-success">Branch Net Weight</label>
									<div class="input-group">
										<span class="input-group-addon"><span style="color:#990000" class="fa fa-balance-scale"></span></span>
									<input type="text" class="form-control" name="bnw" id="bnw" required placeholder="Branch Net Wt"></div></div>
									<div class="col-sm-2"><label class="text-success">After Stone</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
										<input type="text" class="form-control" name="afterstone" required id="afterstone" placeholder="After Stone"></div>
									</div>
									<div class="col-sm-2"><label class="text-success">Difference</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
										<input type="text" class="form-control" required name="diff" id="diff" placeholder="Difference"></div>
									</div>
									<label class="col-sm-12"><br></label>
									<div class="col-sm-2"><label class="text-success">Gatti Weight</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-file"></span></span>
										<input type="text" class="form-control" required name="gwt" id="gwt" placeholder="Gatti Weight"></div>
									</div>
									<div class="col-sm-2"><label class="text-success">Melting Loss</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-diamond"></span></span>
										<input type="text" class="form-control" required name="meltwt" id="meltwt" placeholder="Melting Loss"></div>
									</div>
									<div class="col-sm-2"><label class="text-success">Branch Purity</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
										<input type="text" class="form-control" required name="branchpurity" id="branchpurity" placeholder="Branch Purity"></div>
									</div>
									<div class="col-sm-2"><label class="text-success">After Purity</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
										<input type="text" class="form-control"  name="afterpurity" id="afterpurity" placeholder="After Purity"></div>
									</div>
									<div class="col-sm-2"><label class="text-success">Purity Loss</label>
										<div class="input-group">
											<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
										<input type="text" class="form-control"  name="purityloss" id="purityloss" placeholder="Purity Loss"></div>
									</div>
									<div class="col-sm-2" align="left"><label>________________</label><br>
										<button class="btn btn-success" name="melting" id="melting" type="submit" ><span style="color:#ffcf40" class="fa fa-check"></span> Submit</button>
									</div>
						</div>
					</div>
				</form>
			</div><div style="clear:both"></div>
		</div>
		<div class="hpanel">
			<div class="panel-body">
				<div class="col-lg-12">
                    <div class="table-responsive">
						<table id="example2" class="table table-striped table-bordered table-hover">
							<thead>
								<tr class="theadRow">
									<th>SNo</th>
									<!--th>BM</th-->
									<th>Branch</th>
									<th>Gold Send Date</th>
									<th>Gross Weight</th>
									<th>Branch Net Weight</th>
									<th>After Stone</th>
									<th>Difference</th>
									<th>Gatti Weight</th>
									<th>Melting Weight</th>
									<th>Branch Purity</th>
									<th>Melting Purity</th>
									<th>Purity Margin</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$query=mysqli_query($con,"SELECT * FROM melting where date in ('".$prev_date."','".$date."') || afterpurity = ''");
									$count=mysqli_num_rows($query);
									for($i=1;$i<=$count;$i++)
									{
										if($count>0)
										{
											$row=mysqli_fetch_array($query);
											$branch=$row['branch'];
											$sql="select branchName from branch where branchId='$branch'";
											$res=mysqli_query($con,$sql);
											$row1=mysqli_fetch_array($res);
											$empid=$row['empid'];
											$sql1="select name from employee where empId='$empid'";
											$res1=mysqli_query($con,$sql1);
											$row2=mysqli_fetch_array($res1);
											echo "<tr><td>" . $i .  "</td>";
											//echo "<td>" . $row2['name'] ."</td>";
											echo "<td>" . $row1['branchName'] . "</td>";
											echo "<td>" . $row['gdate'] ."</td>";
											echo "<td>" . $row['grosswt'] ."</td>";
											echo "<td>" . $row['branchnetwt'] ."</td>";
											echo "<td>" . $row['afterstone'] ."</td>";
											if($row['difference'] < 0)
											{
												echo "<td style='color:#f00;font-weight:bold;'>" . $row['difference'] ."</td>";
											}
											else
											{
												echo "<td>" . $row['difference'] ."</td>";
											}
											echo "<td>" . $row['gattiwt'] ."</td>";
											if($row['meltingwt'] < 0)
											{
												echo "<td style='color:#f00;font-weight:bold;'>" . $row['meltingwt'] ."</td>";
											}
											else
											{
												echo "<td>" . $row['meltingwt'] ."</td>";
											}
											echo "<td>" . $row['branchpurity'] ."</td>";
											if($row['afterpurity'] == '' && $row['purityloss'] == '')
											{
												echo "<td><form method='post' action='updatemelting.php?id=".$row['id']."'><div class='input-group'>
												<input type='text' class='form-control' name='afterpurity' id='afterpurity' placeholder='After Purity'></td>
												<td><input type='text' class='form-control' name='purityloss' id='purityloss' placeholder='Purity Loss' style='width: 90px;'>
												<button type='submit' class='btn btn-success btn-small'><span style='color:#ffcf40' class='fa fa-check'></span></button></div></form></td></tr>";
											}
											else
											{
												echo "<td>" . $row['afterpurity'] ."</td>";
												if($row['purityloss'] < 0)
												{
													echo "<td style='color:#f00;font-weight:bold;'>" . $row['purityloss'] ."</td></tr>";
												}
												else
												{
													echo "<td>" . $row['purityloss'] ."</td></tr>";
												}
											}
										}
									}
								?>
							</tbody>				
						</table>
					</div>
				</div>
			</div>  
			<?php include("footer.php");?>
			<div style="clear:both"></div>
		</div>		