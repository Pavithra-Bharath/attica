<?php
session_start();
	  $type=$_SESSION['usertype'];
	include("header.php");
	   include("menuhr.php");
	
	   include("dbConnection.php");
	   $date=date('Y/m/d');
if(isset($_GET['delete']))
{
$multiple=$_GET['multiple'];
$i=0;
$sql="DELETE FROM customer";
foreach($multiple as $item_id){
$i ++;
if($i ==1 )
{
$sql .=" WHERE id = " . mysqli_real_escape_string($con,$item_id) . "";
}
else{
$sql .=" OR id = " . mysqli_real_escape_string($con,$item_id) . "";
}
}
mysqli_query($con,$sql) or die (mysqli_connect_errno());
}
?>
<div id="wrapper">
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-heading" >
                    <h4><i class="fa fa-users"></i> View Employee Details <a class="btn btn-success btn-md" href="addEmployee.php"><span class="fa fa-user-plus"></span>  Add New Employee</a></h4>
                </div>
                <div class="panel-body" style="overflow:hidden">
				<form id="frm1" action=""  method="GET" onSubmit="return validate();"> 
                <table id="example2" class="table table-striped table-bordered table-hover">
                <thead>
                <tr>
                    <th><i class="fa fa-sort-numeric-asc"></i></th>
					<th>Emp_ID</th>
                    <th>Name</th>
					<th>Contact</th>
                    <th>designation</th>
					<th>Edit</th>
                </tr>
                </thead>
                <tbody>
                <?php
					$query=mysqli_query($con,"SELECT * FROM employee order by id DESC;");
					   $count=mysqli_num_rows($query);
					    for($i=1;$i<=$count;$i++)
											{
										if($count>0)
										{
											$row=mysqli_fetch_array($query);
												echo "<tr><td>" . $i .  "</td>";
												echo "<td>" . $row['empId'] . "</td>";
												echo "<td>" . $row['name'] . "</td>";
												//echo "<td>" . $row['supplierId'] .  "</td>";
												echo "<td>" . $row['contact'] . "</td>";
												echo "<td>" . $row['designation'] . "</td>";
												echo "<td><a class='btn btn-primary' href='addEmployee.php?empId=".$row['id']."'><i class='fa fa-edit'></i> Edit</a></td></tr>";
											}
										}
					 ?>
                </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    </div>
  <div style="clear:both"></div>
<?php
include("footer.php");
?>