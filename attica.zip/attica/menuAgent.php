<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">         			
			<li><a href="sms.php"><span class="nav-label"><span style="color:#990000" class="fa fa-comments"></span> SMS</span></a></li>
			<li><a href="logout.php"><span class="nav-label"><span style="color:#990000" class="fa fa-sign-out"></span> Logout</span></a></li>
        </ul>
    </div>
</aside>