		<footer class="footer">
			<b><span style="color:#990000" class="pull-right">
			ISO 9001:2015 Certified Company</span>
			<span style="color:#990000" class="pull-left">
			Attica Gold Pvt Ltd</span></b>
		</footer>
	</div> 


	<!-- Vendor scripts -->
	<script src="vendor/jquery/dist/jquery.min.js"></script>
	<script src="vendor/jquery-ui/jquery-ui.min.js"></script>
	<script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
	<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
	<script src="vendor/iCheck/icheck.min.js"></script>
	<script src="vendor/sparkline/index.js"></script>
	<script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

	<!-- DataTables buttons scripts -->
	<script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
	<script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>

	<script src="scripts/homer.js"></script>
	<script src="scripts/states.js"></script>
	<script src="vendor/clockpicker/dist/bootstrap-clockpicker.min.js"></script>
	<script src="vendor/summernote/dist/summernote.min.js"></script>

	<!-- New scripts  -->
	<script src="vendor/inputmask/js/jquery.inputmask.bundle.js"></script>
	<script src="vendor/select2-3.5.2/select2.min.js"></script>
	<script src="scripts/attic.js" type="text/javascript"></script>
	<script type="text/javascript" src="scripts/demo.js"></script>
	
	</body>
</html>					