<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
date_default_timezone_set('Asia/Calcutta');

$type = $_SESSION['usertype'];
if ($type == 'Master') {
    include("header.php");
    include("menumaster.php");
} elseif ($type == 'Zonal') {
    include("header.php");
    include("menuZonal.php");
}else {
    include("logout.php");
}

include("dbConnection.php");


?>
<style>
	#results img{
		width:100px;
	}
	#wrapper{
		background: #f5f5f5;
	}
	
	#wrapper h3{
		text-transform:uppercase;
		font-weight:600;
		font-size: 20px;
		color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
		background-color:#fffafa;
	}
	.quotation h3{
		color:#123C69;
		font-size: 18px!important;
	}
	.text-success{
		color:#123C69;
		text-transform:uppercase;
		font-weight:bold;
		font-size: 12px;
	}
	.btn-primary{
		background-color:#123C69;
	}
	.btn-info{
		background-color:#123C69;
		border-color:#123C69;
		font-size:12px;
	}	
	.btn-info:hover, .btn-info:focus, .btn-info:active, .btn-info.active{
		background-color:#123C69;
		border-color:#123C69;
	}
	.fa_Icon{
		color:#ffa500;
	}
	thead {
		text-transform:uppercase;
		background-color:#123C69;

	}
	thead tr{
		color: #f2f2f2;
		font-size:12px;
	}
	
	.dataTables_empty{
		text-align:center;
		font-weight:600;
		font-size:12px;
		text-transform:uppercase;
	}

	.btn-success{
		display:inline-block;
		padding:0.7em 1.4em;
		margin:0 0.3em 0.3em 0;
		border-radius:0.15em;
		box-sizing: border-box;
		text-decoration:none;
		font-size: 12px;
		font-family:'Roboto',sans-serif;
		text-transform:uppercase;
		color:#fffafa;
		background-color:#123C69;
		box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
		text-align:center;
		position:relative;
	}

	.modaldesign {
		float: right;
		cursor: pointer;
		padding: 5px;
		background:none;
		color: #f0f8ff;
		border-radius: 5px;
		margin: 15px;
		font-size: 20px;
	}
	#available{
		text-transform:uppercase;
	}
</style>

<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<h3 class="text-success"> <i style="color:#990000" class="fa fa-ticket"></i> PLEDGE FUND All Data</h3>
				</div>
				<div class="panel-body" style="box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;border-radius:10px;">
					<form method="POST" class="form-horizontal" action="">
						
			<div class="hpanel">
				<div class="panel-body" style="box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;border-radius:10px;">
					<table id="example5" class="table table-striped table-bordered table-hover">
						<thead>
                            <tr>
                                <th>#</th>
								<th>Bill Number</th>
                                <!-- <th>Invoice Number</th> -->
                                <th>Customer name</th>
                                <th>Contact</th>
                                <th>Amount</th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Date</th>
                                <th>Time</th>
                            </tr>
                        </thead>
						<tbody>
						<?php
						if (isset($_GET['billId'])) {
							// Fetch the specific row data based on the selected ID
							$selectedId = $_GET['billId'];
							$result = mysqli_query($con, "SELECT * FROM pledge_fund WHERE billId = $selectedId");
							$numrow = mysqli_num_rows($result);

							if ($numrow > 0) {
								$res = mysqli_fetch_array($result);
								echo "<tr>";
								echo "<td>1</td>"; // Assuming you want to start counting from 1 for searched data
								echo "<td>" . $res['billId'] . "</td>";
								echo "<td>" . $res['name'] . "</td>";
								echo "<td>" . $res['contact'] . "</td>";
								echo "<td>" . $res['amount'] . "</td>";
								echo "<td>" . $res['empId'] . "</td>";
								echo "<td>" . $res['empName'] . "</td>";
								echo "<td>" . $res['date'] . "</td>";
								echo "<td>" . $res['time'] . "</td>";
								echo "</tr>";
							} else {
								echo "No data found for the selected ID.";
							}
						} else {
							// Fetch all fund data
							$result = mysqli_query($con, "SELECT * FROM pledge_fund ORDER BY date DESC, time DESC");
							$i = 1; // Initialize $i for counting
							
							while ($res = mysqli_fetch_array($result)) {
								echo "<tr>";
								echo "<td>$i</td>";
								echo "<td>" . $res['billId'] . "</td>";
								echo "<td>" . $res['name'] . "</td>";
								echo "<td>" . $res['contact'] . "</td>";
								echo "<td>" . $res['amount'] . "</td>";
								echo "<td>" . $res['empId'] . "</td>";
								echo "<td>" . $res['empName'] . "</td>";
								echo "<td>" . $res['date'] . "</td>";
								echo "<td>" . $res['time'] . "</td>";
								echo "</tr>";
								$i++;
							}
						}
						?>
                        </tbody>
					</table>
				</div>
			</div>

		</div>
		<div style="clear:both"></div>
	</div>
	<?php include("footer.php"); ?>



	