<?php
	
	define('QRCodeURL',"https://atticagold.in/");