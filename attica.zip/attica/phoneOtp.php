<?php
session_start();
include("dbConnection.php");
	$phone=$_POST['data'];
	$sql1="select * from customer where mobile='$phone'";
	$res1=mysqli_query($con,$sql1);
	$row=mysqli_fetch_array($res1);
	$name=$row['name'];
	$otp = rand(100000,999999);
	date_default_timezone_set("Asia/Kolkata");
$time=date("H:i:s");
$date=date('Y-m-d');
if($phone<9999999999 && $phone>6000000000)
{
	$sql="insert into otp(customerName,mobile,otp,date,time,message,flag,employee_id)values('$name','$phone','$otp','$date','$time','Transaction',0,'')";
	$res=mysqli_query($con,$sql);
	$message ="Dear ".$name. ", your mobile verification OTP for new transaction  is ".$otp;
	
	$url="http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac1114feab4e31bdfaef1f02d3d3c23e7&to=".$phone."&sender=ATTICA&message=".$message;
	
// 	$url ="http://103.255.217.28:15181/BULK_API/SendMessage?loginID=attica_siht1&password=attica@123&mobile=".$phone."&text=".$message."&senderid=ATTICA&DLT_TM_ID=1001096933494158&DLT_CT_ID=&DLT_PE_ID=1201159127344394306&route_id=DLT_SERVICE_IMPLICT&Unicode=0&camp_name=attica_se";
// 	$url1 = str_replace(" ",'%20', $url);
	
	$_SESSION['otp2']=$otp;
	$_SESSION['mobile']=$phone;
	$_SESSION['cus']=$name;
	$ch = curl_init();
curl_setopt_array($ch, array(
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_POST => true
//CURLOPT_POSTFIELDS => $postData
//,CURLOPT_FOLLOWLOCATION => true
));
//Ignore SSL certificate verification
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//get response
$output = curl_exec($ch);
//Print error if any
if(curl_errno($ch))
{
echo 'error:' . curl_error($ch);
}
curl_close($ch);
}
?>