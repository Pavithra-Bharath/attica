<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
date_default_timezone_set('Asia/Calcutta');
$type = $_SESSION['usertype'];
if($type == 'Master'){
	include("header.php");
	include("menumaster.php");
} elseif ($type == 'Zonal'){
	include("header.php");
	include("menuZonal.php");

}else {
    include("logout.php");
}

include("dbConnection.php");

$branch = $_SESSION['branchCode'];
$branchId = $_SESSION['branchCode'];
$currentDate = date('Y-m-d');

if ($type == 'Zonal') {
    if ($branch == "KA") {
        $state = "AND r.branchId IN (SELECT branchId FROM branch WHERE state='Karnataka')";
    } elseif ($branch == "TN") {
        $state = "AND r.branchId IN (SELECT branchId FROM branch WHERE state IN ('Tamilnadu','Pondicherry'))";
    } elseif ($branch == "AP-TS") {
        $state = "AND r.branchId IN (SELECT branchId FROM branch WHERE state IN ('Telangana','Andhra Pradesh'))";
    }
} else {
    $state = "";
}

if (isset($_GET['start_date']) && isset($_GET['end_date']) || $type == "Zonal" || $type == 'Master') {
    // If 'KA' zonal and both start_date and end_date are set, include date range; otherwise, include current date
    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : $currentDate;
    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : $currentDate;

    $searchQuery = mysqli_query($con, "SELECT * FROM pledge_bill r WHERE date BETWEEN '$start_date' AND '$end_date' AND status='Billed' $state ORDER BY id DESC");

    if (!$searchQuery) {
        die("Error in query: " . mysqli_error($con));
    }
} else {
    // Handle other zonals or set default behavior
    $searchQuery = mysqli_query($con, "SELECT * FROM pledge_bill r WHERE date = '$currentDate' $state ORDER BY id DESC");
}
	
	


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pledge Bill</title>

</head>
<style> 
	.panel-heading input[type=text]{
		box-sizing: border-box;
		border: 2px solid #ccc;
		border-radius: 4px;
		font-size: 16px;
		background-color: white;
		/* background-image: url('images/searchicon.png'); */
		background-position: 220px 12px; 
		background-repeat: no-repeat;
		padding: 12px 50px 12px 15px;
		-webkit-transition: width 0.4s ease-in-out;
		transition: width 0.4s ease-in-out;
	}
	#search_branchId,#search_date{
		padding: 10px;
		height: 50px;
		font-size: 16px;
		color: grey;
		box-sizing: border-box;
		border: 2px solid #ccc!important;
	}
	#wrapper{
		background: #f5f5f5;
	}	
	#wrapper h3{
		text-transform:uppercase;
		font-weight:600;
		font-size: 18px;
		color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
		background-color:#fffafa;
	}	
	.text-success{
		color:#123C69;
		text-transform:uppercase;
		font-weight:bold;
		font-size: 12px;
	}
	.btn-primary{
		background-color:#123C69;
	}	
	
	.theadRow {
		text-transform:uppercase;
		background-color:#123C69!important;
		color: #f2f2f2;
		font-size:11px;
	}	
	.dataTables_empty{
		text-align:center;
		font-weight:600;
		font-size:12px;
		text-transform:uppercase;
	}
	.btn-success{
		display:inline-block;
		padding:0.7em 1.4em;
		margin:0 0.3em 0.3em 0;
		border-radius:0.15em;
		box-sizing: border-box;
		text-decoration:none;
		font-size: 12px;
		font-family:'Roboto',sans-serif;
		text-transform:uppercase;
		color:#fffafa;
		background-color:#123C69;
		box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
		text-align:center;
		position:relative;
	}
	.fa_Icon {
		color: #ffcf40;
	}
	.fa-Icon {
		color: #990000;
	}
	tbody{
	    font-weight: 600;
	}
	.modal-title {
		font-size: 20px;
		font-weight: 600;
		color:#708090;
		text-transform:uppercase;
	}	
	.modal-header{
		background: #123C69;
	}	
	#wrapper .panel-body{
		border: 5px solid #fff;
		border-radius: 10px;
		padding: 20px;
		box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;
		background-color: #f5f5f5;
		min-height: 300px;
	}	
	.preload{ 
		width:100px;
		height: 100px;
		position: fixed;
		top: 40%;
		left: 70%;
	}	
	.ajaxload{ 
		width:100px;
		height: 300px;
		position: fixed;
		top: 20%;
		left: 20%;
	}
	.buttons-csv,.btn-info{
	    font-size: 10px;
	}
	fieldset {
		margin-top: 1.5rem;
		margin-bottom: 1.5rem;
		border: none;
		box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;
		border-radius:5px;
	}
	legend{
		margin-left:8px;
		width:450px;
		background-color: #123C69;
		padding: 5px 15px;
		line-height:30px;
		font-size: 14px;
		color: white;
		text-shadow: 1px 1px 1px rgba(0,0,0,0.5);
		transform: translateX(-1.1rem);
		box-shadow: -1px 1px 1px rgba(0,0,0,0.8);
		margin-bottom:0px;
		letter-spacing: 2px;
	}
	.card {
		position: relative;
		display: flex;
		flex-direction: column;
		min-width: 0;
		word-wrap: break-word;
		background-color: #fff;
		background-clip: border-box;
		border: 0 solid rgba(0,0,0,.125);
		border-radius: .25rem;
		box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
	}
	.card-body {
		flex: 1 1 auto;
		min-height: 1px;
		padding: 1rem;
	}
	h4, h6{
		font-weight: bold;
	}
	.form-control{
		height:25px;
	}
	@media only screen and (max-width: 600px) {
		
		legend{

			width:295px;
			font-size: 10px;

		}	
	
	}
</style>
<body>
<datalist id="branchList"> 
    <?php 
        $branches = mysqli_query($con,"SELECT branchId,branchName FROM branch where status=1");
        while($branchList = mysqli_fetch_array($branches)){
		?>
		<option value="<?php echo $branchList['branchId']; ?>" label="<?php echo $branchList['branchName']; ?>"></option>
	<?php } ?>
</datalist>

    <div id="wrapper">
        <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hpanel">
                        <div class="panel-heading">
						<div class="col-lg-12">
                                    <div class="col-lg-7">
                                        <h3 class="text-success">
										<i class="fa fa-cubes" aria-hidden="true" style="font-size:20px;color:#990000;"></i> PLEDGE DETAILS &nbsp; 
										<?php
											if ($start_date == $end_date) {
												echo date("d-m-Y", strtotime($start_date));
											} else {
												echo "From " . date("d-m-Y", strtotime($start_date)) . " to " . date("d-m-Y", strtotime($end_date));
											}
		
										?>
										</h3>
										
								</div>
							<div class="col-lg-3">
									<div class="input-group" style="margin-left:150px;">
										<input type="hidden" name="newUser" id="newUser" value="addUser">
										<?php
											if ($type == 'Master' && $type !== 'Zonal') {
												// Show the button only when $type is 'Master' and not 'Zonal'
												echo '<span class="input-group-btn">
														<button onclick="clickButton()" class="btn btn-success btn-md" style="height: 50px; margin-left:100px;">+ADD NEW PLEDGE</button>
													</span>';
											}
										?>
									</div>
								</div>
                            <div class="row">
							<form action="" method="GET">
								


										<div class="col-lg-3">
											<div class="input-group"style="margin-left:80px;"><span class="input-group-addon"><span style="color:#990000" class="fa fa-calendar"></span></span>
												<input type="date" class="form-control" name="start_date" id="start_date"style="height:50px;">
												<span class="input-group-addon" style="border:none; background:none;">To</span>
												<input type="date" class="form-control" name="end_date" id="end_date" style="height:50px;">
												<span class="input-group-btn">
													<button onclick="searchByDateRange()" class="btn btn-success btn-md" style="height: 48px;"><i class="fa fa-search"></i></button>
												</span>
											</div>
										</div>

									</form>									
                                
                            </div>
                        </div>

                        <div class="container2" style="display: block;">
                            <div class="col-lg-12">
                                <div class="panel-body" style="box-shadow:10px 15px 15px #999; ">
                                    <h3 class="text-success"><i class="fa-Icon fa fa-eye"></i> View Pledge Bill</h3>
                                    <div class="table-responsive">
                                        <table id="example5" class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr style="background-color:#123C69; color:white;">
                                                    <th>#</th>
													<th>BILL NUMBER</th>
                                                    <th>INVOICE NUMBER</th>
													<th>BRANCH ID</th>
													<th>BRANCH NAME</th>
                                                    <th>CUSTOMER</th>
                                                    <th>PHONE</th>
                                                    <th>GROSS WT</th>
                                                    <th>NET WT</th>
                                                    <th>AMOUNT</th>
                                                    <th>RATE </th>
                                                    <th>RATE AMOUNT</th>
                                                    <th>EMPLOYEE NAME</th>
                                                    <th>DATE</th>
                                                    <th>BILL</th>
                                                    <th class="text-center">DOC1</th>
													<th class="text-center">DOC2</th>
													<th class="text-center"> FUND DETAILS</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                               	<?php
												if ($searchQuery && $count = mysqli_num_rows($searchQuery)) {
													$i = 1;
													while ($res = mysqli_fetch_array($searchQuery)) {
														// Fetch branchName based on branchId
														$branchId = $res['branchId'];
														$branchNameQuery = mysqli_query($con, "SELECT branchName FROM branch WHERE branchId = '$branchId'");
														$branchNameRow = mysqli_fetch_assoc($branchNameQuery);
														$branchName = $branchNameRow['branchName'];

														// Check if INVOICE NUMBER starts with "HO"
														$invoiceNumber = $res['invoiceId'];
														$rowColor = (strpos($invoiceNumber, 'HO') === 0) ? 'background-color: #ffeeba;' : '';

														echo "<tr style='$rowColor'>";
														echo "<td>$i</td>";
														echo "<td>" . $res['billId'] . "</td>";
														echo "<td>" . $res['invoiceId'] . "</td>";
														echo "<td>" . $branchId . "</td>"; // Display branchId
														echo "<td>" . $branchName . "</td>"; // Display branchName
														echo "<td>" . $res['name'] . "</td>";
														echo "<td>" . $res['contact'] . "</td>";
														echo "<td>" . $res['grossW'] . "</td>";
														$netW = $res['grossW'] - $res['stoneW'];
														echo "<td class='text-center'>" . $netW . "</td>";
														echo "<td>" . $res['amount'] . "</td>";
														echo "<td>" . $res['rate'] . "</td>";
														echo "<td>" . $res['rateAmount'] . "</td>";
														echo "<td>" . $res['empName'] . "</td>";
														echo "<td>" . $res['date'] . "</td>";
														echo "<td class='text-center'><a target='_blank' class='btn btn-success btn-md' href='InvoicePledge.php?id=" . base64_encode($res['id']) . "'><i class='fa_Icon fa fa-edit'></i> </a></b></td>";
														echo "<td class='text-center'>
															<a target='_blank' class='btn btn-success btn-md'href='CustomerDocuments/" . $res['kyc1'] . "'><i class='fa_Icon fa fa-eye'></i> Kyc1</a>
															</td>";
														if ($res['kyc2'] != "") {
															echo "<td class='text-center'><a target='_blank' class='btn btn-success btn-md' href='CustomerDocuments/" . $res['kyc2'] . "'><i class='fa_Icon fa fa-eye'></i> Kyc2</a></td>";
														} else {
															echo "<td class='text-center'><a class='btn'><i style='color:#ffcf40' class='fa fa-ban'></i> KYC2</a></td>";
														}
														echo "<td class='text-center'><a target='_blank' class='btn btn-success btn-md' href='pledgefundDetails.php?billId=" . ($res['billId']) . "'><i class='fa_Icon fa fa-book'></i> </a></b></td>";
														echo "</tr>";
														$i++;
													}
												} else {
													echo "<tr><td colspan='18'>No results found for the selected date.</td></tr>";
												}
												?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12"></div>
        <div style="clear:both"></div>
        <?php include("footer.php"); ?>
    </div>

    <!-- Modal -->
   


<script>
		
     
	function searchByDateRange() {
		var start_date = document.getElementById("start_date").value;
		var end_date = document.getElementById("end_date").value;
		window.location.href = "pledgeMaster.php?start_date=" + start_date + "&end_date=" + end_date;
    }
    
	function clickButton() {
		var selectedButton = document.getElementById("newUser").value;
		window.location.href = "pledgenewUser.php?newUser=" + selectedButton;
    }


</script>

</body>

</html>

