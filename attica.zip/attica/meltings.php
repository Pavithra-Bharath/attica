<?php
session_start();
include("header.php");
include("menuacc.php");
include("dbConnection.php");
$date=date('Y-m-d');
$date1="2020-01-27";
	   ?>
<div id="wrapper">
<div class="content">
            <div class="hpanel">
                <div class="panel-heading">
                <h3 class="text-success"><b><i style="color:#990000" class="fa fa-info-circle"></i> Melting Details</b></h3>
                </div>
                <div class="panel-body" style="box-shadow:10px 15px 15px #999;">
                <form method="POST" class="form-horizontal" action="add.php">
                <div class="form-group">
        <div class="col-lg-12">
				<div class="col-sm-2">
				 <label class="text-success">Branch</label>
			<div class="input-group"><span class="input-group-addon"><span style="color:#990000" class="fa fa-institution"></span></span>
				 <input list="cusId" class="form-control" name="bran" id="bran" placeholder="Branch Id" />  
				 </div>
				 </div>
				 <datalist id="cusId">
						<option value="All Branches">All Branches</option>
								<?php 
								$sql="select * from branch";
	                            $res=mysqli_query($con,$sql);
	                            $row=mysqli_fetch_array($res);
								while($row = mysqli_fetch_array($res))
								{
								    $branch=$row['branchId'];
								    $sql="select branchName from branch where branchId='$branch'";
								?>
								   <option value="<?php echo $row['branchId']; ?>">
								   <?php echo $row['branchName']; ?></option>
                                    <?php } ?>
                                </datalist>
                                <div class="col-sm-2"><label class="text-success">BM</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
				<input list="bm" class="form-control" name="bm" placeholder="Select BM" />
				<datalist id="bm">
								<?php 
								 $sql1="select * from employee";
	   $res1=mysqli_query($con,$sql1);
	                            $row1=mysqli_fetch_array($sql1);
								while($row1 = mysqli_fetch_array($res1))
								{
								    $empId=$row1['empId'];
								    $sql1="select name from employee where empId='$empId'";
								?>
								   <option value="<?php echo $row1['empId']; ?>">
								   <?php echo $row1['name']; ?></option>
                                    <?php } ?>
                                </datalist>
				</div></div>
				<div class="col-sm-3"><label class="text-success">Gold Send Date</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-signal"></span></span>
				<input type="text" class="form-control" name="gdate" id="gdate" placeholder="Gold Send Date" value="2020-01-23"></div>
			    </div>
				<div class="col-sm-2"><label class="text-success">Gross Weight</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-balance-scale"></span></span>
				<input type="text" class="form-control" name="grosswt" id="grosswt" placeholder="Gross Weight"></div>
			    </div>
				<div class="col-sm-3"><label class="text-success">Branch Net Weight</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-balance-scale"></span></span>
				<input type="text" class="form-control" name="bnw" id="bnw" placeholder="Branch Net Weight"></div></div>
				
				<label class="col-sm-12"><br></label>
				<div class="col-sm-2"><label class="text-success">After Stone</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
				<input type="text" class="form-control" name="afterstone" id="afterstone" placeholder="After Stone"></div>
				</div>
				<div class="col-sm-2"><label class="text-success">Difference</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-hourglass-half"></span></span>
				<input type="text" class="form-control"  name="diff" id="diff" placeholder="Difference"></div>
				</div>
				<div class="col-sm-2"><label class="text-success">Gatti Weight</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-file"></span></span>
				<input type="text" class="form-control"  name="gwt" id="gwt" placeholder="Gatti Weight"></div>
				</div>
				<div class="col-sm-2"><label class="text-success">Melting Loss</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-diamond"></span></span>
				<input type="text" class="form-control"  name="meltwt" id="meltwt" placeholder="Melting Loss"></div>
				</div>
				<div class="col-sm-2"><label class="text-success">Branch Purity</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
				<input type="text" class="form-control"  name="branchpurity" id="branchpurity" placeholder="Branch Purity"></div>
				</div>
				<div class="col-sm-2"><label class="text-success">After Purity</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
				<input type="text" class="form-control"  name="afterpurity" id="afterpurity" placeholder="After Purity"></div>
				</div><label class="col-sm-12"><br></label>
				<div class="col-sm-2"><label class="text-success">Purity Loss</label>
				<div class="input-group">
				<span class="input-group-addon"><span style="color:#990000" class="fa fa-percent"></span></span>
				<input type="text" class="form-control"  name="purityloss" id="purityloss" placeholder="Purity Loss"></div>
				</div>
				<div class="col-sm-2" align="right"><label>________________</label>
					<button class="btn btn-success" name="melting" id="melting" type="submit" ><span style="color:#ffcf40" class="fa fa-plus"></span> Submit</button>
                </div>
                </div>
                </div>
                </form>
                </div><div style="clear:both"></div>
                </div>
                <div class="hpanel">
                <div class="panel-body" style="box-shadow:10px 15px 15px #999;">
                	<div class="col-lg-12">
                    <div class="form-group">
                <table id="example2" class="table table-striped table-bordered table-hover">
                <thead>
                <tr class="text-success">
                    <th>SNo</th>
                    <th>BM</th>
					<th>Branch</th>
					<th>Gold Send Date</th>
					<th>Gross Weight</th>
					<th>Branch Net Weight</th>
					<th>After Stone</th>
					<th>Difference</th>
					<th>Gatti Weight</th>
					<th>Melting Weight</th>
					<th>Branch Purity</th>
					<th>Melting Purity</th>
					<th>Purity Margin</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $query=mysqli_query($con,"SELECT * FROM melting where gdate = '$date1'");
					$count=mysqli_num_rows($query);
					for($i=1;$i<=$count;$i++)
                    {
                        if($count>0)
                        {
                            $row=mysqli_fetch_array($query);
                            $branch=$row['branch'];
                            $sql="select branchName from branch where branchId='$branch'";
                            $res=mysqli_query($con,$sql);
                            $row1=mysqli_fetch_array($res);
                            $empid=$row['empid'];
                            $sql1="select name from employee where empId='$empid'";
                            $res1=mysqli_query($con,$sql1);
                            $row2=mysqli_fetch_array($res1);
							echo "<tr><td>" . $i .  "</td>";
							echo "<td>" . $row2['name'] ."</td>";
						    echo "<td>" . $row1['branchName'] . "</td>";
							echo "<td>" . $row['gdate'] ."</td>";
							echo "<td>" . $row['grosswt'] ."</td>";
							echo "<td>" . $row['branchnetwt'] ."</td>";
							echo "<td>" . $row['afterstone'] ."</td>";
							echo "<td>" . $row['difference'] ."</td>";
							echo "<td>" . $row['gattiwt'] ."</td>";
							echo "<td>" . $row['meltingwt'] ."</td>";
							$row['branchpurity'] == $branchpurity;
							echo "<td>" . $branchpurity ."</td>";
							if($row['afterpurity'] == '' && $row['purityloss'] == '')
							{
							echo "<td><form method='post' action='updatemelting.php?id=".$row['id']."'><div class='input-group'>
				<input type='text' class='form-control' name='afterpurity' id='afterpurity' placeholder='After Purity'></td>
				<td><input type='text' class='form-control' name='purityloss' id='purityloss' placeholder='Purity Loss'>
				<button type='submit' class='input-group-addon btn btn-primary'><span style='color:#990000' class='fa fa-check'></span></button></div></form></td></tr>";
							}
							else
							{
							    echo "<td>" . $row['afterpurity'] ."</td>";
							    echo "<td>" . $row['purityloss'] ."</td></tr>";
							}
						}
					}
				?>
				</tbody>				
			</table>
	</div>
</div>
      </div>  
	<?php include("footer.php");?>
	<div style="clear:both"></div>
</div>