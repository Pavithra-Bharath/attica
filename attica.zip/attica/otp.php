<?php
	session_start();
	include("dbConnection.php");
	$phone=$_POST['data'];
	$sql="select mobile,amobile from customer where mobile='$phone' OR amobile='$phone'";
	$res=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($res);
	$ph=$row['mobile'];
	$ph1=$row['amobile'];
	if($ph == $phone)
	{
		$count=mysqli_num_rows($res);
		echo $count;
	}
	else if($ph1 == $phone)
	{
		$count=mysqli_num_rows($res);
		echo $count;
	}			
?>