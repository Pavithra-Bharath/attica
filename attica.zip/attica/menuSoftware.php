<aside id="menu" style="overflow:scroll;overflow-x:hidden">
	<div id="sidebar-collapse">
		<ul class="nav" id="side-menu">
			<li><a href="viewBranchDetails.php"><i style="color:#B80000;width:20px;font-size:16px;" class="fa pe-7s-culture"></i> Branch</a></li>
			<li><a href="branchInfo.php"><i style="color:#DB3E00;width:20px;font-size:16px" class="fa pe-7s-info"></i> Info</a></li>
			<li><a href="editClosing.php"><i style="color:#FCCB00;width:20px;font-size:16px" class="fa pe-7s-lock"></i> Closing</a></li>
			<li><a href="editEveryCustomer.php"><i style="color:#008B02;width:20px;font-size:16px" class="fa pe-7s-add-user"></i> Every Customer</a></li>
			<li><a href="#"><span class="nav-label"><b><i style="color:#006B76;width:20px;font-size:16px" class="fa pe-7s-menu"></i> Transaction</b></span><b><span class="fa arrow"></span></b></a>
				<ul class="nav nav-second-level">
					<li><a href="searchTrans.php"> Trans</a></li>
					<li><a href="editCustomers.php"> Customer</a></li>
					<li><a href="viewBillDetails.php"> Bills</a></li>
					<li><a href="searchReleasedata.php"> Release</a></li>
				</ul>
			</li>
			<li><a href="#"><span class="nav-label"><b><i style="color:#1273DE;width:20px;font-size:16px" class="fa pe-7s-cash"></i> Money</b></span><b><span class="fa arrow"></span></b></a>
				<ul class="nav nav-second-level">
					<li><a href="editExpenseDetails.php"> Expense</a></li>
					<li><a href="searchFund.php"> Fund </a></li>
					<li><a href="editTrare.php"> Trare </a></li>
				</ul>
			</li>
			<li><a href="xreleaseDataR.php"><i style="color:#004DCF;width:20px;font-size:16px" class="fa pe-7s-portfolio"></i> Release</a></li>
			<li><a href="dailyClosingR.php"><i style="color:#5300EB;width:20px;font-size:16px" class="fa pe-7s-anchor"></i> Balance</a></li>
			<li><a href="searchbillsTransaction.php"><i style="color:#B80000;width:20px;font-size:16px" class="fa pe-7s-search"></i> Search Bill</a></li>
			
			<li><a href="#"><span class="nav-label"><b><i style="color:#1273DE;width:20px;font-size:16px" class="pe-7s-config"></i> Others</b></span><b><span class="fa arrow"></span></b></a>
			    <ul class="nav nav-second-level">
		    	    <li><a href="searchWalkinData.php"><i style="color:#008B02;width:20px;font-size:16px" class="fa pe-7s-users"></i> Walkin</a></li>
			        <li><a href="searchGoldSendData.php"><i style="color:#008B02;width:20px;font-size:16px" class="pe-7s-gleam"></i> Gold Send Data</a></li>
			        <li><a href="searchCustomerID.php"><i style="color:#B80000;width:20px;font-size:16px" class="fa pe-7s-search"></i> Search By ID</a></li>
			        <li><a href="customerAddAccess.php"><i style="color:#006B76;width:20px;font-size:16px" class="fa pe-7s-like2"></i> Access</a></li>
			        <li><a href="ws_access.php"><i style="color:#990000" class="fa fa-balance-scale"></i> WS Access </a></li>
			        <li><a href="viewLogin.php"><i style="color:#DB3E00;width:20px;font-size:16px" class="fa pe-7s-next"></i> Login OTP</a></li>
			        <li><a href="downloadData.php"><i style="color:#5300EB;width:20px;font-size:16px" class="fa pe-7s-download"></i> Download</a></li>
			        <li><a href="assignBranch.php"><i style="color:#FCCB00;width:20px;font-size:16px" class="fa pe-7s-users"></i> BMs</a></li>
			        <li><a href="editUsers.php"><i style="color:#008B02;width:20px;font-size:16px" class="fa pe-7s-id"></i> Users</a></li>
		    	    <li><a href="fraud.php"><i style="color:#006B76;width:20px;font-size:16px" class="fa pe-7s-close-circle"></i> Fraud/Theft</a></li>
		    	</ul>
			</li>
		</ul>
	</div>
</aside>