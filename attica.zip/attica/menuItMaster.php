<aside id="menu">
    <div id="sidebar-collapse">
		<ul class="nav" id="side-menu">
			<!--<li><a><b><i style="color:#990000" class="fa fa-bug"></i> Issues </b><span class="fa arrow"></span></a>-->
			<!--	<ul class="nav nav-second-level"> -->
			<!--		<li><a href="masterRaiseIssue.php"> Raise</a></li> -->
			<!--		<li><a href="viewMasterIssueDetails.php"> View</a></li> 					-->
			<!--	</ul>-->
			<!--</li>-->
			<li><a href="license-renewal.php"><span class="nav-label"><i style="color:#990000" class="fa fa-balance-scale"></i> License Renewal</span></a></li>
			<li><a href="internetRenewalStatus.php"><span class="nav-label"><i style="color:#990000" class="fa fa-wifi"></i> Internet Renewal</span></a></li>
			<li><a href="shopLicense.php"><span class="nav-label"><i style="color:#990000" class="fa fa-bank"></i> Shop License</span></a></li>
			<li><a href="ws_access.php"><span class="nav-label"><i style="color:#990000" class="fa fa-balance-scale"></i> WS Access</span></a></li>
			<li><a href="expenseApprovalIT.php"><span class="nav-label"><i style="color:#990000" class="fa fa-file-text"></i> IT Expense</span></a></li>
			<li><a href="expense_IT_report.php"><span class="nav-label"><i style="color:#990000" class="fa fa-file"></i> IT Report</span></a></li>
			<li><a href="ITissueHO.php"><span class="nav-label"><i style="color:#990000" class="fa fa-ticket"></i> IT Issues</span></a></li>
			<li><a href="it_inventory.php"><span class="nav-label"><i style="color:#990000" class="	fa fa-desktop"></i> IT Inventory</span></a></li>
			<li><a href="addVM.php"><span class="nav-label"><i style="color:#990000" class="fa_icon fa fa-user-circle"></i> Add VM</span></a></li>
		</ul>
	</div>
</aside>

