<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
$type = $_SESSION['usertype'];
if ($type == 'Master') {
	include("header.php");
	include("menumaster.php");
} else if ($type == 'Software') {
	include("header.php");
	include("menuacc.php");
} else {
	include("logout.php");
}
include("dbConnection.php");
$date = date('Y-m-d');
$time = date("l / d-M-Y");
?>
<style>
	#wrapper {
		background-color: #f5f5f5;
	}

	#wrapper h3 {
		text-transform: uppercase;
		font-weight: 600;
		font-size: 20px;
		color: #123C69;
	}

	thead {
		text-transform: uppercase;
		background-color: #123C69;
	}

	thead tr {
		color: #f2f2f2;
	}

	.dataTables_empty {
		text-align: center;
		font-weight: 600;
		font-size: 12px;
		text-transform: uppercase;
	}

	.fa_Icon {
		color: #ffd700;
	}

	.text-success {
		font-weight: 600;
		color: #123C69;
	}

	.panel-heading h3 {
		text-transform: uppercase;
	}

	.hpanel .panel-body {
		padding: 5px 15px 5px;
	}

	.dataTables_wrapper .row {
		margin-right: 0px;
		margin-left: 0px;
	}

	fieldset {
		margin-top: 1.5rem;
		margin-bottom: 1.5rem;
		border: none;
		border: 5px solid #fff;
		border-radius: 10px;
		padding: 5px;
		box-shadow: rgb(50 50 93 / 25%) 0px 50px 100px -20px, rgb(0 0 0 / 30%) 0px 30px 60px -30px, rgb(10 37 64 / 35%) 0px -2px 6px 0px inset;
	}

	legend {
		margin-left: 8px;
		width: 420px;
		background-color: #123C69;
		padding: 5px 15px;
		line-height: 30px;
		font-size: 18px;
		color: white;
		text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.5);
		transform: translateX(-1.1rem);
		box-shadow: -1px 1px 1px rgba(0, 0, 0, 0.8);
		margin-bottom: 0px;
		letter-spacing: 2px;
		text-transform: uppercase;
	}

	button {
		transform: none;
		box-shadow: none;
	}

	button:hover {
		background-color: gray;
		cursor: pointer;
	}

	legend:after {
		content: "";
		height: 0;
		width: 0;
		background-color: transparent;
		border-top: 0.0rem solid transparent;
		border-right: 0.35rem solid black;
		border-bottom: 0.45rem solid transparent;
		border-left: 0.0rem solid transparent;
		position: absolute;
		left: -0.075rem;
		bottom: -0.45rem;
	}

	@media only screen and (max-width: 500px) {
		legend {
			width: 390px;
			font-size: 12px;

		}
	}



	.highlighted {
		background-color: blue;
		color: white;
		padding: 10px;
		border-radius: 120px;
	}

	.highlight {
		background-color: #fff34d;
		-moz-border-radius: 5px;
		/* FF1+ */
		-webkit-border-radius: 5px;
		/* Saf3-4 */
		border-radius: 5px;
		/* Opera 10.5, IE 9, Saf5, Chrome */
		-moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7);
		/* FF3.5+ */
		-webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7);
		/* Saf3.0+, Chrome */
		box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7);
		/* Opera 10.5+, IE 9.0 */
	}

	.highlight {
		padding: 1px 4px;
		margin: 0 20px;
	}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
	function searchAndHighlight(searchTerm, selector) {
		if (searchTerm) {
			var selector = selector || "#realTimeContents"; //use body as selector if none provided
			var searchTermRegEx = new RegExp(searchTerm, "ig");
			var matches = $(selector).text().match(searchTermRegEx);
			if (matches != null && matches.length > 0) {
				$('.highlighted').removeClass('highlighted'); //Remove old search highlights 

				//Remove the previous matches
				$span = $('#realTimeContents span');
				$span.replaceWith($span.html());

				if (searchTerm === "&") {
					searchTerm = "&amp;";
					searchTermRegEx = new RegExp(searchTerm, "ig");
				}
				$(selector).html($(selector).html().replace(searchTermRegEx, "<span class='match'>" + searchTerm + "</span>"));
				$('.match:first').addClass('highlighted');

				var i = 0;

				$('.next_h').off('click').on('click', function() {
					i++;

					if (i >= $('.match').length) i = 0;

					$('.match').removeClass('highlighted');
					$('.match').eq(i).addClass('highlighted');
					$('.ui-mobile-viewport').animate({
						scrollTop: $('.match').eq(i).offset().top
					}, 300);
				});
				$('.previous_h').off('click').on('click', function() {

					i--;

					if (i < 0) i = $('.match').length - 1;

					$('.match').removeClass('highlighted');
					$('.match').eq(i).addClass('highlighted');
					$('.ui-mobile-viewport').animate({
						scrollTop: $('.match').eq(i).offset().top
					}, 300);
				});




				if ($('.highlighted:first').length) { //if match found, scroll to where the first one appears
					$(window).scrollTop($('.highlighted:first').position().top);
				}
				return true;
			}
		}
		return false;
	}

	$(document).on('click', '.searchButtonClickText_h', function(event) {

		$(".highlighted").removeClass("highlighted").removeClass("match");
		if (!searchAndHighlight($('.textSearchvalue_h').val())) {
			alert("No results found");
		}


	});
</script>

<?php
if (isset($_POST['date'])) {
	$searchfor = $_POST['date'];
} else {
	$searchfor = date('Y-m-d');;
}
$file = 'userLogs.txt';

$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
?>
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<fieldset>
					<legend>
						<i style="padding-top:15px" class="fa_Icon fa fa-sort-numeric-asc"></i> Logs View <span style='color:#f5deb3'><?php echo " $time"; ?> <form action="" method="POST">
								<div class="row text-center " style="margin-top: 10px;">
									<div class="col-md-9">
										<input name="date" id="text-12" value="" type="date" class=" form-control" />
									</div>
									<div class="col-md-1">
										<input name="submitlo" value="Submit" type="submit" class="btn btn-danger" />
									</div>
								</div>
							</form></span>
					</legend>

					<div class="panel-body">
						<div class="searchContend_h" align='Center' style="margin-top: 20px;">
							<!-- <?php
									echo 'User IP Address - ' . $_SERVER['REMOTE_ADDR'];
									if (preg_match_all($pattern, $contents, $matches)) {
									?> -->
							<div class="row text-center">
								<div class="col-md-3">
									<input list="cusId" name="text" id="text-12" placeholder="Enter the Username" type="text" class="textSearchvalue_h form-control" />
								</div>
								<datalist id="cusId">
									<?php
										$sql = "SELECT DISTINCT(type) FROM `users` WHERE type !='VM-HO'";
										$res = mysqli_query($con, $sql);
										while ($row = mysqli_fetch_array($res)) { ?>
										<option value="<?php echo $row['type']; ?>">
											<?php echo $row['type']; ?></option>
									<?php } ?>
								</datalist>
								<div class="col-md-1">
									<a href="#" class="searchButtonClickText_h btn btn-primary">Search</a>
								</div>
								<div class="col-md-1">
									<a href="#" class="next_h btn btn-primary">Next</a>
								</div>
								<div class="col-md-1">
									<a href="#" class="previous_h btn btn-primary">Previous</a>
								</div>
							</div>
						<?php
									}
						?>
						</div>
						<hr>
						<div id="realTimeContents" style="margin-top: 25px;">
							<?php
							if (preg_match_all($pattern, $contents, $matches)) {
								// echo "Found matches:<br />";
								echo implode("<br/><hr>", $matches[0]);
							} else {
								echo "No matches found";
								// fclose($file);
							}
							?>
						</div>
					</div>
				</fieldset>
			</div>
		</div>
	</div>
	<?php include("footer.php"); ?>