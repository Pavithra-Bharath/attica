<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> Logout</span></a></li>
        </ul>
    </div>
</aside>