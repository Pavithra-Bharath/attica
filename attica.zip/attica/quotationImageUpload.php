<?php
	session_start();
	include("dbConnection.php");
	
	if(isset($_POST['ecID']) && $_POST['ecID']!='' && isset($_POST['quotationImage']) && $_POST['quotationImage']!=''){
		$id = $_POST['ecID'];
		$branchId = $_POST['branchId'];
		
		$image_parts = explode(";base64,",$_POST['quotationImage']);
		$image_base64 = base64_decode($image_parts[1]);	
		$quotationFile = $branchId.date('YmdHis').uniqid().'.png';
		$file = 'QuotationImage/'.$quotationFile;
		file_put_contents($file, $image_base64);
		
		$data = [];
		$data['image'] = "$quotationFile";
		$data['status'] = 1;
		$encoded = json_encode($data);
		
		$sql = "UPDATE everycustomer SET quotation='$encoded' WHERE Id='$id'";
		if(mysqli_query($con,$sql)){
			echo header("location:xeveryCustomer.php");
		}
		else{
			echo "<script>alert('ERROR OCCURRED , PLEASE TRY AGAIN')</script>";
			echo "<script>setTimeout(\"location.href = 'xeveryCustomer.php';\",150);</script>";
		}
	}
	else{
		echo "<script>alert('BROWSER ERROR !!!')</script>";
		echo "<script>setTimeout(\"location.href = 'xeveryCustomer.php';\",150);</script>";
	}