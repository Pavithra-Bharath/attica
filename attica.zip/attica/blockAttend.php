<?php
		session_start();
	$type=$_SESSION['usertype'];
	$username=$_SESSION['login_username'];
	if($type=='Master'){
		include("header.php");
		include("menumaster.php");
	}
	
	else if($type=='HR'){
		include("header.php");
		include("menuhr.php");
	}
	else{
		include("logout.php");
	}
	include("dbConnection.php");
	$date = date('Y-m-d');
	
		/*   BRANCH DATA   */
	$branchData = [];
	$branchQuery = mysqli_query($con, "SELECT branchId, branchName, city, state FROM branch WHERE status = 1");
	while($row = mysqli_fetch_assoc($branchQuery)){
		$branchData[$row['branchId']] = $row;
	}
	
	/*   ATTENDANCE DATA   */
	$attendanceQuery = '';
	$branchId = '';
	$from = '';
	$to = '';
	if(isset($_GET['getAttendance'])){
		$branchId = $_GET['branchId'];
		$from = $_GET['from'];
		$to = $_GET['to'];
		$state = '';
		switch($branchId){
			case "All Branches": $state=''; break;
			case "Bangalore"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Bengaluru')"; break;
			case "Karnataka"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Karnataka' AND city!='Bengaluru')"; break;
			case "Chennai"     : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Chennai')"; break;
			case "Tamilnadu"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Tamilnadu' AND city!='Chennai')"; break;
			case "Hyderabad"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Hyderabad')"; break;
			case "AP-TS"       : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state IN ('Telangana','Andhra Pradesh') AND city!='Hyderabad')"; break;
			case "Pondicherry" : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Pondicherry')"; break;
			default            : $state=" AND branchId='$branchId'"; break;
		}
	 $attendanceQuery = mysqli_query($con, "SELECT empId, name, branchId, branch, date, time, photo, lastlogin
        FROM attendance
        WHERE date BETWEEN '$from' AND '$to' " . $state . " and status=1
        ORDER BY empId, date DESC");
} else {
    $attendanceQuery = mysqli_query($con, "SELECT empId, name, branchId, branch, date, time, photo, lastlogin
        FROM attendance
        WHERE status=1
        ORDER BY empId, date DESC");
}
	
	$data = [];
	while($row = mysqli_fetch_assoc($attendanceQuery)){
		$data[$row['empId'].$row['date']][] = $row;
	}	
	
if (isset($_POST['unblock_empId']) && isset($_POST['unblock_date'])) {
    if ($username == 'HR0002') {
        $unblockEmpId = $_POST['unblock_empId'];
        $unblockDate = $_POST['unblock_date'];

        
       // $updateQuery = "UPDATE attendance SET status = 0 WHERE empId = '$unblockEmpId' AND date = '$unblockDate'";
        $updateQuery = "UPDATE attendance SET status = 0 WHERE empId = '$unblockEmpId'";
        mysqli_query($con, $updateQuery);

        echo "<script>alert('Attendance Unblocked');</script>";
        echo "<script>setTimeout(\"location.href = 'blockAttend.php';\", 150);</script>";
    } else {
		 echo "<script>alert('Unauthorized access: You do not have permission to unblock attendance.');</script>";
       echo "<script>setTimeout(\"location.href = 'blockAttend.php';\", 150);</script>";
    }
}

?>
<style>	
	#wrapper h3{
	text-transform:uppercase;
	font-weight:700;
	font-size: 18px;
	color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
	background-color:#fffafa;
	}
	.text-success{
	color:#123C69;
	text-transform:uppercase;
	font-weight:bold;
	font-size: 12px;
	}
	.btn-primary{
	background-color:#123C69;
	}
	.theadRow {
	text-transform:uppercase;
	background-color:#123C69!important;
	color: #f2f2f2;
	font-size:11px;
	}
	.dataTables_empty{
	text-align:center;
	font-weight:600;
	font-size:12px;
	text-transform:uppercase;
	}
	.btn-success{
	display:inline-block;
	padding:0.3em 1.4em;
	margin:0 0.3em 0.3em 0;
	border-radius:0.15em;
	box-sizing: border-box;
	text-decoration:none;
	font-size: 14px;
	font-family:'Roboto',sans-serif;
	
	color:#fffafa;
	background-color:#123C69;
	box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
	text-align:center;
	position:relative;
	
	}
	 .unblock-button {
        background-color: transparent;
        border: none;
        color:green;
        font-size: 13px;
        cursor: pointer;
		font-weight: 700;
    }
	.fa_Icon {
	color: #990000;
	}
	.modal-title {
	font-size: 20px;
	font-weight: 600;
	color:#708090;
	text-transform:uppercase;
	}
	.modal-header{
	background: #123C69;
	}
	#wrapper .panel-body{
	box-shadow: 10px 15px 15px #999;
	border: 1px solid #edf2f9;
	background-color: #f5f5f5;
	border-radius:3px;
	padding: 20px;
	}
	.td-align-right{
	text-align : right;
	}
	.table-responsive .row{
	margin: 0px;
	}
</style>

<!-- DATA LIST - BRANCH LIST -->
<datalist id="branchList"> 
	<option value="All Branches"> All Branches</option>
	<option value="Bangalore"> Bangalore</option>
	<option value="Karnataka"> Karnataka</option>
	<option value="Chennai"> Chennai</option>
	<option value="Tamilnadu"> Tamilnadu</option>
	<option value="Hyderabad"> Hyderabad</option>
	<option value="AP-TS"> AP-TS</option>
	<option value="Pondicherry"> Pondicherry</option>
	<?php 
		foreach($branchData as $row){
			echo "<option value='$row[branchId]' label='$row[branchName]'></option>";
		}
	?>
</datalist>
<div id="wrapper">
	<div class="row content">
		
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<div class="col-sm-3">
					<h3 class="text-success">Blocked Attendance</span></h3>
					<small style='color: #990000'>(
						<?php 
							echo (isset($_GET['getAttendance'])) ? $_GET['from']." to ".$_GET['to'] : $date;
						?>
					)</small>
				</div>
				<form action="" method="GET" >
					<div class="col-sm-3">
						<input list="branchList" class="form-control" name="branchId"  placeholder="Branch Id" required/>
					</div>
					<div class="col-sm-4">
						<div class="input-group">
							<input type="date" class="form-control" name="from"/>
							<span class="input-group-addon">to</span>
							<input type="date" class="form-control" name="to"/>
						</div>
					</div>					
					<div class="col-sm-2" style="margin-top: 1px;">
						<button class="btn btn-success btn-block" name="getAttendance"><span class="fa_Icon fa fa-search"></span>  Search </button>
					</div>
				</form>				
			</div>
			<div style="clear:both"><br></div>
		
		
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-body">
					<div class="table-responsive">
						<table id="exampleBalance" class="table table-bordered">
							<thead>
								<tr class="theadRow">
									 <th>#</th> 
									<th>Employee_Id</th>
									<th>Employee_Name</th>
									<th>Branch</th>
									<th>State</th>
									<th>Last_Login_Date</th>
									<th>Date</th>
									<th>Time</th>
									<th style='text-align: center;'>Status</th>		
								</tr>
							</thead>
							<tbody id="tableBody">
							<?php
                                $i = 1;
                                foreach ($data as $row) {
                                $loginDate = strtotime($row[0]['lastlogin']);
                                $date = strtotime($row[0]['date']);
                                $employeeId = $row[0]['empId'];
        
                                $diff = ($row[0]['lastlogin'] == '0000-00-00' || empty($row[0]['lastlogin'])) ? 0 : floor(($date - $loginDate - 1) / (60 * 60 * 24));                                   
                                $currentDate = date('Y-m-d'); 

                                echo "<tr" . ($row[0]['date'] != $currentDate ? " style='background-color: #ffe6e6;'" : "") . ">";
                                echo "<td>" . $i . "</td>";
                                echo "<td>" . $row[0]['empId'] . "</td>";
                                echo "<td>" . $row[0]['name'] . "</td>";
                                if($row[0]['branchId']=='AGPL089'){
                                echo "<td>Vijayawada-Bhavanipuram</td>";
                                }
                                else {
                                echo "<td>" . $row[0]['branch'] . "</td>";
                                     }
                                echo "<td>" . $branchData[$row[0]['branchId']]['state'] . "</td>";
                                echo "<td>" . $row[0]['lastlogin'] . "<br><small> Difference: " . $diff . "</small></td>";
                                echo "<td>" . $row[0]['date'] . "</td>";
                                echo "<td>" . $row[0]['time'] . "</td>";

                                echo "<td style='text-align: center; vertical-align: middle;'>";     
                                echo "<form method='POST'>";
                                echo "<input type='hidden' name='unblock_empId' value='$employeeId'>";
                                echo "<input type='hidden' name='unblock_date' value='{$row[0]['date']}'>";
                                echo "<button type='submit' class='unblock-button'>Unblock</button>";
                                echo "</form>";
                                echo "</td>";
                                echo "</tr>";
                                $i++;
                                }
                              ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>	
		</div>
	</div>
	<script>
$(document).ready(()=>{
			
			$('#exampleBalance').DataTable( {
				paging: false,
				"ajax": '',
				dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
				"lengthMenu": [[10, 25, 50, 100, 250, -1], [10, 25, 50, 100, 250, "All"]],
				buttons: [
				{ extend: 'copy', className: 'btn-sm' },
				{ extend: 'csv', title: 'ExportReport', className: 'btn-sm' },
				{ extend: 'pdf', title: 'ExportReport', className: 'btn-sm' },
				{ extend: 'print', className: 'btn-sm' }
				]
			} );
			
			let tableRows = document.querySelectorAll('tr'),
			tdAP = document.querySelectorAll('.Andhra_Pradesh , .Telangana'),
			tdKAR = document.querySelectorAll('.Karnataka'),
			tdTN = document.querySelectorAll('.Tamilnadu , .Pondicherry');
			tdIndex = [2, 3, 6, 7, 8];
			
			let stateSelect = document.getElementById('state');
			stateSelect.addEventListener('change',(state)=>{
				let selected = stateSelect.value;
				switch(selected){
					
					case 'APT': getStateData('APT');
					tdAP.forEach((e)=>{ e.removeAttribute("hidden"); });
					tdKAR.forEach((e)=>{ e.setAttribute("hidden","hidden"); });
					tdTN.forEach((e)=>{ e.setAttribute("hidden","hidden"); });
					break;
					
					case 'KAR': getStateData('KAR');
					tdAP.forEach((e)=>{ e.setAttribute("hidden","hidden"); });
					tdKAR.forEach((e)=>{ e.removeAttribute("hidden"); });
					tdTN.forEach((e)=>{ e.setAttribute("hidden","hidden");});
					break;
					
					case 'TN' : getStateData('TN');
					tdAP.forEach((e)=>{ e.setAttribute("hidden","hidden"); });
					tdKAR.forEach((e)=>{ e.setAttribute("hidden","hidden"); });
					tdTN.forEach((e)=>{ e.removeAttribute("hidden"); });
					break;
					
					case 'ALL' : getStateData('ALL');
					tableRows.forEach((e)=>{ e.removeAttribute("hidden"); });
					break;
					
				}
			});
			
			function getStateData(state){
				
				
				// TOTAL DATA
				for(let index of tdIndex){
					stateRows.forEach((e)=>{
						if(e.className != "theadRow"){
							switch(index){
								case 2 : open += parseInt(e.children[index].innerHTML); break;
								case 3 : fund += parseInt(e.children[index].innerHTML); break;
								case 6 : net += parseInt(e.children[index].innerHTML); break;
								case 7 : expense += parseInt(e.children[index].innerHTML); break;
								case 8 : balance += parseInt(e.children[index].innerHTML); break;
							}
						}
					});
				}
				
				
			}
			getStateData(stateSelect.value);
			
		});
		
	</script>
<?php include("footer.php"); ?>