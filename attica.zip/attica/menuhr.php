<aside id="menu">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
			<li><a href="addEmployee.php"><span class="nav-label"><i style="color:#990000" class="fa fa-edit"></i> Employees</span></a></li>
			<li><a href="inbox.php"><span class="nav-label"><i style="color:#990000" class="fa fa-envelope"></i> MailBox</span></a></li>
			<li><a href="viewAttendance.php"><span class="nav-label"><i style="color:#990000" class="fa fa-file"></i> Consolidated Report</span></a></li>			
			<li><a href="dailyAttend.php"><span class="nav-label"><i style="color:#990000" class="fa fa-edit"></i> Daily Report</span></a></li>
			<li><a href="blockAttend.php"><span class="nav-label"><i style="color:#990000" class="fa fa-ban"></i> Blocked Attendance</span></a></li>
			<li><a href="attendanceReport.php"><span class="nav-label"><i style="color:#990000" class="fa fa-calendar"></i> Monthly Report</span></a></li>
			<li><a href="employeeMonthlyReport.php"><span class="nav-label"><i style="color:#990000" class="fa fa-user-circle-o"></i> Employee Report</span></a></li>
			<li><a href="passReset.php"><span class="nav-label"><span style="color:#990000" class="fa fa-key"></span> Reset Password</span></a></li>
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-in"></i> Logout</span></a></li>
        </ul>
    </div>
</aside>