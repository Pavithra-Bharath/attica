<aside id="menu" style="overflow:scroll;overflow-x:hidden">
	<div id="sidebar-collapse">
		<ul class="nav" id="side-menu">
			<li><a href="branch_performance.php"><i style="color:#990000" class="fa fa-bank"></i> Performance</a></li>
			<li><a href="logout.php"><i style="color:#990000" class="fa fa-user-circle-o"></i> Logout</a></li>
		</ul>
	</div>
</aside>