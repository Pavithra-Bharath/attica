<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
$type=$_SESSION['usertype'];
	   include("header.php");
	    
		 include("menu.php");
	   
	   
	   include("dbConnection.php");
	   if(isset($_SESSION['mobile']))
	   {
	   $name=$_SESSION['name'];
	$phone=$_SESSION['mobile'];
	$netW=$_SESSION['netW'];
		$grossW=$_SESSION['grossW'];
	$paid=$_SESSION['amountP'];
	$rate=$_SESSION['gold'];
	   $date=date("Y-m-d");
	  
	$sql="select billCount,branchId from trans where phone='$phone' order by id DESC LIMIT 1";
	$res=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($res);
	$count=$row['billCount'];
	$branch=$row['branchId'];
	$bdate=$row['date'];
	$sql3="select branchName from branch where branchId='$branch'";
	   $res3=mysqli_query($con,$sql3);
	   $row3=mysqli_fetch_array($res3);
	   $branchName=$row3['branchName'];

	echo $count;
	//echo $count;
	if($count>1)
	{
		$ph="8884435300,8884437300";
		$message ="Branch: ".$branchName.", Customer Name: ".$name.", Phone: ".$phone.", Gross Weight: ".round($grossW,2).", Total Bills: ".$count.", Release Amount: ".$rel.", Paid amount: ".round($paid,0).", Recent bill: ".$bdate;
	$url="http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac1114feab4e31bdfaef1f02d3d3c23e7&to=".$ph."&sender=ATTICA&message=".$message;
	$ch = curl_init();
curl_setopt_array($ch, array(
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_POST => true,
//CURLOPT_POSTFIELDS => $postData
//,CURLOPT_FOLLOWLOCATION => true
));
//Ignore SSL certificate verification
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//get response
$output = curl_exec($ch);
//Print error if any
if(curl_errno($ch))
{
echo 'error:' . curl_error($ch);
}
curl_close($ch);
	}
	   

}	   
	   
?>
<div id="wrapper">
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-heading text-success">
                    <h2 class="text-success"><b><i style="color:#900" class="fa fa-edit"></i> View Transaction Details</b> <button style="float:right" onclick="window.location.reload();" class="btn btn-success"><b><i style="color:#ffcf40" class="fa fa-refresh"></i> Reload</b></button></h2>
                </div>
                <div class="panel-body">
				<form id="frm1" action=""  method="GET" onSubmit="return validate();"> 
                <table id="example2" class="table table-striped table-bordered">
                <thead>
                <tr class="text-success">
                    <th>SlNo</th>
                    <th>Customer ID</th>
                    <th>Net Weight</th>
                    <th>Gross Weight</th>
                    <th>Net Amount</th>
                    <th>Gross Amount</th>
                    <th>Amount Paid</th>
					<th>Margin Amount</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Action</th>
					
                   
                </tr>
                </thead>
                <tbody>
                <?php
				$date=date('Y-m-d');
				$branchName=$_SESSION['branchCode'];
				$query=mysqli_query($con,"SELECT * FROM trans where	date='$date' and branchId='$branchName';");
					   $count=mysqli_num_rows($query);
//$row=mysqli_fetch_array($query);
					   
					    for($i=1;$i<=$count;$i++)
											{
					  
										if($count>0)
										{
											$row=mysqli_fetch_array($query);
											if($row['status']=="Pending")
				{
											$customerId=$row['phone'];
					   $sql="select * from customer where mobile='$customerId'";
					   $res1=mysqli_query($con,$sql);
					   $row1=mysqli_fetch_array($res1);
												echo "<tr>";
												echo "<td>" . $i .  "</td>";												
												echo "<td>" . $row['customerId'] . "</td>";
												echo "<td>" . round($row['netW'],2). "</td>";
												echo "<td>" . round($row['grossW'],2). "</td>";
												echo "<td>" . round($row['netA'],0) . "</td>";
												echo "<td>" . round($row['grossA'],0) . "</td>";
												echo "<td>" . round($row['amountPaid'],0) . "</td>";
												echo "<td>" . round($row['margin'],0). "</td>";
												echo "<td>" . $row['date'] . "</td>";
												echo "<td>" . $row['time'] . "</td>";
												echo "<td>Pending </td>";
												echo "</tr>";
											}
											else if($row['status']=="Approved")
				{
											$customerId=$row['phone'];
					   $sql="select * from customer where mobile='$customerId'";
					   $res1=mysqli_query($con,$sql);
					   $row1=mysqli_fetch_array($res1);
												echo "<tr>";
												echo "<td>" . $i .  "</td>";												
												echo "<td>" . $row['customerId'] . "</td>";
												echo "<td>" . round($row['netW'],2). "</td>";
												echo "<td>" . round($row['grossW'],2). "</td>";
												echo "<td>" . round($row['netA'],0). "</td>";
												echo "<td>" . round($row['grossA'],0). "</td>";
												echo "<td>" . round($row['amountPaid'],0). "</td>";
												echo "<td>" . round($row['margin'],0). "</td>";
												echo "<td>" . $row['date'] . "</td>";
												echo "<td>" . $row['time'] . "</td>";
												echo "<td><a target='_blank' class='btn btn-success' href='Invoice.php?billId=".$row['billId']."&billName=".$row['branchId']."&name=".$row1['name']."&amountP=".$row['amountPaid']."&mobile=".$row1['mobile']."&gross=".$row['grossA']."&net=".$row['netA']."&margin=".$row['margin']."&dat=".$row['date']."&release=".$row['releases']."'><i style='color:#ffcf40' class='fa fa-eye'></i> View Bill</a></td>";
										        echo "</tr>";
											}
											else if($row['status']=="Rejected")
				{
											$customerId=$row['phone'];
					   $sql="select * from customer where mobile='$customerId'";
					   $res1=mysqli_query($con,$sql);
					   $row1=mysqli_fetch_array($res1);
												echo "<tr>";
												echo "<td>" . $i .  "</td>";												
												echo "<td>" . $row['customerId'] . "</td>";
												echo "<td>" . round($row['netW'],2). "</td>";
												echo "<td>" . round($row['grossW'],2). "</td>";
												echo "<td>" . round($row['netA'],0). "</td>";
												echo "<td>" . round($row['grossA'],0). "</td>";
												echo "<td>" . round($row['amountPaid'],0). "</td>";
												echo "<td>" . round($row['margin'],0). "</td>";
												echo "<td>" . $row['date'] . "</td>";
												echo "<td>" . $row['time'] . "</td>";
												echo "<td>Rejected</td>";
										        echo "</tr>";
											}
										}
											}
										
				 echo "</tbody>";				
					 ?>
                
                </table>
</form>
                </div>
            </div>
        </div>

    </div>
    </div>

  <div style="clear:both"></div>
<?php
unset($_SESSION['customerId']);
		   unset($_SESSION['name']);
		   unset($_SESSION['bill']);
		   unset($_SESSION['mobile']);
	unset($_SESSION['gross']);
	unset($_SESSION['netW']);
	unset($_SESSION['netAm']);
	unset($_SESSION['amountP']);
	//$type = $_POST['comm'];
	//$per = $_POST['cType'];
	unset($_SESSION['marginAmount']);
	unset($_SESSION['grossW']);
include("footer.php");
?>

	   
		 
	   