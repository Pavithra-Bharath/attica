<?php
	session_start();
	$type=$_SESSION['usertype'];
	if($type=='Master') {
        include("header.php");
        include("menumaster.php");
	}
	else if($type=='Software'){
		include("header.php");
		include("menuSoftware.php");
	}
    else{
        include("logout.php");
	}
	include("dbConnection.php");
?>
<style>	
	#wrapper h3{
	text-transform:uppercase;
	font-weight:600;
	font-size: 16px;
	color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
	background-color:#fffafa;
	}
	.text-success{
	color:#123C69;
	text-transform:uppercase;
	font-weight:bold;
	font-size: 12px;
	}
	.btn-primary{
	background-color:#123C69;
	}
	.theadRow {
	text-transform:uppercase;
	background-color:#123C69!important;
	color: #f2f2f2;
	font-size:11px;
	}
	.dataTables_empty{
	text-align:center;
	font-weight:600;
	font-size:12px;
	text-transform:uppercase;
	}
	.btn-success{
	display:inline-block;
	padding:0.7em 1.4em;
	margin:0 0.3em 0.3em 0;
	border-radius:0.15em;
	box-sizing: border-box;
	text-decoration:none;
	font-size: 12px;
	font-family:'Roboto',sans-serif;
	text-transform:uppercase;
	color:#fffafa;
	background-color:#123C69;
	box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
	text-align:center;
	position:relative;
	}
	.fa_Icon {
	color: #990000;
	}	
	.modal-title {
	font-size: 20px;
	font-weight: 600;
	color:#708090;
	text-transform:uppercase;
	}
	.modal-header{
	background: #123C69;
	}
	#wrapper .panel-body{
	border: 5px solid #fff;
	padding: 15px;
	box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px;
	background-color: #f5f5f5;
	border-radius: 3px;
	}
</style>
<div id="wrapper">
	<div class="row content">
		
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<form method="GET" action="">
						<div class="col-lg-6">
							<h3>DAILY BRANCH REPORT
								<?php
									if(isset($_GET['region']) && isset($_GET['date'])){	
										echo "<span style='color:#990000'>( ".$_GET['region']." , ".date("d-M-Y", strtotime($_GET['date']))." </span>)";
									}
								?>
							</h3>
						</div>
						<div class="col-lg-3">
							<select class="form-control m-b" name="region" required>
								<option value="" selected>SELECT</option>
								<option value="Bangalore">Bangalore</option>
								<option value="Karnataka">Karnataka</option>
								<option value="Chennai">Chennai</option>
								<option value="Tamilnadu">Tamilnadu</option>
								<option value="Hyderabad">Hyderabad</option>
								<option value="AP-TS">AP-TS</option>
								<option value="Pondicherry">Pondicherry</option>
							</select>
						</div>
						<div class="col-lg-3">
							<div class="input-group">
								<input class="form-control" type="date" required name="date">
								<div class="input-group-btn">
									<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-body">
					<table id="example1" class="table table-bordered table-striped table-hover">
						<thead>
							<tr class="theadRow">
								<th>#</th>
								<th>BRANCH ID</th>
								<th>BRANCH NAME</th>
								<th>BILLS</th>
								<th>GROSS W</th>
								<th>NET W</th>
								<th>GROSS A</th>
								<th>NET A</th>
								<th>AVG PURITY</th>
								<th>EXPENSE</th>
							</tr>
						</thead>
						<tbody>
							<?php
								if(isset($_GET['region']) && isset($_GET['date'])){	
									
									$region = $_GET['region'];
									$date = $_GET['date'];
									$stateA = '';
									$stateB = '';
									$expData = [];
									
									switch($region){
										case "Bangalore"   :
										$stateA = "(SELECT branchId FROM branch WHERE city='Bengaluru')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE city='Bengaluru' AND status=1 AND branchId!='AGPL000'";
										break;
										
										case "Karnataka"   :
										$stateA = "(SELECT branchId FROM branch WHERE state='Karnataka' AND city!='Bengaluru')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE state='Karnataka' AND city!='Bengaluru' AND status=1"; 
										break;
										
										case "Chennai"     :
										$stateA = "(SELECT branchId FROM branch WHERE city='Chennai')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE city='Chennai' AND status=1"; 
										break;
										
										case "Tamilnadu"   :
										$stateA = "(SELECT branchId FROM branch WHERE state='Tamilnadu' AND city!='Chennai')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE state='Tamilnadu' AND city!='Chennai' AND status=1"; 
										break;
										
										case "Hyderabad"   :
										$stateA = "(SELECT branchId FROM branch WHERE city='Hyderabad')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE city='Hyderabad' AND status=1"; 
										break;
										
										case "AP-TS"       :
										$stateA = "(SELECT branchId FROM branch WHERE state IN ('Telangana','Andhra Pradesh') AND city!='Hyderabad')";
										$stateB = "SELECT branchId,branchName FROM branch WHERE state IN ('Telangana','Andhra Pradesh') AND city!='Hyderabad' AND status=1";
										break;
										
										case "Pondicherry" :
										$stateA = "(SELECT branchId FROM branch WHERE state='Pondicherry')"; 
										$stateB = "SELECT branchId,branchName FROM branch WHERE state='Pondicherry' AND status=1"; 
										break;
										
										default            :
										$stateA = "(SELECT branchId FROM branch WHERE city='Bengaluru')"; 
										$stateB = "SELECT branchId FROM branch WHERE city='Bengaluru'"; 
										break;
									}
									
									// BUSINESS DETAILS
									$query1 = "SELECT A.bills, A.grossW, A.netW, A.grossA, A.netA, A.sumPurity, B.branchId, B.branchName 
									FROM
									(SELECT branchId, COUNT(*) AS bills, ROUND(SUM(grossW),2) AS grossW, ROUND(SUM(netW),2) AS netW, ROUND(SUM(grossa),2) AS grossA, ROUND(SUM(netA)) AS netA, ROUND(SUM(purity),2) as sumPurity 
									FROM trans
									WHERE status='Approved' AND metal='Gold' AND date='$date' AND branchId IN ".$stateA."
									GROUP BY branchId) A 
									RIGHT JOIN
									(".$stateB.") B
									ON A.branchId=B.branchId
									ORDER BY B.branchId";
									$report = mysqli_query($con,$query1);
									
									// EXPENSE DETAILS
									$query2 = "SELECT branchCode,SUM(amount) AS expense
									FROM expense
									WHERE status='Approved' AND date='$date' AND branchCode IN ".$stateA."
									GROUP BY branchCode";
									$expense = mysqli_query($con,$query2);
									while($row = mysqli_fetch_assoc($expense)){
										$expData[$row['branchCode']] = $row['expense'];
									}
									
									$i = 1;
									while($row = mysqli_fetch_assoc($report)){
										echo "<tr>";
										echo "<td>".$i."</td>";
										echo "<td>".$row['branchId']."</td>";
										echo "<td>".$row['branchName']."</td>";
										echo "<td>".$row['bills']."</td>";
										echo "<td>".$row['grossW']."</td>";
										echo "<td>".$row['netW']."</td>";
										echo "<td>".$row['grossA']."</td>";
										echo "<td>".$row['netA']."</td>";
										if($row['bills'] == null){
											echo "<td></td>";
										}
										else{
											echo "<td>".round($row['sumPurity']/$row['bills'],2)."</td>";
										}
										echo "<td>".$expData[$row['branchId']]."</td>";
										echo "</tr>";
										$i++;
									}
								}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		
	</div>
<?php include("footer.php"); ?>