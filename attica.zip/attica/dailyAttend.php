<?php
	session_start();
	$type=$_SESSION['usertype'];
	if($type=='Master'){
		include("header.php");
		include("menumaster.php");
	}
	
	else if($type=='HR'){
		include("header.php");
		include("menuhr.php");
	}
	else{
		include("logout.php");
	}
	include("dbConnection.php");
	$date = date('Y-m-d');
	
	/*   BRANCH DATA   */
	$branchData = [];
	$branchQuery = mysqli_query($con, "SELECT branchId, branchName, city, state FROM branch WHERE status = 1");
	while($row = mysqli_fetch_assoc($branchQuery)){
		$branchData[$row['branchId']] = $row;
	}
	
	/*   ATTENDANCE DATA   */
	$attendanceQuery = '';
	$branchId = '';
	$from = '';
	$to = '';
	if(isset($_GET['getAttendance'])){
		$branchId = $_GET['branchId'];
		$from = $_GET['from'];
		$to = $_GET['to'];
		$state = '';
		switch($branchId){
			case "All Branches": $state=''; break;
			case "Bangalore"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Bengaluru')"; break;
			case "Karnataka"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Karnataka' AND city!='Bengaluru')"; break;
			case "Chennai"     : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Chennai')"; break;
			case "Tamilnadu"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Tamilnadu' AND city!='Chennai')"; break;
			case "Hyderabad"   : $state=" AND branchId IN (SELECT branchId FROM branch WHERE city='Hyderabad')"; break;
			case "AP-TS"       : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state IN ('Telangana','Andhra Pradesh') AND city!='Hyderabad')"; break;
			case "Pondicherry" : $state=" AND branchId IN (SELECT branchId FROM branch WHERE state='Pondicherry')"; break;
			default            : $state=" AND branchId='$branchId'"; break;
		}
	$attendanceQuery = mysqli_query($con, "SELECT empId, name, branchId, branch, date, time, photo
		FROM attendance
		WHERE date BETWEEN '$from' AND '$to'".$state." and status=0
		ORDER BY id");
	}
	else{
		$attendanceQuery = mysqli_query($con, "SELECT empId, name, branchId, branch, date, time, photo
		FROM attendance
		WHERE date='$date' and status=0
		ORDER BY id");
	}
	
	$data = [];
	while($row = mysqli_fetch_assoc($attendanceQuery)){
		$data[$row['empId'].$row['date']][] = $row;
	}	
	
	if (isset($_POST['block_empId']) && isset($_POST['block_date'])) {
    $blockEmpId = $_POST['block_empId'];
    $blockDate = $_POST['block_date'];

    // Update the status to '0' for the specified employee ID and date
    $updateQuery = "UPDATE attendance SET status = 1 WHERE empId = '$blockEmpId' AND date = '$blockDate'";
    mysqli_query($con, $updateQuery);

   echo "<script>alert('Attendence bloked.!');</script>";
        echo "<script>setTimeout(\"location.href = 'dailyAttend2.php';\", 150);</script>";
}
?>
<style>
	#wrapper h3{
	text-transform:uppercase;
	font-weight:600;
	font-size: 20px;
	color:#123C69;
	margin: 0px;
	}
	#wrapper .panel-body{
	border: 5px solid #fff;
	padding: 15px;
	box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px;
	background-color: #f5f5f5;
	border-radius: 3px;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
	background-color:#fffafa;
	}
	.text-success{
	color:#123C69;
	text-transform:uppercase;
	font-weight:bold;
	font-size: 12px;
	}
	.btn-primary{
	background-color:#123C69;
	}
	.theadRow {
	text-transform:uppercase;
	background-color:#123C69!important;
	color: #f2f2f2;
	font-size:11px;
	}
	.btn-success{
	display:inline-block;
	padding:0.7em 1.4em;
	margin:0 0.3em 0.3em 0;
	border-radius:0.15em;
	box-sizing: border-box;
	text-decoration:none;
	font-size: 10px;
	font-family:'Roboto',sans-serif;
	text-transform:uppercase;
	color:#fffafa;
	background-color:#123C69;
	box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
	text-align:center;
	position:relative;
	}
	.fa_Icon {
	color:#ffd700;
	}
	.fa_icon{
	color:#990000;
	}
	.row{
	margin-left:0px;
	margin-right:0px;
	}
	
	.block-button {
    background-color: transparent;
	color:red;
    border: none;
    padding: 0;
    cursor: pointer;
}

</style>
<!-- DATA LIST - BRANCH LIST -->
<datalist id="branchList"> 
	<option value="All Branches"> All Branches</option>
	<option value="Bangalore"> Bangalore</option>
	<option value="Karnataka"> Karnataka</option>
	<option value="Chennai"> Chennai</option>
	<option value="Tamilnadu"> Tamilnadu</option>
	<option value="Hyderabad"> Hyderabad</option>
	<option value="AP-TS"> AP-TS</option>
	<option value="Pondicherry"> Pondicherry</option>
	<?php 
		foreach($branchData as $row){
			echo "<option value='$row[branchId]' label='$row[branchName]'></option>";
		}
	?>
</datalist>
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<div class="col-sm-3">
					<h3 class="text-success">Daily Attendance</span></h3>
					<small style='color: #990000'>(
						<?php 
							echo (isset($_GET['getAttendance'])) ? $_GET['from']." to ".$_GET['to'] : $date;
						?>
					)</small>
				</div>
				<form action="" method="GET" >
					<div class="col-sm-3">
						<input list="branchList" class="form-control" name="branchId"  placeholder="Branch Id" required/>
					</div>
					<div class="col-sm-4">
						<div class="input-group">
							<input type="date" class="form-control" name="from"/>
							<span class="input-group-addon">to</span>
							<input type="date" class="form-control" name="to"/>
						</div>
					</div>
					<div class="col-sm-1" style="margin-top: 1px;">
						<button class="btn btn-success btn-block" name="getAttendance" ><span class="fa_Icon fa fa-search"></span> Search</button>
					</div>
				</form>
				<div class="col-sm-1" style="margin-top: 1px;">
					<form action="export.php" enctype="multipart/form-data" method="post">
						<input type="hidden" name="branch" value="<?php if(isset($_GET['getAttendance'])){ echo $_GET['branchId']; }else { echo "All Branches"; } ?>">
						<input type="hidden" name="from" value="<?php if(isset($_GET['getAttendance'])){ echo $_GET['from']; }else { echo $date; } ?>">
						<input type="hidden" name="to" value="<?php if(isset($_GET['getAttendance'])){ echo $_GET['to']; }else { echo $date; } ?>">
						<button type="submit" name="exportDailyAttend" class="btn btn-success btn-block" value="Export Excel" required><span class="fa_Icon fa fa-download"></span>  Export</button>
					</form> 
				</div>
			</div>
			<div style="clear:both"><br></div>
			<div class="panel-body">
				<div class="table-responsive">
				<table id="example5" class="table table-striped table-hover table-bordered">
							<thead>
								<tr class="theadRow">
									<th>#</th>
									<th>Employee_Id</th>
									<th>Employee_Name</th>
									<th>Branch</th>
									<th>City</th>
									<th>State</th>
									<th>Date</th>
									<th>Time In</th>
									<th>Photo</th>
									<th>Time Out</th>
									<th>Photo</th>
									<th>Block</th>
								</tr>
							</thead>
							<tbody>
						<?php
$i = 1;
foreach ($data as $row) {

	$loginPhoto = isset($row[0]['photo']) ? 'AttendanceImage/'.$row[0]['photo'] : '';
	$logoutPhoto = isset($row[1]['photo']) ? 'AttendanceImage/'.$row[1]['photo'] : '';
    echo "<tr>";
    echo "<td>".$i."</td>";
    echo "<td>".$row[0]['empId']."</td>";
    echo "<td>".$row[0]['name']."</td>";
     if($row[0]['branchId']=='AGPL089'){
            echo "<td>Vijayawada-Bhavanipuram</td>";
        }
        else {
            echo "<td>" . $row[0]['branch'] . "</td>";
        }
    echo "<td>".$branchData[$row[0]['branchId']]['city']."</td>";
    echo "<td>".$branchData[$row[0]['branchId']]['state']."</td>";
    echo "<td>".$row[0]['date']."</td>";
    echo "<td>".$row[0]['time']."</td>";
    echo "<td style='margin:0px;padding:0px;width: 60px;'>
        <a target='_blank' href='".$loginPhoto."'><img width='100%' src='".$loginPhoto."'></a>
    </td>";
    echo "<td>".$row[1]['time']."</td>";
    echo "<td style='margin:0px;padding:0px;width: 60px;'>
        <a target='_blank' href='".$logoutPhoto."'><img width='100%' src='".$logoutPhoto."'></a>
    </td>";
    
	echo "<td style='text-align: center; vertical-align: middle;'>";
   
    echo "<form method='POST'>";
    echo "<input type='hidden' name='block_empId' value='{$row[0]['empId']}'>";
    echo "<input type='hidden' name='block_date' value='{$row[0]['date']}'>";
    echo "<button type='submit' class='block-button'><i class='fa fa-ban' style='font-size:20px; font-weight: bold;'></i></button>"; 
    echo "</form>";
    echo "</td>";

    echo "</tr>";
    $i++;
}
?>
							</tbody>
						</table>
				</div>
			</div>
		</div>
	</div>
</div>
<div style="clear:both"></div>
<?php include("footer.php"); ?>