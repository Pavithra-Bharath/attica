<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
            <li>
            	<a href="enquiryReport.php"><span class="nav-label"><i style="color:#990000" class="fa fa-phone"></i> Main</span></a>
            </li>
            <li>
            	<a href="enquiryReportAll.php"><span class="nav-label"><i style="color:#990000" class="fa fa-file-text-o"></i> Over All</span></a>
            </li>
             <li>
                <a href="searchWalkin.php"><span class="nav-label"><i style="color:#990000" class="fa fa-search"></i> Search</span></a>
            </li>
           
			<li>
				<a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> Logout</span></a>
			</li>
        </ul>
    </div>
</aside>