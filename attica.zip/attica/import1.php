<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
$type = $_SESSION['usertype'];

if($type == 'Master') {
	include("header.php");
	include("menumaster.php");
}else if($type=='Call Centre'){
		include("header.php");
		include("menuCall.php");
	$extra= "";
	$branchSQL = mysqli_query($con,"SELECT branchId,branchName FROM branch where status = 1");
}	
include("dbConnection.php");
$date = date('Y-m-d');
$sFrom = '';
$sTo = '';
$sMetal = '';

if(isset($_GET['sMetal'])) {
	$sFrom = $_GET['sFrom'];
	$sTo = $_GET['sTo'];
}

$sqlCondition = "";
if ($sFrom !== "" && $sTo !== "") {
    $sqlCondition .= " AND date BETWEEN '$sFrom' AND '$sTo'";
}

?>

<style>
	#wrapper h3 {
		text-transform: uppercase;
		font-weight: 600;
		font-size: 20px;
		color: #123C69;
	}

	#wrapper .panel-body {
		box-shadow: 10px 15px 15px #999;
		border: 1px solid #edf2f9;
		background-color: #f5f5f5;
		border-radius: 3px;
		padding: 20px;
	}

	.form-control[disabled],
	.form-control[readonly],
	fieldset[disabled] .form-control {
		background-color: #fffafa;
	}

	.text-success {
		color: #123C69;
		text-transform: uppercase;
		font-weight: bold;
		font-size: 12px;
	}

	.btn-primary {
		background-color: #123C69;
	}

	.theadRow {
		text-transform: uppercase;
		background-color: #123C69 !important;
		color: #f2f2f2;
		font-size: 11px;
	}

	.btn-success {
		display: inline-block;
		padding: 0.7em 1.4em;
		margin: 0 0.3em 0.3em 0;
		border-radius: 0.15em;
		box-sizing: border-box;
		text-decoration: none;
		font-size: 10px;
		font-family: 'Roboto', sans-serif;
		text-transform: uppercase;
		color: #fffafa;
		background-color: #123C69;
		box-shadow: inset 0 -0.6em 0 -0.35em rgba(0, 0, 0, 0.17);
		text-align: center;
		position: relative;
	}

	.fa_Icon {
		color: #990000;
	}

	.row {
		margin-left: 0px;
		margin-right: 0px;
	}

	.block-button {
		/* background-color: #123C69; */
		color: #123C69;
		border: none;
		padding: 2px 6px;
		cursor: pointer;

	}


	.tab {
		font-family: 'Titillium Web', sans-serif;
	}

	.tab .nav-tabs {
		padding: 0;
		margin: 0;
		border: none;
	}

	.tab .nav-tabs li a {
		color: #123C69;
		background: #E3E3E3;
		font-size: 13px;
		font-weight: 700;
		text-align: center;
		letter-spacing: 1px;
		text-transform: uppercase;
		padding: 7px 10px 6px;
		margin: 5px 5px 0px 0px;
		border: none;
		border-bottom: 3px solid #123C69;
		border-radius: 0;
		position: relative;
		z-index: 1;
		transition: all 0.3s ease 0.1s;
	}

	.tab .nav-tabs li.active a,
	.tab .nav-tabs li a:hover,
	.tab .nav-tabs li.active a:hover {
		color: #f2f2f2;
		background: #123C69;
		border: none;
		border-bottom: 3px solid #ffa500;
		font-weight: 600;
		border-radius: 3px;
	}

	.tab .nav-tabs li a:before {
		content: "";
		background: #E3E3E3;
		height: 100%;
		width: 100%;
		position: absolute;
		bottom: 0;
		left: 0;
		z-index: -1;
		transition: clip-path 0.3s ease 0s, height 0.3s ease 0.2s;
		clip-path: polygon(0 0, 100% 0, 100% 100%, 0% 100%);
	}

	.tab .nav-tabs li.active a:before,
	.tab .nav-tabs li a:hover:before {
		height: 0;
		clip-path: polygon(0 0, 0% 0, 100% 100%, 0% 100%);
	}

	.tab-content h4 {
		color: #123C69;
		font-weight: 600;
	}

	@media only screen and (max-width: 479px) {
		.tab .nav-tabs {
			padding: 0;
			margin: 0 0 15px;
		}

		.tab .nav-tabs li {
			width: 100%;
			text-align: center;
		}

		.tab .nav-tabs li a {
			margin: 0 0 5px;
		}
	}

	tbody td {
		font-weight: normal;
	}

	select {

		padding: 6px 10px;
		margin: 1px 0;
		display: inline-block;
		border: 1px solid #ccc;
		border-radius: 3px;
		box-sizing: border-box;
	}
</style>


<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<div class="row">
						<div class="col-sm-5">
							<h3 class="text-success"><i style="color:#990000;" class="fa_Icon fa fa-user-circle"></i>
								Website Leads </h3>
							</h3>
						</div>
						<form action="" method="GET">

							<div class="col-sm-3">
								<label class="text-success">From Date</label>
								<div class="input-group"><span class="input-group-addon"><span style="color:#990000"
											class="fa fa-calendar"></span></span>
									<input type="date" class="form-control" name="sFrom" required />
								</div>
							</div>
							<div class="col-sm-3">
								<label class="text-success">To Date</label>
								<div class="input-group"><span class="input-group-addon"><span style="color:#990000"
											class="fa fa-calendar"></span></span>
									<input type="date" class="form-control" name="sTo" required />
								</div>
							</div>
							<div class="col-sm-1">
								<button class="btn btn-success btn-block" name="sMetal" style="margin-top:23px"><span
										style="color:#ffcf40" class="fa fa-search"></span>
									Search</button>
							</div>
						</form>


					</div><br> <br>

					<div class="tab" role="tabpanel">
						<ul class="nav nav-tabs" role="tablist">
							<li class="active"><a data-toggle="tab" href="#tab-1"><i style="color:#ffcf40"
										class="fa_Icon fa fa-refresh"></i> Pending</a></li>
							<li class="active1"><a data-toggle="tab" href="#tab-2"><i style="color:#ffcf40"
										class="fa_Icon fa fa-refresh"></i> Followup</a></li>
                            <li class="active2"><a data-toggle="tab" href="#tab-3"><i style="color:#ffcf40"
										class="fa_Icon fa fa-refresh"></i> Planning to visit</a></li>

						</ul>
						<div class="tab-content">
							<div id="tab-1" class="tab-pane active">
								<div class="panel-body">

									<div class="table-responsive">
										<table id="example1" class="table table-striped table-bordered table-hover">
											<thead>
												<tr class="theadRow">
													<th class="text-center"><i style="color:#ffcf40"
															class="fa_Icon fa fa-sort-numeric-asc"></i></th>
													<th>Customer Name</th>
													<th>Contact number</th>
													<th>Type</th>
													<th>State</th>
													<th>Date</th>
													<th>Time</th>
													<?php if ($type == 'Call Centre') { ?>
													<th class="text-center"><i class="fa fa-edit"></i></th>
													<?php } ?>
												</tr>
											</thead>
											<tbody>

											<?php
$i = 1;



$sql = mysqli_query($con, "SELECT id, name, mobile, type, state, date, time 
                           FROM enquiry 
                           WHERE status='Pending'" . $sqlCondition . "
                           ORDER BY import_date ASC");

while ($row = mysqli_fetch_assoc($sql)) {
    echo "<tr>";
    echo "<td>".$i."</td>";
    echo "<td>".$row['name']."</td>";
    echo "<td>".$row['mobile']."</td>";
    echo "<td>".$row['type']."</td>";
    echo "<td>".$row['state']."</td>";
    echo "<td>".$row['date']."</td>";
    echo "<td>".$row['time']."</td>";
	if ($type == 'Call Centre') {
    echo '<td class="text-center">';
    echo '<button class="block-button btn-sm openModal" data-toggle="modal" data-target="#myModal'.$i.'"><i class="fa fa-edit fa-lg"></i></button>';
    echo '</td>';
	}
    echo "</tr>";

    // Modal structure for each row
	echo '<div class="modal fade" id="myModal' . $i . '" tabindex="-1" role="dialog" aria-labelledby="editModalLabel' . $i . '" aria-hidden="true">';
echo '<div class="modal-dialog" role="document">';
echo '<div class="modal-content">';
echo '<div class="modal-header" style="background-color: #123C69; color: #fff; padding: 12px;">';
echo '<h2 class="text-success" id="editModalLabel' . $i . '" style="color: white; font-size: 14px; margin-bottom: 0;">Update Remarks</h2>';

	
	echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
	echo '<span aria-hidden="true">&times;</span>';
	echo '</button>';
	echo '</div>';
	echo '<div class="modal-body">';
	echo '<form method="POST" action="">'; 
	echo '<input type="hidden" name="id" value="' . $row['id'] . '">';

// First row: Customer Name and Contact Number
echo '<div class="form-group row">';

echo '<div class="col-sm-6">';
echo '<label for="name" class="col-sm-6 col-form-label">Customer Name:</label>';
echo '<input type="text" class="form-control" id="name" name="name" value="' . $row['name'] . '" readonly>';
echo '</div>';

echo '<div class="col-sm-6">';
echo '<label for="mobile" class="col-sm-6 col-form-label">Contact Number:</label>';
echo '<input type="text" class="form-control" id="mobile" name="mobile" value="' . $row['mobile'] . '" readonly>';
echo '</div>';
echo '</div>';

// Second row: Type and State
echo '<div class="form-group row">';
echo '<div class="col-sm-6">';
echo '<label for="type" class="col-sm-6 col-form-label">Type:</label>';
echo '<input type="text" class="form-control" id="type" name="type" value="' . $row['type'] . '" readonly>';
echo '</div>';


echo '<div class="col-sm-6">';
echo '<label for="state" class="col-sm-6 col-form-label">State:</label>';
echo '<input type="text" class="form-control" id="state" name="state" value="' . $row['state'] . '" readonly>';
echo '</div>';
echo '</div>';

echo '<div class="form-group row">';
echo '<div class="col-sm-6">';
echo '<label for="comments" class="col-sm-6 col-form-label">Update Comments:</label>';
echo '<textarea class="form-control" id="remarks" name="remarks" rows="2" required></textarea>';
echo '</div>';

echo '<div class="col-sm-6">';
echo '<label for="followup" class="col-sm-6 col-form-label">Planning to visit</label>';
echo '<input type="date" class="form-control" id="followup" name="followup">';
echo '</div>';
echo '</div>';


// Submit button
echo '<div class="form-group row">';
echo '<div class="col-sm-12 text-right">';
echo '<button class="btn btn-primary" type="submit" name="submit" style="padding: 12px 24px;">Submit</button>';
echo '</div>';
echo '</div>';

echo '</form>';

    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    $i++;
}
if (isset($_POST['submit'])) {
    $remarks = $_POST['remarks'];
    $id = $_POST['id'];
    $followup = $_POST['followup'];
    $currentDate = date('Y-m-d');
    $status = "Done";

    // Check if a follow-up date is provided
    if (!empty($followup)) {
        // Validate the provided date format
        if (strtotime($followup) === false) {
            
            echo "Invalid date format";
            exit; // You might want to handle this more gracefully
        } else {
            // Valid date format, proceed with the update
            $updateComment = "UPDATE enquiry SET remarks='$remarks', date='$currentDate', followup='$followup', status='$status' WHERE id='$id'";
        }
    } else {
        // No follow-up date provided, update without the follow-up date
        $updateComment = "UPDATE enquiry SET remarks='$remarks', date='$currentDate', status='$status' WHERE id='$id'";
    }

    // Execute the update query
    $res2 = mysqli_query($con, $updateComment);

    if ($res2) {
        echo "<script>alert('Remarks Updated')</script>";
        echo "<script>setTimeout(\"location.href = 'import1.php';\", 150);</script>";
        exit;
    } else {
        echo "<script>setTimeout(\"location.href = 'import1.php'\", 150);</script>";
    }
}
?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							<div id="tab-2" class="tab-pane active1">
								<div class="panel-body">
									<div class="table-responsive">
										<table id="example2" class="table table-striped table-bordered table-hover">
											<thead>
												<tr class="theadRow">
													<th class="text-center"><i style="color:#ffcf40"
															class="fa_Icon fa fa-sort-numeric-asc"></i></th>
													<th>Customer Name</th>
													<th>Contact number</th>
													<th>Type</th>
													<th>State</th>
													<th>date</th>
													<th>Followup_date</th>
													<th>Remarks</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$i = 1;
												$sql = mysqli_query($con, "SELECT id, name, mobile, type, state, date, time ,status,import_date,remarks
                           FROM enquiry 
                           WHERE status!='Pending' AND followup='0000-00-00' AND date='$date' " . $sqlCondition . "
                           ORDER BY import_date ASC");

												while($row = mysqli_fetch_assoc($sql)) {
													echo "<tr>";
													echo "<td>".$i."</td>";
													echo "<td>".$row['name']."</td>";
													echo "<td>".$row['mobile']."</td>";
													echo "<td>".$row['type']."</td>";
													echo "<td>".$row['state']."</td>";
													echo "<td>".$row['import_date']."</td>";
													echo "<td>".$row['date']."</td>";
													echo "<td>".$row['remarks']."</td>";
													echo "</tr>";

													$i++;
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							
							<div id="tab-3" class="tab-pane active1">
								<div class="panel-body">
									<div class="table-responsive">
										<table id="example3" class="table table-striped table-bordered table-hover">
											<thead>
												<tr class="theadRow">
													<th class="text-center"><i style="color:#ffcf40"
															class="fa_Icon fa fa-sort-numeric-asc"></i></th>
													<th>Customer Name</th>
													<th>Contact number</th>
													<th>Type</th>
													<th>State</th>
													<th>Previous_Followup</th>
													<th>Planning to visit</th>
													<th>Remarks</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$i = 1;
												$sql = mysqli_query($con, "SELECT id, name, mobile, type, state, date,time,status,import_date,remarks,followup
                           FROM enquiry 
                           WHERE status!='Pending' AND followup!='0000-00-00' " . $sqlCondition . "
                           ORDER BY import_date ASC");

												while($row = mysqli_fetch_assoc($sql)) {
													echo "<tr>";
													echo "<td>".$i."</td>";
													echo "<td>".$row['name']."</td>";
													echo "<td>".$row['mobile']."</td>";
													echo "<td>".$row['type']."</td>";
													echo "<td>".$row['state']."</td>";
													echo "<td>".$row['date']."</td>";
													echo "<td>".$row['followup']."</td>";
													echo "<td>".$row['remarks']."</td>";
													echo "</tr>";

													$i++;
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							
							
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<div style="clear:both"></div>
		<?php include("footer.php"); ?>