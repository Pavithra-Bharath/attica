<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
			<li><a href="issues.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-users"></span> Walkin's</span></a></li>
			<!--<li><a href="website_leads.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-sitemap"></span> Website Leads</span></a></li>-->
			<li><a href="transactionReports.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-check-square-o"></span> Sold out</span></a></li>
			<li><a href="enquiryReportAll.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-file"></span> Enquiry Report</span></a></li>
			<!--<li><a href="import1.php"><span class="nav-label"><i style="color:#990000" class="fa fa-user-circle"></i> Website Leads</span></a></li>-->
			<li><a href="searchWalkin.php"><span class="nav-label"><i style="color:#990000; width:20px" class="fa fa-search"></i> Search</span></a></li>
			<li><a href="viewBranch.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-institution"></span> Branch</span></a> </li>
			<li><a href="sms.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-comments"></span> SMS</span></a></li>
			<li><a href="inbox.php"><span class="nav-label"><i style="color:#990000; width:20px" class="fa fa-envelope"></i> MailBox</span></a></li>
			<li><a href="dailyReports.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-unlock-alt"></span> Daily Closing</span></a> </li>
			<li><a href="logout.php"><span class="nav-label"><span style="color:#990000; width:20px" class="fa fa-sign-out"></span> Logout</span></a></li>
        </ul>
    </div>
</aside>