<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
            <li><a href="inbox.php"><i style="color:#990000" class="fa fa-envelope"></i> MailBox</a></li>
            <li><a href="assignBranch.php"><span class="nav-label"><i style="color:#990000" class="fa fa-users"></i> Branch BM</span></a></li>
            <li><a href="viewBranch.php"><i style="color:#990000" class="fa fa-envelope"></i> Branch Details</a></li>
            <li><a href="license-renewal.php"><span class="nav-label"><i style="color:#990000" class="fa fa-balance-scale"></i> License Renewal</span></a></li>
            <li class="active"><a href="inventory_stock.php"><span class="nav-label"><i style="color:#990000" class="fa fa-hourglass-half"></i> Stock</span></a></li>
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> Logout</span></a></li>
        </ul>
    </div>
</aside>