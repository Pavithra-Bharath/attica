<?php
session_start();
//$type=$_SESSION['usertype'];
	   include("header.php");
	  /* if($type=='Master')
	   {
		    include("menumaster.php");
	   }
	   else if($type=='Admin')
	   {
		    include("menuadmin.php");
	   }*/
	   include("dbConnection.php");
	   
	   if( isset($_GET['id']))
	   { 
	   $id=$_GET['id'];
	   $sql="select * from employee where id='$id'";
	   $res=mysqli_query($con,$sql);
	   $row=mysqli_fetch_array($res);
}
	  ?> 
                <div class="container-fluid">
	<h4 class="text-primary"><b><i class="fa fa-institution"></i> Edit Salary</b></h4>
	<div class="card o-hidden border-0 shadow-lg my-3">
		<div class="card-body">
                <form method="POST" class="form-horizontal" action="edit.php?id=<?php echo $id;?>" >
                <div class="form-group row">
					<div class="col-sm-3"><label>Amount</label>
					 <div class="input-group">
						<input type="text" name="amount" id="amount" class="form-control" value="<?php echo $row['amount']; ?>">
						<div class="input-group-append">
								<div class="btn btn-success"><i class="fa fa-hotel"></i></div>
							</div>
						</div>
					 </div>
					 <div class="col-sm-3"><label>Comments</label>
					 <div class="input-group">
					<input type="text" class="form-control" value="<?php  echo $row['comments']; ?>" name="comment" id="comment">
					<div class="input-group-append">
								<div class="btn btn-success"><i class="fa fa-hotel"></i></div>
							</div>
					</div>
					 </div>
					 <!--div class="col-sm-3"><label>Active</label>
					 <div class="input-group">
						<span class="input-group-addon"><span class="fa fa-map"></span></span>
						<input type="checkbox" id="active" name="active" value="active">
						<!--input type="text" class="form-control" value="< ?php echo $row['status'];?>">
						</div>
						<div></input>
						</div>
				</div-->
				
			
				 <div class="col-sm-3"><label>_______________</label><br>
				 <button class="btn btn-primary" name="editsalary" id="editsalary" type="submit" ><span class="fa fa-check"></span> Change</button>
                    </div>
				</form>
                </div>
            </div>
        </div>
    </div>
<?php include("footer.php");?>
	 