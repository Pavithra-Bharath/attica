<style>
#side-menu li a {
    color: #000;
    padding: 15px 15px;
    font-size: 12px;
}
</style>
<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
            <li><a href="renewalStatus.php"><i style="color:#990000" class="fa fa-repeat"></i> RENEWALS</a></li>
			<li><a href="addAttend.php"><i style="color:#990000" class="fa fa-check-square"></i> ATTENDANCE</a></li>
			<li><a href="inbox.php"><i style="color:#990000" class="fa fa-envelope"></i> MAILBOX</a></li>
			<li><a href="xeveryCustomer.php"><i style="color:#990000" class="fa fa-user"></i> NEW CUSTOMER</a></li>
			<li><a><b><i style="color:#990000" class="fa fa-eye"></i> VIEW</b><span class="fa arrow"></span></a>
				<ul class="nav nav-second-level">
					<li><a href="xphysicalStatus.php"> BILL</a></li>
					<li><a href="xreleaseStatus.php"> RELEASE</a></li>
					<li><a href="pledgeStatus.php"> PLEDGE</a></li>
				</ul>
			</li>
			<li><a><b><i style="color:#990000" class="fa fa-rupee"></i> FUNDS</b><span class="fa arrow"></span></a>
				<ul class="nav nav-second-level">
					<li><a href="requestFund.php"> REQUEST FUNDS</a></li>
					<li><a href="transferFund.php"> TRANSFER FUNDS</a></li>
					<li><a href="pledgeFund.php">PLEDGE FUND</a></li>
				</ul>
			</li>
			<li><a><b><i style="color:#990000" class="fa fa-file-text-o"></i> SENDING REPORT</b><span class="fa arrow"></span></a>
				<ul class="nav nav-second-level">
					<li><a href="goldReports.php"> GOLD</a></li>
					<li><a href="silverReport.php"> SILVER</a></li>
				</ul>
			</li>
			<li><a href="dailyExpenses.php"><i style="color:#990000" class="fa fa-money"></i> DAILY EXPENSES</a></li>
			<li><a href="dailyClosing.php"><i style="color:#990000" class="fa fa-lock"></i> DAILY CLOSING</a></li>
			<!--<li><a href="branchIssue.php"><i style="color:#990000" class="fa fa-bug"></i> IT ISSUES</a></li>-->
			
			<!--<li><a href="<?php echo 'https://meet.jit.si/'.base64_encode($_SESSION['branchCode'].date('Y-m-d')); ?>" target="_blank"><i style="color:#990000" class="fa fa-video-camera"></i> MEET</a></li>-->
			
			<li><a href="denominations.php"><i style="color:#990000" class="fa fa-money"></i> DENOMINATIONS</a></li>
			<!--<li><a href="addmedia.php"><i style="color:#990000" class="fa fa-edit"></i> UPLOAD VIDEOS</a></li>-->
			<li><a href="IT_issue.php"><i style="color:#990000" class="fa fa-ticket"></i> IT ISSUES</a></li>
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> LOGOUT</span></a></li>
		</ul>
	</div>
</aside>