<?php
	session_start();
	$type=$_SESSION['usertype'];
	if($type=='HR'){
		include("header.php");
		include("menuhr.php");
	}

	else{
		include("logout.php");
	}
	include("dbConnection.php");
	
	if(isset($_GET['empReport'])){
		
		$empId = $_GET['empId'];
		$monthYear = $_GET['empMonth'];
		
		// GET NUMBER OF DAYS IN A MONTH;
		$splitDate = explode("-",$monthYear,2);
		$totalDays = cal_days_in_month(CAL_GREGORIAN, $splitDate[1], $splitDate[0]);
		
		// SUNDAYS IN THE GIVEN MONTH
		function getSundays($y,$m){ 
			$date = "$y-$m-01";
			$first_day = date('N',strtotime($date));
			$first_day = 7 - $first_day + 1;
			$last_day =  date('t',strtotime($date));
			$days = [];
			for($i=$first_day; $i<=$last_day; $i=$i+7){
				$days[] = $i;
			}
			return count($days);
		}
		$totalSundays = getSundays($splitDate[0],$splitDate[1]);
		$monthName = '';
		
		switch($splitDate[1]){
			case '01' : $monthName='Jan';break;
			case '02' : $monthName='Feb';break;
			case '03' : $monthName='Mar';break;
			case '04' : $monthName='April';break;
			case '05' : $monthName='May';break;
			case '06' : $monthName='June';break;
			case '07' : $monthName='July';break;
			case '08' : $monthName='Aug';break;
			case '09' : $monthName='Sep';break;
			case '10' : $monthName='Oct';break;
			case '11' : $monthName='Nov';break;
			case '12' : $monthName='Dec';break;
		}
		
		$allData = [];
		$sql = "SELECT empId,name,branchId,branch,date,time,photo
		FROM attendance
		WHERE DATE_FORMAT(date,'%Y-%m')='$monthYear' AND empId='$empId'
		GROUP BY date,empId";
		$query = mysqli_query($con,$sql);
		while($row = mysqli_fetch_assoc($query)){
			$allData[] = $row;
		}
		
		$employeeData = mysqli_fetch_assoc(mysqli_query($con,"SELECT name,contact FROM employee WHERE empId='$empId'"));
		
	}
?>
<style>
	#wrapper{
	background-color: #d9d9d9;
	}
	#wrapper h3{
	text-transform:uppercase;
	font-weight:600;
	font-size: 15px;
	color:#123C69;
	}
	.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control{
	background-color:#fffafa;
	}
	.text-success{
	color:#123C69;
	text-transform:uppercase;
	font-weight:bold;
	font-size: 12px;
	}
	.btn-primary{
	background-color:#123C69;
	}
	.btn-success{
	display:inline-block;
	padding:0.7em 1.4em;
	margin:0 0.3em 0.3em 0;
	border-radius:0.15em;
	box-sizing: border-box;
	text-decoration:none;
	font-size: 10px;
	font-family:'Roboto',sans-serif;
	text-transform:uppercase;
	color:#fffafa;
	background-color:#123C69;
	box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
	text-align:center;
	position:relative;
	}
	.fa_Icon {
	color:#ffd700;
	}
	.fa_icon{
	color:#990000;
	}
	.row{
	margin-left:0px;
	margin-right:0px;
	}
	#wrapper .panel-body{
	box-shadow:10px 15px 15px #999;
	border: 1px solid #edf2f9;
	border-radius:7px;
	background-color: #f5f5f5;
	}
</style>
<!-- DATA LIST - BRANCH LIST -->
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<div class="col-lg-5">
						<h3 style="margin-top:30px"> Employee Report</h3>
					</div>
					<form action="" method="GET">
						<div class="col-lg-3">
							<label class="text-success">Employee ID</label>
							<div class="input-group">
								<span class="input-group-addon"><span class="fa_icon fa fa-address-book-o"></span></span>
								<input type="text" class="form-control" name="empId" placeholder="Employee ID" required autocomplete="off">  
							</div>
						</div>
						<div class="col-lg-3">
							<label class="text-success">Month</label> 
							<div class="input-group">
								<span class="input-group-addon"><span class="fa_icon fa fa-calendar"></span></span>
								<input type="month"  class="form-control" name="empMonth" required>
							</div>
						</div>
						<div class="col-lg-1">
							<button style="margin-top:23px" type="submit" class="btn btn-success btn-block" name="empReport"><span class="fa_Icon fa fa-search"></span></button>
						</div>
					</form>
				</div>
				<div style="clear:both"><br></div>
				<?php if(isset($_GET['empReport'])){ ?>
					<div class="col-sm-5">
						<div class="panel-body no-padding" style="margin-top:25px">
							<div class="panel-heading hbuilt">
								<b>Employee Info</b>
							</div>
							<ul class="list-group">
								<li class="list-group-item">
									<i class="fa pe-7s-id text-success" style="font-size:30px;margin-right:30px;"></i>
									<?php echo $empId; ?>
								</li>
								<li class="list-group-item ">
									<i class="fa pe-7s-user text-success" style="font-size:30px;margin-right:30px;"></i>
									<?php echo $employeeData['name']; ?>
								</li>
								<li class="list-group-item">
									<i class="fa pe-7s-call text-success" style="font-size:30px;margin-right:30px;"></i>
									<?php echo $employeeData['contact']; ?>
								</li>
							</ul>
						</div>
						<div class="panel-body no-padding" style="margin-top:25px">
							<div class="panel-heading hbuilt">							
								<b><?php echo $monthName." - ".$splitDate[0]; ?></b>
							</div>
							<ul class="list-group">
								<li class="list-group-item">
									<span class="badge badge-primary"><?php echo $totalDays; ?></span>
									Days
								</li>
								<li class="list-group-item ">
									<span class="badge badge-info"><?php echo count($allData); ?></span>
									Present
								</li>
								<li class="list-group-item">
									<span class="badge badge-danger"><?php echo $totalSundays; ?></span>
									Sundays
								</li>
								<li class="list-group-item">
									<span class="badge badge-success"><?php echo count($allData)+$totalSundays; ?></span>
									Total
								</li>
							</ul>
						</div>	
					</div>
					<div class="col-sm-7">
						<div class="v-timeline vertical-container animate-panel"  data-child="vertical-timeline-block" data-delay="2">
							<?php foreach($allData as $key=>$val){ ?>
								<div class="vertical-timeline-block">
									<div class="vertical-timeline-icon navy-bg">
										<i class="fa fa-calendar" style="color:#990000"></i>
									</div>
									<div class="vertical-timeline-content" style="box-shadow:10px 15px 15px #999;">
										<div class="row" style="padding-top:20px;">
											<div class="col-sm-3" style="padding-left:30px">
												<?php echo $val['date']; ?><br/> <small><?php echo $val['time']; ?></small>
											</div>
											<div class="col-sm-6">
												<?php echo $val['name']."<br>".$val['empId']; ?>
											</div>
											<div class="col-sm-2">
												<img style="width:100%;" class="img-circle m-b" src='AttendanceImage/<?php echo $val['photo']; ?>'>
											</div>
										</div>
										<div class="panel-footer" style="text-align:center">
											<?php echo $val['branch']." - ".$val['branchId']; ?>
										</div>
									</div>
								</div>
							<?php } ?>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<div style="clear:both"></div>
<?php include("footer.php"); ?>