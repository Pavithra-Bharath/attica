<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
$type = $_SESSION['usertype'];
if ($type == 'VM-HO') {
	include("headervc.php");
	include("menuvc.php");
	$branchCode = base64_decode($_GET['mn']);
} else {
	include("logout.php");
}
$date = date('Y-m-d');


?>
<style>
	#results img {
		width: 100px;
	}

	#wrapper {
		background: #E3E3E3;
	}

	#wrapper h3 {
		text-transform: uppercase;
		font-weight: 600;
		font-size: 14px;
	}

	.form-control[disabled],
	.form-control[readonly],
	fieldset[disabled] .form-control {
		background-color: #fffafa;
	}

	.quotation h3 {
		color: #123C69;
		font-size: 18px !important;
	}

	.text-success {
		color: #123C69;
		text-transform: uppercase;
		font-weight: 600;
		font-size: 12px;
		margin: 0px 0px 0px;
	}

	.btn-primary {
		background-color: #123C69;
	}

	thead {
		text-transform: uppercase;
		background-color: #123C69;
	}

	thead tr {
		color: #f2f2f2;
		font-size: 12px;
	}

	.btn-success {
		display: inline-block;
		padding: 0.7em 1.4em;
		margin: 0 0.3em 0.3em 0;
		border-radius: 0.15em;
		box-sizing: border-box;
		text-decoration: none;
		font-size: 12px;
		font-family: 'Roboto', sans-serif;
		text-transform: uppercase;
		color: #fffafa;
		background-color: #123C69;
		box-shadow: inset 0 -0.6em 0 -0.35em rgba(0, 0, 0, 0.17);
		text-align: center;
		position: relative;
	}

	.modaldesign {
		float: right;
		cursor: pointer;
		padding: 5px;
		background: none;
		color: #f0f8ff;
		border-radius: 5px;
		margin: 15px;
		font-size: 20px;
	}

	#wrapper .panel-body {
		box-shadow: 10px 15px 15px #999;
		border: 1px solid #edf2f9;
		border-radius: 7px;
		background-color: #f5f5f5;
		padding: 20px;
	}

	.tooltip .tooltiptext {
		visibility: hidden;
		width: 120px;
		background-color: #990000;
		color: #fff;
		text-align: center;
		border-radius: 6px;
		padding: 5px 0;
		position: absolute;
		z-index: 1;
		top: -5px;
		right: 105%;
	}

	.tooltip:hover .tooltiptext {
		visibility: visible;
	}

	.panel-box {
		margin: 20px;
		border: 4px solid #fff;
		border-radius: 10px;
		padding: 20px;
		overflow: hidden;
		background: #990000;
		filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#f5f5f5', EndColorStr='#f6f2ec');
		-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorStr='#f5f5f5', EndColorStr='#f6f2ec')";
		-moz-box-shadow: 0 0 2px rgba(0, 0, 0, 0.35), 0 85px 180px 0 #fff, 0 12px 8px -5px rgba(0, 0, 0, 0.85);
		-webkit-box-shadow: 0 0 2px rgb(0 0 0 / 35%), 0 85px 810px -68px #fff, 0 12px 8px -5px rgb(0 0 0 / 65%);
		box-shadow: 0 0 2px rgb(0 0 0 / 35%), 0 85px 180px 0 #fff, 0 12px 8px -5px rgb(0 0 0 / 85%);
	}
</style>
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel text-center">
				<div class="panel-body">
					<div class="stats-title pull-left">
						<h3 class="text-success">Video Calling <?php echo $branchCode; ?></h3>
					</div>
					<div class="m-t-xl" style="margin-top:20px">
						<iframe allow="camera; microphone; fullscreen; display-capture; autoplay" src="https://meet.jit.si/<?php echo $branchCode; ?>" style="height:450px; width: 100%; border: 0px;"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include("footer.php"); ?>
</div>

<!-- ===================================== RENEWAL EXPIRY ALERT ================================== -->
