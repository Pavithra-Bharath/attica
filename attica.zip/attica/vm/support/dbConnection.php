<?php
	$con= mysqli_connect('localhost','atticagoldapp_new','atticagoldnew','atticagoldapp_new');
	if(!$con){
		die('could not connect;'.mysqli_connect_error());
	}
?>