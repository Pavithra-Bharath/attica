<?php
    session_start();
    $phone = 9361247663;
    $add = 'Head Office';
    $message = "Dear Customer, Address: ".$add;
    
// 	$url="http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac1114feab4e31bdfaef1f02d3d3c23e7&to=".$phone."&sender=ATTICA&message=".$message;
	
	$url = "http://103.255.217.31:15181/BULK_API/SendMessage?loginID=attica_seht&password=attica@123&mobile=".$phone."&text=".$message."&senderid= ATICAA&DLT_TM_ID= 1001096933494158&DLT_CT_ID=&DLT_PE_ID=1201159127344394306&route_id=DLT_SERVICE_EXPLICT&Unicode=0&camp_name=attica_se";
	$url1 = str_replace(" ", '%20', $url);
	
	$ch = curl_init();
    curl_setopt_array($ch, array(CURLOPT_URL => $url1,CURLOPT_RETURNTRANSFER => true,CURLOPT_POST => true,));
    
    //Ignore SSL certificate verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    
    //get response
    $output = curl_exec($ch);
    
    //Print error if any
    if(curl_errno($ch)){
        echo 'error:' . curl_error($ch);
    }
    curl_close($ch);
    header("location:sms.php");
?>
