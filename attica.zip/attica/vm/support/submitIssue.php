<?php
	include("dbConnection.php");
	$date=date('Y-m-d');
	$time=date("h:i:s");
	$dateTime = date("Y-m-d h:i:s");
	//$branch=$_SESSION['branchCode'];
		
	if(isset($_POST['submitMobIssue']))
	{
	    $branchId ="";
	    $status = "";
	    $assignedTo = "";
		$remarks = "";
		$priority ="";
		$acptDateTime =$dateTime;
		$rslvDateTime = $dateTime;
		$empId = "";
		$empName = "";
		
		$branchName = $_POST['bname'];
		$name = $_POST['Ename'];
		$empid = $_POST['Eid'];
		$phone = $_POST['mobile'];
		$issue = $_POST['issues'];
		$description = $_POST['details'];
		
		/* $sql="select * from issue ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$branchName=$row['branchName']; */
	/*	$insconn = "INSERT INTO issue(branchName,empName,empId,phoneNo,issueType,des,date)
		VALUES ('$branchName','$name','$empid','$phone','$issue','$description','$date')"; */
		$insconn = "INSERT INTO `issue`(issueType, des, branchId, status, priority, assignedTo, remarks,date, time, acptDateTime,rslvDateTime, branchName, empId, empName, phoneNo)
		VALUES ('$issue','$description','$branchId','$status ','$priority',' $assignedTo','$remarks','$date','$time','$acptDateTime','$rslvDateTime','$branchName','$empid','$name','$phone')";
		
		
		if((mysqli_query($con,$insconn)))	
		{
			$sqlC = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM issue WHERE date='$date' ORDER BY id DESC"));
			$issue = $sqlC['issueType'];
			$bname = $sqlC['branchName'];
			$employee = $sqlC['empName'];
			$contact = $sqlC['phoneNo'];
			
			
		    /*	$phone = array();
			$phone['master'] = 8884520172;
			$message = "IT:: ".$bname ."  Employee: ".$employee." Contact: ".$contact." issueType: ".$issue." problem in the branch";
			$url="http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac1114feab4e31bdfaef1f02d3d3c23e7&to=".$phone['master']."&sender=ATTICA&message=".$message;
			
			$ch = curl_init();
			curl_setopt_array($ch, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true
			));
			//Ignore SSL certificate verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			//get response
			$output = curl_exec($ch);
			//Print error if any
			if(curl_errno($ch))
			{
				echo 'error:' . curl_error($ch);
			}
			curl_close($ch); */
			
			$phone = array('8151005300','8123181429','8861111337');
				foreach($phone as $contactno)
				{
					$message = "IT:: ".$bname ."  employee: ".$employee." Contact: ".$contact." issueType: ".$issue." problem in the branch";
			        
			     //   $url="http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac1114feab4e31bdfaef1f02d3d3c23e7&to=".$contactno."&sender=ATTICA&message=".$message;
			        
			        $url ="http://103.255.217.28:15181/BULK_API/SendMessage?loginID=attica_siht1&password=attica@123&mobile=".$contactno."&text=".$message."&senderid=ATTICA&DLT_TM_ID=1001096933494158&DLT_CT_ID=&DLT_PE_ID=1201159127344394306&route_id=DLT_SERVICE_IMPLICT&Unicode=0&camp_name=attica_se";
	                
	                $url1 = str_replace(" ",'%20', $url);
					$ch = curl_init();
					curl_setopt_array($ch, array(
					CURLOPT_URL => $url1,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POST => true
					));
					//Ignore SSL certificate verification
					curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					//get response
					$output = curl_exec($ch);
					//Print error if any
					if(curl_errno($ch))
					{
						echo 'error:' . curl_error($ch);
					}
				curl_close($ch);
				}
			echo "<script type='text/javascript'>alert('Issue Reported Successfully!')</script>";
			echo "<script>setTimeout(\"location.href = 'index.php';\",50);</script>";
		   //header("location:messegeSuccess.php");
		  
			
		}
	}
	
?>