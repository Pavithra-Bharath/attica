<?php
    include("dbConnection.php");
?>
<datalist id="EId">
	<?php 
	$eQuery = mysqli_query($con,"SELECT * FROM employee");
	while($erow = mysqli_fetch_array($eQuery)) { ?><option value="<?php echo $erow['empId']; ?>"><?php echo $erow['name']; ?></option>
	<?php } ?>
</datalist>
<!DOCTYPE html>
<html>
	<head>
		<title>IT issue</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	</head>

	<body>	
	<div class="text-center" style="background-color: #ebebe0;">
						<img src="Attica Logo-min.png" class="mx-auto" alt="ATTICA GOLD" style="height:150px;width:200px;"><hr>
						</div>
		<div class="container">
			<div class="col-8">
				<div class="hpanel">
					<div class="panel-body" style="box shadow: 10px 15px 15px #999;">
					    
						<h3 class="text-center" style="color:#990000;"><b>IT Issues</b></h3>
						<div class="col-4">
							<form method="POST" action="submitIssue.php" class="mx-auto" enctype="multipart/form-data" autocomplete="off">
									    <div class="form-group">
								        <label><h4><b>Branch Name<b></h4></label>
											<?php
											    $connect = mysqli_query($con,"select * from branch");
											    $options="";
												while($row = mysqli_fetch_array($connect)){
													$options= $options."<option>$row[2]</option>";
												}
										    ?>
										    <select  class="form-control" name="bname" id="bname" required>
										    <?php 
												echo "<option selected> Select </option>";
												echo $options;								  
										    ?>
									    	</select>
									    </div>

									<div class="form-group">
								    <label><h4><b>Employee Name</b></h4></label>
										<input type="text" name="Ename" style="padding:0px 5px" id="Ename" placeholder="Employee Name" maxlength="40" class="form-control" required>
									</div>

						
									<div class="form-group">
									<label><h4><b>Employee ID</b></h4></label>
										<input list="EId" class="form-control" name="Eid" style="padding:0px 5px" placeholder="Employee id" required>
									</div>

					
									<div class="form-group">
								    <label><h4><b>Contact Number</b></h4></label>
										<input type="text" name="mobile" style="padding:0px 5px" id="mobile" placeholder="Contact Number" maxlength="10" class="form-control"  required>
									</div>
							 
							
									<div class="form-group">
								    <label><h4><b> Issues</b></h4></label>
										<select class="form-control m-b" name="issues" id="issues" required>
											<option selected="true" disabled="disabled" value=""> Select </option> 
											<option value="electric"> Electirc </option>
											<option value="system"> System </option>
											<option value="network"> Network </option>
											<option value="karatMeter"> Karatmeter </option>
											<option value="others"> Others </option>
										</select>
									</div>
							
						
						
							    <div class="form-group">
                                    <label for="exampleFormControlTextarea1"><h4><b>Details</h4></label>
                                    <textarea class="form-control" name="details"  id="exampleFormControlTextarea1" rows="3" required></textarea>
                                </div>
						
						
							
							<br>
							
					
									<button style="background-color:#990000;color:#ffffff;" class="btn btn-lg btn-block" name="submitMobIssue" id="submitMobIssue" type="submit">Submit </button>
					</form>

					</div>
				</div>
			</div>			
		</div>
	</div>

</body>
</html>
