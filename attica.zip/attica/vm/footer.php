<footer class="footer">
	<b><span style="color:#990000" class="pull-right">
	ISO 9001:2015 Certified Company</span>
	<span style="color:#990000" class="pull-left">
	Attica Gold Pvt Ltd</span></b>
</footer>
</div> 

<!-- Vendor scripts -->
<script src="jpeg_camera/jpeg_camera_with_dependencies.min.js" type="text/javascript"></script>
<script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/jquery-ui/jquery-ui.min.js"></script>
<script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="vendor/jquery-flot/jquery.flot.js"></script>
<script src="vendor/jquery-flot/jquery.flot.resize.js"></script>
<script src="vendor/jquery-flot/jquery.flot.pie.js"></script>
<script src="vendor/flot.curvedlines/curvedLines.js"></script>
<script src="vendor/jquery.flot.spline/index.js"></script>
<script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
<script src="vendor/iCheck/icheck.min.js"></script>
<script src="vendor/peity/jquery.peity.min.js"></script>
<script src="vendor/sparkline/index.js"></script>
<script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables buttons scripts -->
<script src="vendor/pdfmake/build/pdfmake.min.js"></script>
<script src="vendor/pdfmake/build/vfs_fonts.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="vendor/bootstrap-datepicker-master/dist/js/bootstrap-datepicker.min.js"></script>
<script src="scripts/charts.js"></script>
<script src="scripts/homer.js"></script>
<script src="scripts/states.js"></script>
<script src="vendor/clockpicker/dist/bootstrap-clockpicker.min.js"></script>
<script src="vendor/summernote/dist/summernote.min.js"></script>
<script>
	$(document).ready(function()
	{
		$('#sbran').change(function()
		{
			var c =  $('#sbran').val();
			window.location.replace("DashboardSir.php?sbran="+c);
		});
		$("#afterstone").change(function()
		{
			var afterstone = $('#afterstone').val();
			var bnw = $('#bnw').val();
			var diff = afterstone - bnw;
			$("#diff").val(diff.toFixed(2));
		});
		$("#gwt").change(function()
		{
			var gwt = $('#gwt').val();
			var bnw = $('#bnw').val();
			var meltwt = gwt - bnw;
			$("#meltwt").val(meltwt.toFixed(2));
		});
		$("#afterpurity").change(function()
		{
			var afterpurity = $('#afterpurity').val();
			var branchpurity = $('#branchpurity').val();
			var purityloss = afterpurity - branchpurity;
			$("#purityloss").val(purityloss.toFixed(2));
		});
		$("#code").change(function()
		{
			var data=$('#code').val();
			var req=$.ajax(
			{
				url:"getStock.php",
				type: "POST",
				data:{data},
			}); 
			req.done(function(msg)
			{
				$("#stock").val(msg);
			});
		});
	});
</script>
<script>
    var options = {
		shutter_ogg_url: "jpeg_camera/shutter.ogg",
		shutter_mp3_url: "jpeg_camera/shutter.mp3",
		swf_url: "jpeg_camera/jpeg_camera.swf",
	};
	
    var camera = new JpegCamera("#camera", options);
	
	$('#snapshots').click(function()
	{
		var snapshot = camera.capture();
		snapshot.show();
		snapshot.upload({api_url: "ac.php"}).done(function(response)
		{
			$('#image').prepend("<tr><td><img src='"+response+"' width='80px' height='74px'></td></tr>");
			this.discard();
			//alert("Marked Attendance");
		});
	});
	
	
	function changeTex(submitId)
	{
        var submit = document.getElementById(submitId);
        submit.value = 'Marked Attendance';
        return false;
	};
</script>
<script>
	
    var options = {
		shutter_ogg_url: "jpeg_camera/shutter.ogg",
		shutter_mp3_url: "jpeg_camera/shutter.mp3",
		swf_url: "jpeg_camera/jpeg_camera.swf",
	};
	
    var camera = new JpegCamera("#camera", options);
	
	$('#take').click(function()
	{
		var snapshot = camera.capture();
		snapshot.show();
		snapshot.upload({api_url: "act.php"}).done(function(response)
		{
			$('#imagelist').prepend("<tr><td><img src='"+response+"' width='80px' height='74px'></td></tr>");
			this.discard();
			//alert("Marked Attendance");
		});
	});
	
	
	function changeTex(submitId)
	{
        var submit = document.getElementById(submitId);
        submit.value = 'Recapture';
        return false;
	};
</script>
<script>
	$(document).ready(function()
	{
		$("#gspd").change(function()
		{
			var gtype = $('#gspd').val();
			$("#metal").val(gtype);
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#empp").change(function()
		{
			var data=$('#empp').val();
			var req=$.ajax({
				url:"employeeDetailss.php",
				type: "POST",
				dataType: 'JSON',
				data:{data},
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++)
					{
						var name = response[i].name;
						var phone = response[i].phone;
						var email = response[i].email;
						var address = response[i].address;
						var loc = response[i].loc;
						var des = response[i].des;
						var gender = response[i].gender;
						var join = response[i].join;
						var qual = response[i].qual;
						var doc = response[i].doc;
						var branch = response[i].branch;
						var lan = response[i].lan;
						var ref = response[i].ref;
						
						$("#name").val(name);
						$("#number").val(phone);
						$("#email").val(email);
						$("#address").val(address);
						$("#loc").val(loc);
						$("#des").val(des);
						$("#gender").val(gender);
						$("#join").val(join);
						$("#qual").val(qual);
						$("#doc").val(doc);
						$("#branch").val(branch);
						$("#lan").val(lan);
						$("#ref").val(ref);
					}
					
				}
			});
		});
	});
	
</script>
<script>
	$(document).ready(function()
	{
		$("#contact").change(function()
		{
			
			alert("OTP Sent To Your Mobile");
			var data=$('#contact').val();
			var name=$('#name').val();
			var req1=$.ajax({
				url:"ot.php",
				type: "POST",
				data:{data:data,name:name},
				
				
			});
			req1.done(function(msg)
			{
				window.location.href("addLeads.php");
			});
			
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#contact1").change(function()
		{
			
			alert("OTP Sent To Your Mobile");
			var data=$('#contact1').val();
			var name=$('#name').val();
			var req1=$.ajax({
				url:"otp1.php",
				type: "POST",
				data:{data:data,name:name},
				
				
			});
			req1.done(function(msg)
			{
				window.location.href("addLeads.php");
			});
			
		});
	});
</script>

<script>
	
    $(function ()
    {
		
        // Initialize summernote plugin
        $('.summernote').summernote({
            toolbar: [
			['headline', ['style']],
			['style', ['bold', 'italic', 'underline', 'superscript', 'subscript', 'strikethrough', 'clear']],
			['textsize', ['fontsize']],
			['alignment', ['ul', 'ol', 'paragraph', 'lineheight']],
            ]
		});
		
	});
	
</script>
<style>
	#camera {
	width: 170px;
	height: 160px;
	}
	.wrapper {
    background: #FFF;
    border:1px solid lightgray;
	}
</style>
<script>
	$(document).ready(function()
	{
		$(".nav li.disabled a").click(function()
		{
			return false;
		});
	});
</script>
<script language="JavaScript">
	function FillBilling(f)
	{
		if(f.billingtoo.checked == true)
		{
			f.line1.value = f.line.value;
			f.locality1.value = f.locality.value;
			f.state1.value = f.state.value;
			var city=f.city.value;
			var select=f.city1;
			var el = document.createElement("option");
			el.textContent = city;
			el.value =city;
			select.appendChild(el);
			f.landmark1.value = f.landmark.value;
			f.pin1.value = f.pin.value;
		}
	}
	function FillBillings(f)
	{
		if(f.billingtooo.checked == true)
		{
			f.line1.value = f.line.value;
			f.locality1.value = f.locality.value;
			f.state3.value = f.state2.value;
			var city=f.city2.value;
			var select=f.city3;
			var el = document.createElement("option");
			el.textContent = city;
			el.value =city;
			alert(el.value);
			select.appendChild(el);
			f.landmark1.value = f.landmark.value;
			f.pin1.value = f.pin.value;
		}
	}
</script>
<SCRIPT>
	$(document).ready(function()
	{
		$("#rel").change(function()
		{
			var comm = $('#rel').val();
			var data=comm;
			var req=$.ajax({
				url:"setMargin.php",
				type: "POST",
				data:{data},
				
				
			}); 
			req.done(function(msg)
			{
				$("#payable").val(msg);
			});
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#cus").change(function()
		{
			var data = $('#cus').val();
			var req=$.ajax({
				url:"setCustomer.php",
				type: "POST",
				dataType: 'JSON',
				data:{data},
				
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++)
					{
						var name = response[i].name;
						var phone = response[i].phone;
						$("#dat2").val(name);
						$("#dat3").val(phone);
						
					}
				}
			}); 
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#dat3").change(function()
		{
			var data = $('#dat3').val();
			var req=$.ajax({
				url:"setPhone.php",
				type: "POST",
				dataType: 'JSON',
				data:{data},
				
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++)
					{
						var name = response[i].name;
						var cus = response[i].cus;
						$("#cus").val(cus);
						$("#dat2").val(name);
						
					}
				}
				
				
			}); 
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#brana").change(function()
		{
			var data = $('#brana').val();
			var req=$.ajax({
				url:"setAddress.php",
				type: "POST",
				data:{data},
			}); 
			
			req.done(function(msg)
			{
				
                $("#add").val(msg);
				
				
			});
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#cType").change(function()
		{
			var com = $('#cType').val();
			var data=com;
			var req=$.ajax({
				url:"setCommission.php",
				type: "POST",
				dataType: 'JSON',
				data:{data},
				
				
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++)
					{
						var type = response[i].ctype;
						var margin = response[i].margin;
						var type1 = response[i].netA;
						var margin1 = response[i].amountP;
						$("#cType").val(type.toFixed(2));
						$("#margin").val(Math.round(margin));
						$("#net1").val(Math.round(type1));
						$("#payable").val(Math.round(margin1));
					}
				}
				
			});
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#net1").change(function()
		{
			var data = $('#net1').val();
			//var data=com;
			var req=$.ajax({
				url:"setAmount.php",
				type: "POST",
				dataType: 'JSON',
				data:{data},
				
				
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++){
						var margin = response[i].margin;
						var payable = response[i].payable;
						var type1 = response[i].ctype;
						//var margin1 = response[i].amountP;
						$("#margin").val(Math.round(margin));
						//$("#margin").val(margin);
						$("#cType").val(type1.toFixed(2));
						$("#payable").val(Math.round(payable));
					}
				}
				
			});
			
		});
	});
</SCRIPT>
<SCRIPT>
	$(document).ready(function()
	{
		$("#sweight").change(function()
		{
			var weight = $('#weight').val();
			var swaste = $('#sweight').val();
			var Totals = +weight - +swaste;
			$("#reading").val(Totals);
		});
	});
</SCRIPT>
<script>
	$(document).ready(function()
	{
		$("#one").hide();
		$("#two").hide();
		$("#three").hide();
		$("#four").hide();
		$("#type2").change(function()
		{
			var text = $('select#type2').val();
			if(text=="By Cash")
			{
				$("#one").hide();
				$("#four").hide();
				$("#three").hide();
				$("#two").hide();
			}
			else if(text=="By Cheque")
			{
				$("#one").hide();
				$("#four").hide();
				$("#three").show();
				$("#two").hide();
			}
			else if(text=="By Bank Transfer")
			{
				$("#one").show();
				$("#four").hide();
				$("#two").show();
				$("#three").hide();
			}
			else if(text=="To NBFC")
			{
				$("#one").show();
				$("#four").show();
				$("#three").hide();
				$("#two").hide();
			}
			else if(text=="repledge" || text=="recovery" || text=="others")
			{
				$("#one").hide();
				$("#three").hide();
				$("#four").show();
				$("#two").hide();
			}
		});
	});
</script>
<script>
	
    $(function ()
    {
		
        $('#example1').dataTable( {
            "ajax": '',
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            "lengthMenu": [ [10, 25, 50,100,250, -1], [10, 25, 50,100,250, "All"] ],
            buttons: [
			{extend: 'copy',className: 'btn-sm'},
			{extend: 'csv',title: 'ExportReport', className: 'btn-sm'},
			{extend: 'pdf', title: 'ExportReport', className: 'btn-sm'},
			{extend: 'print',className: 'btn-sm'}
            ]
		});
		
        $('#example2').dataTable( {
            "ajax": '',
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            "lengthMenu": [ [10, 25, 50,100,250, -1], [10, 25, 50,100,250, "All"] ],
            buttons: [
			{extend: 'copy',className: 'btn-sm'},
			{extend: 'csv',title: 'ExportReport', className: 'btn-sm'},
			{extend: 'pdf', title: 'ExportReport', className: 'btn-sm'},
			{extend: 'print',className: 'btn-sm'}
            ]
		});
		
		$('#example3').dataTable( {
            "ajax": '',
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            "lengthMenu": [ [10, 25, 50,100,250, -1], [10, 25, 50,100,250, "All"] ],
            buttons: [
			{extend: 'copy',className: 'btn-sm'},
			{extend: 'csv',title: 'ExportReport', className: 'btn-sm'},
			{extend: 'pdf', title: 'ExportReport', className: 'btn-sm'},
			{extend: 'print',className: 'btn-sm'}
            ]
		});
		
        $('#example4').dataTable( {
            "ajax": '',
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            "lengthMenu": [ [10, 25, 50,100,250, -1], [10, 25, 50,100,250, "All"] ],
            buttons: [
			{extend: 'copy',className: 'btn-sm'},
			{extend: 'csv',title: 'ExportReport', className: 'btn-sm'},
			{extend: 'pdf', title: 'ExportReport', className: 'btn-sm'},
			{extend: 'print',className: 'btn-sm'}
            ]
		});				
		$('#example5').dataTable();
		$('#example6').dataTable();
		$('#example7').dataTable();
		$('#example8').dataTable();
		$('#example9').dataTable();
		$('#example10').dataTable();
		$('#example11').dataTable();
	});
	
</script>
<script>
	function openTab(evt, cityName)
	{
		var i, tabcontent, tablinks;
		tabcontent = document.getElementsByClassName("tabcontents");
		for (i = 0; i < tabcontent.length; i++)
		{
			tabcontent[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("tablinks");
		for (i = 0; i < tablinks.length; i++)
		{
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(cityName).style.display = "block";
		evt.currentTarget.className += " active";
	}
	document.getElementById("defaultOpen").click();
</script>
<script type="text/javascript">
	var toggle=document.getElementById('toggle');
	toggle.onclick=function(){
		var multiple=document.getElementsByName('multiple[]');
		for(i=0;i<multiple.length; i ++)
		{
			multiple[i].checked=this.checked;
		}	
	}
</script>	  
<script>
	$(function(){
		
		$('#datepicker').datepicker();
		$("#datepicker").on("changeDate", function(event)
		{
			$("#my_hidden_input").val(
			$("#datepicker").datepicker('getFormattedDate')
			)
		});
		
		$('#datapicker2').datepicker();
		$('.input-group.date').datepicker({ });
		$('.input-daterange').datepicker({ });
	});
    var options = {
		shutter_ogg_url: "jpeg_camera/shutter.ogg",
		shutter_mp3_url: "jpeg_camera/shutter.mp3",
		swf_url: "jpeg_camera/jpeg_camera.swf",
	};
	
    var camera = new JpegCamera("#camera", options);
	var clickCount = 0;
	$('#take_snapshots').click(function()
	{
		clickCount++;
		if (clickCount == 1)
		{
			var snapshot = camera.capture();
			snapshot.show();
			snapshot.upload({api_url: "action.php"}).done(function(response)
			{
				$('#imagelist').prepend("<tr><td><img src='"+response+"' width='80px' height='74px'></td></tr>");
				this.discard();
				
			}).fail(function(response)
			{
				alert("Upload failed with status " + response);
			});
			
		}
		else if (clickCount >= 2)
		{
			var element = $("#imagelist").remove();
			window.location.href="action1.php";
			
		}
		
	});
	
	function done()
	{
		$('#snapshots').html("uploaded");
	}
	function changeText(submitId)
	{
        var submit = document.getElementById(submitId);
        submit.value = 'Recapture Image';
        return false;
	};
</script>
<script>
	$(document).ready(function()
	{
		$("#empid").change(function()
		{
			alert("Verify OTP with Head Office");
			var username=$('#username').val();
			var empid=$('#empid').val();
			var req1=$.ajax(
			{
				url:"loginOtp.php",
				type: "POST",
				data:{username:username,empid:empid},
			});
			req1.done(function(msg)
			{
				window.location.href("addCustomers.php");
			});
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#mobile").change(function()
		{
			var data=$('#mobile').val();
			var name=$('#name').val();
			var req=$.ajax({
				url:"otp.php",
				type: "POST",
				data:{data},								
			}); 
			req.done(function(msg)
			{
				if(msg>0)
				{					
					alert("Continue to Next Page");
					window.location.href='addCustomer.php?phone='+ data +'';					
				}
				else if(msg==0)
				{					
					alert("OTP Sent To Your Mobile");
					var req1=$.ajax({
						url:"ot.php",
						type: "POST",
						data:{data:data,name:name},												
					});
					req1.done(function(msg)
					{
						window.location.href("addCustomers.php");
					});
				}				
			});
		});
	});	
</script>
<script>
	$(document).ready(function()
	{
		$("#otp").change(function()
		{
			var data=$('#otp').val();
			var req=$.ajax({
				url:"otpValid.php",
				type: "POST",
				data:{data},				
			}); 
			req.done(function(msg)
			{
				$("#otp").val(msg);
				if(msg=="OTP Validated")
				{
					$('#otp').attr('readonly','true');
				}
				else if(msg=="Invalid OTP")
				{
					alert(msg);
				}
			});			
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#amobile").change(function()
		{
			var data=$('#amobile').val();
			var name=$('#name').val();
			var req1=$.ajax({
				url:"otp4.php",
				type: "POST",
				data:{data},
				
			}); 
			req1.done(function(msg){
				if(msg>0)
				{
					
					alert("Already Registered");
					window.location.href='addCustomer.php?phone='+ data +'';
					
				}
				else if(msg==0)
				{
					alert("OTP Sent To Your Mobile");
					var req=$.ajax({
						url:"otp1.php",
						type: "POST",
						data:{data:data,name:name},
						
					}); 
					req.done(function(msg)
					{
						
						window.location.href("addCustomers.php");
					});
				}
				
			});
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#otp1").change(function()
		{
			var data=$('#otp1').val();
			var req=$.ajax({
				url:"otpValid1.php",
				type: "POST",
				data:{data},
				
			}); 
			req.done(function(msg)
			{
				$("#otp1").val(msg);
				if(msg=="OTP Validated")
				{
					$('#otp1').attr('readonly','true');
				}
				else if(msg=="Invalid OTP")
				{
					alert(msg);
				}				
			});
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#otp2").change(function()
		{
			var data=$('#otp2').val();
			var req=$.ajax({
				url:"otpValid2.php",
				type: "POST",
				data:{data},
			}); 
			req.done(function(msg)
			{
				$(" 2").val(msg);
				if(msg=="OTP Validated")
				{
					$('#otp2').attr('readonly','true');
					document.getElementById("submitT").disabled =false;
				}
				else if(msg=="Invalid OTP")
				{
					alert(msg);
					document.getElementById("submitT").disabled = true;
				}
				
			});
		});
	});
</script>
<script>
	$(document).ready(function()
	{
		$("#customer").change(function()
		{
			var data=$('#customer').val();
			
			var res=$.ajax({
				type: "POST",
				url: "detailsCustomer.php",
				data:{data},
				dataType: 'JSON',
				success: function(response)
				{
					var len = response.length;
					for(var i=0; i<len; i++)
					{
						var name = response[i].name;
						var mobile = response[i].mobile;
						$("#name").val(name);
						$("#phone").val(mobile);
					}
				}
				
			});
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#phone").change(function(){
			var data=$('#phone').val();
			//alert(data);
			var res=$.ajax({
				type: "POST",
				url: "detailPhone.php",
				data:{data},
				dataType: 'JSON',
				success: function(response){
					var len = response.length;
					for(var i=0; i<len; i++){
						var name = response[i].name;
						var id = response[i].id;
						$("#name").val(name);
						$("#customer").val(id);
					}
				}
				
			});
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#phone").keyup(function(){
			var data=$('#phone').val();
			var res=$.ajax({
				type: "POST",
				url: "detailBill.php",
				data:{data},
			});
			res.done(function(msg){
				$("#bill2").val(msg);
				
			});
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#phone").keyup(function(){
			var data=$('#phone').val();
			var res=$.ajax({
				type: "POST",
				url: "phoneOtp.php",
				data:{data},
			});
			res.done(function(msg){
			});
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#dob").change(function(){
			var data=$('#dob').val();
			var res=$.ajax({
				type: "POST",
				url: "dobCheck.php",
				data:{data},
			});
			res.done(function(msg){
				if(msg<25)
				{
					
					alert('Customer age is less than 25,kindly verify with vigilance!');
					
				}
			});
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#release").hide();
		$("#releases").hide();
		$("#comm").change(function(){
			var data=$('#comm').val();
			if(data=="Release Gold")
			{
				$("#release").show();
				$("#releases").show();
			}
			else if(data=="Physical Gold")
			{
				$("#release").hide();
				$("#releases").hide();
			}
			
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#rel").change(function(){
			var data=$('#rel').val();
			var amount=$('#payable').val();
			var avail=$('#available').val();
			var value=amount-data;
			var vale=avail-amount-data;
			$('#payable').val(value);
			$('#available').val(vale);
		});
	});
</script>
<script>
	$(document).ready(function(){
		$("#paymentType").change(function(){
			var data=$('#gspd').val();
			var dat=$('#paymentType').val();
			var res=$.ajax({
				type: "POST",
				url: "getToday.php",
				data:{data:data,dat:dat},
				
			});
			res.done(function(msg){
				
				$("#ex2").val(msg);
			});
		});
	});
</script>
<script>
	
    $(function () {
		
        /**
			* Flot charts data and options
			*/
			var data1 = [ [0, 55], [1, 48], [2, 40], [3, 36], [4, 40], [5, 60], [6, 50], [7, 51] ];
			var data2 = [ [0, 56], [1, 49], [2, 41], [3, 38], [4, 46], [5, 67], [6, 57], [7, 59] ];
			
			var chartUsersOptions = {
				series: {
					splines: {
						show: true,
						tension: 0.4,
						lineWidth: 1,
						fill: 0.4
					},
				},
				grid: {
					tickColor: "#f0f0f0",
					borderWidth: 1,
					borderColor: 'f0f0f0',
					color: '#6a6c6f'
				},
				colors: [ "#62cb31", "#efefef"],
			};
			
			$.plot($("#flot-line-chart"), [data1, data2], chartUsersOptions);
			
			/**
				* Flot charts 2 data and options
				*/
				var chartIncomeData = [
				{
					label: "line",
					data: [ [1, 10], [2, 26], [3, 16], [4, 36], [5, 32], [6, 51] ]
				}
				];
				
				var chartIncomeOptions = {
					series: {
						lines: {
							show: true,
							lineWidth: 0,
							fill: true,
							fillColor: "#64cc34"
							
						}
					},
					colors: ["#62cb31"],
					grid: {
						show: false
					},
					legend: {
						show: false
					}
				};
				
				$.plot($("#flot-income-chart"), chartIncomeData, chartIncomeOptions);
			});
			
		</script>
		<script>
			if(!window.JpegCamera) {
				alert('Camera access is not available in your browser');
			} 
			else{
				var options = {
					shutter_ogg_url: "jpeg_camera/shutter.ogg",
					shutter_mp3_url: "jpeg_camera/shutter.mp3",
					swf_url: "jpeg_camera/jpeg_camera.swf",
				};
				var cameras = new JpegCamera("#camera", options);
				var clickCount = 0;
				$('#take_snapshot').click(function(){
					clickCount++;
					if (clickCount == 1) {
						var snapshot1 = cameras.capture();
						snapshot1.show();
						snapshot1.upload({api_url: "action3.php"}).done(function(response) {
							$('#imagelist1').prepend("<tr><td><img src='"+response+"' width='80px' height='74px'></td></tr>");
							this.discard();
							
							}).fail(function(response) {
							alert("Upload failed with status " + response);
						});
					}
					else if (clickCount >= 2) {
						var element = $("#imagelist1").remove();
						window.location.href="action2.php";
						
					}
				})
			}
			function done(){
				$('#snapshot1').html("uploaded");
			}
			function changeText(submitId){
				var submit = document.getElementById(submitId);
				submit.value = 'Recapture ';
				return false;
			};
		</script>  
		<script>
			var options = {
				shutter_ogg_url: "jpeg_camera/shutter.ogg",
				shutter_mp3_url: "jpeg_camera/shutter.mp3",
				swf_url: "jpeg_camera/jpeg_camera.swf",
			};
			var camera = new JpegCamera("#camera", options);
			var clickCount = 0;
			$('#take_snap').click(function(){
				clickCount++;
				var data=$('#dat3').val();
				alert(data);
				if (clickCount == 1) {
					var snapshot = camera.capture();
					snapshot.show();
					snapshot.upload({api_url: "act.php"}).done(function(response) {
						$('#imagelist').prepend("<tr><td><img src='"+response+"' width='80px' height='74px'></td></tr>");
						this.discard();
						
						}).fail(function(response) {
						alert("Upload failed with status " + response);
					});
				}
				else if (clickCount >= 2) {
					var element = $("#imagelist").remove();
					window.location.href="action1.php";
				}
			})
		</script>		
	</body>
	</html>			