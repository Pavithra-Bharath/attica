<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
$type = $_SESSION['usertype'];
if ($type == 'VM-HO') {
	include("headervc.php");
	include("menuvc.php");
} else {
	include("logout.php");
}
date_default_timezone_set("Asia/Kolkata");
$date = date('Y-m-d');
$empId = $_SESSION['employeeId'];
$emr = mysqli_fetch_array(mysqli_query($con, "Select name from employee WHERE empId='$_SESSION[employeeId]'"));

if (isset($_POST['change'])) {
	$Password = $_POST['password'];
	$sql = "UPDATE users SET password='$Password' WHERE employeeId='$empId'";
	if (mysqli_query($con, $sql)) {
		echo "<script type='text/javascript'>alert('YOUR PASSWORD HAS BEEN CHANGED')</script>";
	} else {
		echo "<script type='text/javascript'>alert('SOMETHING WENT WRONG,PLEASE TRY AGAIN.')</script>";
	}
}

if (isset($_POST['editEveryCustomer'])) {
	if (isset($_POST['ecid']) && $_POST['ecid'] != '') {
		$id = $_POST['ecid'];
		$branchId = $_POST['branchId'];
		$status = $_POST['ecStatus'];
		$sql = "UPDATE everycustomer SET status='$status' WHERE Id='$id'";
		if (mysqli_query($con, $sql)) {
			echo header("location:zbmhoHome1.php");
		} else {
			echo "<script>alert('Error Occurred')</script>";
			echo header("location:zbmhoHome1.php");
		}
	}
}

if (isset($_POST['cusname']) && isset($_POST['cusmob']) && isset($_POST['branchID'])) {
//if (isset($_POST['submitNC32'])) {
    
	$cName=trim($_POST['cusname']);	
	$cusname = strtoupper($cName);
	$mob = $_POST['cusmob'];
	$type = '';
	$branchID = $_POST['branchID'];
	$time = date("h:i:s");
	
	/* ======================== Check whether the customer has billed in less than 20days ======================= */
	$yesterday = date('Y-m-d', strtotime($date.' -1 day'));
	$start_date = date('Y-m-d', strtotime($yesterday.' -20 day'));
	$billCount = mysqli_num_rows(mysqli_query($con,"SELECT phone FROM trans WHERE phone='$mob' AND date BETWEEN '$start_date' AND '$yesterday' and status='Approved'"));
	if($billCount>0){
		$status = "Blocked";  // block the customer from billing 
		$remark ="This customer has billed recently in less than 20days";
	}
	else{

		$custQuery = mysqli_query($con,"SELECT mobile FROM `customer` where rcontact='$mob'");
		$cRow = mysqli_fetch_assoc($custQuery);			
		if(isset($cRow["mobile"])){
			$additionalContactNo=$cRow["mobile"];
			$cbillCount = mysqli_num_rows(mysqli_query($con,"SELECT phone FROM trans WHERE phone='$additionalContactNo' AND date BETWEEN '$start_date' AND '$yesterday' and status='Approved'"));
			if($cbillCount>0){
				$status = "Blocked";  // block the customer from billing 
				$remark ="This customer has billed recently with different number ($additionalContactNo) in less than 20days";
			}
			else{
				$status = 0;
				$remark ="";
			}
		}else{
			$status = 0;
			$remark ="";
		}		

	}
	//$status = 0;
	//$remark ="";
	$idnumber = "";
	$fName1 = '';
	$inscon = "INSERT INTO everycustomer(customer,contact,type,idnumber,branch,image,date,time,status,remark) VALUES ('$cusname','$mob','$type','$idnumber','$branchID','$fName1','$date','$time','$status','$remark')";
	if (mysqli_query($con, $inscon)) {
		echo "<script>setTimeout(\"location.href = 'zbmhoHome1.php';\",150);</script>";
	} else {
		echo "<script type='text/javascript'>alert('Error Storing Data!')</script>";
		echo "<script>setTimeout(\"location.href = 'zbmhoHome1.php';\",150);</script>";
	}
}


$vmBranchList = mysqli_fetch_assoc(mysqli_query($con, "SELECT agentId,branch FROM vmagent WHERE agentId='$empId'"));
$branches = explode(",", $vmBranchList['branch']);

$query = mysqli_fetch_assoc(mysqli_query($con, "SELECT count(*) AS totalWalkin FROM everycustomer WHERE date='$date' AND branch IN ('$branches[0]','$branches[1]','$branches[2]','$branches[3]','$branches[4]') AND branch!=''"));
$count = $query['totalWalkin'];

$query1 = mysqli_fetch_assoc(mysqli_query($con, "SELECT count(*) AS billed FROM trans WHERE date='$date' AND branchId IN ('$branches[0]','$branches[1]','$branches[2]','$branches[3]','$branches[4]') AND status='Approved' AND branchId!=''"));
$count11 = $query1['billed'];
?>
<!--  MODAL - PASSWORD CHANGE   -->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-sm">
		<div class="modal-content ">
			<div class="color-line"></div>
			<span class="fa fa-close modaldesign" data-dismiss="modal"></span>
			<div class="modal-header" style="background-color: #123C69;color: #f0f8ff;">
				<h4>Hi , <?php echo $emr['name']; ?></h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-7">
						<h5>Change Your Password :</h5>
						<form action="" method="POST">
							<input style="font-weight:500; width:250px; margin-bottom:10px;margin-top:20px" type="text" class="form-control" name="password" value="" placeholder="DON'T USE PERSONAL PASSWORD" required>
							<button style="margin-top:20px" class="btn btn-success" name="change">Change</button>
						</form>
					</div>
					<div class="col-sm-5">
						<img src="images/atticalogo.png" alt="Atticagold" width="250" height="100">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<link rel="stylesheet" href="styles/vm-style.css" />

<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<div class="form-group row">
						<div class="col-xs-6">
							<h3 class="text-success">Hi <span style="color:#FF6347"><b><?php echo $emr['name']; ?></b></span></h3>
						</div>
						<div class="col-xs-3">
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-user-plus"></span></span>
								<input style="text-align:center;font-weight:bold;color:#900" type="text" readonly class="form-control" value="TOTAL WALKIN : <?php echo $count; ?>">
							</div>
						</div>
						<div class="col-xs-3">
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-check-circle-o"></span></span>
								<input style="text-align:center;font-weight:bold;color:#900" type="text" readonly class="form-control" value="TOTAL SOLD : <?php echo $count11; ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-4">
						<div class="panel-body">
							<div class="panel-heading">
								<h3 class="text-success">Add New Customer</h3>
								<form id="add-new-customer" method="POST" class="form-horizontal" action="" onsubmit="submitNC32.disabled = true; return true;">
									<div class="form-group">
										<div class="col-sm-12" style="margin-top:10px;">
											<label class="text-success">Select Branch</label>
											<div class="input-group">
												<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
												<select class="form-control" name="branchID" required>
													<option selected="true" disabled="disabled" value="">Select Branch</option>
													<?php
													foreach ($branches as $branch_id2) {
														$branchData2 = mysqli_fetch_assoc(mysqli_query($con, "SELECT branchId,branchName FROM branch WHERE branchId='$branch_id2'"));
														echo '<option  value="' . $branchData2['branchId'] . '">' . $branchData2['branchName'] . '</option>';
													}
													?>
												</select>
											</div>
										</div>
										<div class="col-sm-12" style="margin-top:10px;">
											<label class="text-success">Customer Name</label>
											<div class="input-group">
												<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
												<input type="text" name="cusname" placeholder="Customer Name" required id="name" class="form-control" autocomplete="off">
											</div>
										</div>
										<div class="col-sm-12" style="margin-top:10px;">
											<label class="text-success">Contact Number<b style="color:#f00">*</b></label>
											<div class="input-group">
												<span class="input-group-addon"><span class="fa_Icon fa fa-phone-square"></span></span>
												<input type="text" name="cusmob" style="padding:0px 5px" id="mobile" placeholder="Contact Number" maxlength="10" class="form-control" value="<?php echo $custDetails['mobile']; ?>">
											</div>
										</div>
										<div class="row">
											<div class="col-sm-5" style="margin-top:10px;">
												<a onClick="generateOTP()" id="btn" class="btn btn-success"><i class="fa_icon fa fa-paper-plane"></i> Send OTP</a>
											</div>
											<div class="col-sm-1" style="margin-top:10px;">
											</div>
											<div class="col-sm-6" style="margin-top:10px;">
												<div class="input-group">
													<input type="text" placeholder="OTP" class="form-control" maxlength="6" required name="otp" id="xotp">
												</div>
											</div>
										</div>
										<div class="col-sm-12" style="margin-top:22px;">
											<button class="btn btn-success btn-block" id="updateCustomer" name="submitNC32" type="submit"><span style="color:#ffcf40" class="fa fa-save"></span> SUBMIT</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-sm-8">
						<div class="panel-body">
							<div class="panel-heading">
								<h3 class="text-success">Pending Customer</h3>
							</div>
							<div class="table-responsive">
								<table class="table table-striped table-bordered">
									<thead>
										<tr class="theadRow">
											<th>Branch Name</th>
											<th>Customer_Name</th>
											<th>Mobile</th>
											<!--<th>Update</th>-->
											<!--<th>Submit</th>-->
										</tr>
									</thead>
									<tbody>
										<?php
										$query = mysqli_query($con, "SELECT e.status,e.Id,e.customer,e.contact,b.branchName
									FROM everycustomer e,branch b
									WHERE e.status='0' AND e.branch=b.branchId AND e.branch!='' AND e.branch IN ('$branches[0]','$branches[1]','$branches[2]','$branches[3]','$branches[4]') AND e.date='$date'");
										while ($row = mysqli_fetch_assoc($query)) {
											echo "<tr>";
											echo "<td>" . $row['branchName'] . "</td>";
											echo "<td>" . $row['customer'] . "</td>";
											echo "<td>" . $row['contact'] . "</td>";
								// 			echo "<form method='POST' action=''>";
								// 	<input type='hidden' name='ecid' value=" . $row['Id'] . ">
							 //       <input type='hidden' name='branchId' value=" . $row['branch'] . ">";
								// 			echo "<td><div class='form-group'>
								// 		<select class='form-control m-b' name='ecStatus'>
								// 		<option selected='true' disabled='disabled' value=''>SELECT</option>
									
								// 		<option value='Double Entry'>Double Entry</option>
								// 		<option value='Wrong Entry'>Wrong Entry</option>
								// 		</select>
								// 		</div></td>";
								// 			echo "<td style='text-align:center'><button onClick=\"javascript: return confirm('Please confirm Again');\" class='btn btn-lg' name='editEveryCustomer' type='submit'><i class='fa fa-pencil-square-o text-success' style='font-size:16px'></i></button></td>";
											echo "</tr>";
											$i++;
										}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-body" style="margin-top:25px">
					<div class="panel-heading">
						<h3 class="text-success">ASSIGNED BRANCHES</h3>
					</div>
					<div class="table-responsive">
						<table class="table table-striped table-bordered">
							<thead>
								<tr class="theadRow">
									<th>Branch Name </th>
									<th>Branch ID</th>
									<th>BM Name</th>
									<th>contact</th>
									<th>Access</th>
									<th>Audio</th>

								</tr>
							</thead>
							<tbody>
								<?php
								foreach ($branches as $branch_id) {
									$branchData = mysqli_fetch_assoc(mysqli_query($con, "SELECT A.branch,B.branchName,A.name,A.contact FROM
										(SELECT u.branch,e.name,e.contact
										FROM users u,employee e
										WHERE u.branch='$branch_id' AND u.employeeId=e.empId) A 
										JOIN
										(SELECT branchId,branchName FROM branch) B 
										ON A.branch=B.branchId
										LIMIT 1"));
									echo "<tr>";
									echo "<td>" . $branchData['branchName'] . "</td>";
									echo "<td>" . $branchData['branch'] . "</td>";
									echo "<td>" . $branchData['name'] . "</td>";
									echo "<td>" . $branchData['contact'] . "</td>";
									echo "<td class='col-sm-1'><button class='btn btn-success'><a class='text-white' href='xeveryCustomer1.php?mn=" . base64_encode($branchData['branch']) . "'>Access</a></button></td>";
									echo "<td class='col-sm-1'><button class='btn btn-success'><a class='text-white' target='Blank' href='msvideo.php?mn=" . base64_encode($branchData['branch']) . "'>Audio</a></button></td>";
									echo "</tr>";
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<button type="button" class="btn btn-success" style="float:right;margin-bottom:20px" data-toggle="modal" data-target=".bd-example-modal-sm">RESET PASSWORD</button>
		</div>

		<div style="clear:both"></div>
	</div>
	<script>
		// document.getElementById("idOfButton").onclick = function() {
		// 	//disable
		// 	this.disabled = true;

		// 	//do some validation stuff
		// }

		function generateOTP() {
			var data = $('#mobile').val();
			var name = $('#name').val();
			console.log(data);
			console.log(name);
			var req1 = $.ajax({
				url: "../ot.php",
				type: "POST",
				data: {
					data: data,
					name: name
				},
			});
			req1.done(function(msg) {
				alert("OTP is sent to customer's mobile");
				$('#btn').attr("disabled", true);
			});
		}
		$(document).ready(function() {
			$('#updateCustomer').attr("disabled", true);
			$("#xotp").keyup(function() {
				var data = $('#xotp').val();
				var count = data.toString().length;
				if(count==6){
					 var req = $.ajax({
						url: "../otpValid.php",
						type: "POST",
						data: {
							data
						},
					});
					req.done(function(msg) {
						$("#xotp").val(msg);
						if (msg == "OTP Validated") {
							$('#xotp').attr('readonly', 'true');
							$('#updateCustomer').attr("disabled", false);
						} else if (msg == "Invalid OTP") {
							alert(msg);
						}
					});				
				}
			});
		});
	</script>
	<?php include("footer.php"); ?>


	<script src="../AGPL-otp.js"></script>