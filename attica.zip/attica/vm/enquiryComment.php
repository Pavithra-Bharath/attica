<?php
	session_start();
	$type=$_SESSION['usertype'];
	/* if($type=='VM-HO'){
        include("headervc.php");
		include("menuvc.php");
	}
	else{
	    include("logout.php");
	} */
	include("logout.php");
	include("dbConnection.php");
	$date = date("Y-m-d");
	
	if(isset($_GET['mobile']) && isset($_GET['id'])){
		$enquiryData = mysqli_fetch_assoc(mysqli_query($con,"SELECT w.id,w.name,w.mobile,w.gold,w.gwt,w.ramt,w.comment,w.remarks,b.branchName FROM walkin w,branch b WHERE w.id=".$_GET['id']." AND w.branchId=b.branchId"));
	}
	
	if(isset($_GET['submitSave'])){
		$walkinId = $_GET['walkinId'];
		$comment = $_GET['comment'];
		$issue = $_GET['remarks'];
		
		if($issue == 'Coming Tomorrow'){
			$next_date = date('Y-m-d',strtotime("+1 days"));
			$sql = "UPDATE walkin SET comment='$comment',status=1,issue='$issue',date='$next_date' WHERE id='$walkinId'";
		}
		else{
			$sql = "UPDATE walkin SET comment='$comment',status=1,issue='$issue' WHERE id='$walkinId'";
		}
		
		if(mysqli_query($con,$sql)){
			echo "<script>alert('ENQUIRY DONE'); window.location.href='zenquiryvm.php';</script>";
		}
		else{
			echo "<script>alert('ERROR ADDING COMMENT!!!. RESUBMIT PROPERLY AGAIN'); window.location.href='zenquiryvm.php';</script>";
		}
	}	
?>
<link rel="stylesheet" href="styles/vm-style.css"/>
<div id="wrapper">
	<div class="row content">
		<div class="col-lg-12">
			<div class="hpanel">
				<div class="panel-heading">
					<h3 class="text-primary"><i class="fa_Icon fa fa-user"></i> Customer Enquiry </h3>
				</div>
				<div class="panel-body" style="border: 5px solid #fff;border-radius: 10px;padding: 20px;box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;background-color: #F5F5F5;">
					<div class="col-sm-4">
						<label class="text-success">NAME</label>
						<div class="input-group">
							<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
							<input type="text" class="form-control" readonly value="<?php echo $enquiryData['name']; ?>">
						</div> 
					</div>
					<div class="col-sm-4">
						<label class="text-success">Branch</label>
						<div class="input-group">
							<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
							<input type="text" class="form-control" readonly value="<?php echo $enquiryData['branchName']; ?>">
						</div> 
					</div>
					<div class="col-sm-4">
						<label class="text-success">Contact</label><br>
						<div class="input-group">
							<input type="text"  class="form-control" id="myInput" readonly value="<?php echo $enquiryData['mobile']; ?>">
							<button onclick="myFunction()" style="margin-top:-33px" class="form-control btn btn-success btn-block"><span class="fa fa-phone"></span> Copy Number</button>
							<script>
								function myFunction() {
									var copyText = document.getElementById("myInput");
									copyText.select();
									copyText.setSelectionRange(0, 99999)
									document.execCommand("copy");
								}
							</script>
						</div>
					</div>
					<label class="col-sm-12"><br></label>
					<form method="GET" action="">
						<input type="hidden" name="walkinId" value= <?php echo $enquiryData['id']; ?>>
						<input type="hidden" name="mobile" value= <?php echo $enquiryData['mobile']; ?>>
						<div class="col-sm-4">
							<label class="text-success">Type</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
								<input type="text" class="form-control" readonly value="<?php echo $enquiryData['gold']; ?>">
							</div>
						</div>
						<div class="col-sm-4">
							<label class="text-success">Gross Weight</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
								<input type="text" class="form-control" readonly value="<?php echo $enquiryData['gwt']; ?>">
							</div>
						</div>
						<div class="col-sm-4">
							<label class="text-success">Release Amount</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-user"></span></span>
								<input type="text" class="form-control" readonly value="<?php echo $enquiryData['ramt']; ?>">
							</div>
						</div>
						<label class="col-sm-12"><br></label>
						<div class="col-sm-6">
							<label class="text-success">Comment</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-edit"></span></span>
								<textarea name="comment" required autocomplete="off" class="form-control" rows="4" cols="50"><?php echo $enquiryData['comment']; ?></textarea>
							</div>
						</div>
						<div class="col-sm-6">
							<label class="text-success">Branch Remarks</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-edit"></span></span>
								<textarea autocomplete="off" class="form-control" readonly rows="4" cols="50"><?php echo $enquiryData['remarks']; ?></textarea>
							</div>
						</div>
						<label class="col-sm-12"><br></label>
						<?php if($enquiryData['issue'] == 'Coming Today' || $enquiryData['issue'] == 'Coming Tomorrow'){ ?>
							<div class="col-sm-1">
								<label><br></label><br>
								<div class="checkbox checkbox-danger">
									<input id="checkbox6" type="checkbox" required>
									<label for="checkbox6">Spoken</label>
								</div>
							</div>
						<?php } ?>
						<div class="col-sm-3">
							<label class="text-success">REMARKS</label>
							<div class="input-group">
								<span class="input-group-addon"><span style="color:#990000" class="fa fa-phone"></span></span>
								<select required class="form-control" name="remarks" id="remarks" required>
									<option selected="true" disabled="disabled" value="">Select Remarks</option>
									<option value="Coming Today">Coming Today</option>
									<option value="Coming Tomorrow">Coming Tomorrow</option>
									<option value="Sold in Attica">Sold in Attica</option>
									<option value="Sold Outside">Sold Outside</option>
									<option value="Planning to Visit">Planning To Visit</option>
									<option value="Not Feasible">Not Feasible</option>
									<option value="Not Interested">Not Interested / Price Issue</option>
									<option value="RNR">RNR</option>
									<option value="Just Enquiry">Just Enquiry</option>
									<option value="Wrong Number">Wrong Number</option>
									<option value="Pending">Pending</option>
								</select>
							</div>
						</div>
						<div class="col-sm-2">
							<button class="btn btn-primary btn-block" name="submitSave" type="submit" style="margin-top:23px"> 
								<span style="color:#ffcf40" class="fa fa-check"></span> Submit Status
							</button>
						</div>
						<?php if($enquiryData['issue'] == 'Coming Today' || $enquiryData['issue'] == 'Coming Tomorrow'){ ?>
							<div class="col-sm-2">
								<button class="btn btn-danger2 btn-block" name="submitSave" type="submit" style="margin-top:23px">
									<span style="color:#ffcf40" class="fa fa-arrow-circle-o-left"></span> Send Back More Info
								</button>
							</div>
						<?php } ?>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div style="clear:both"></div>
<?php include("footer.php"); ?>