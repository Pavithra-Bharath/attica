<aside id="menu" style="overflow:scroll;overflow-x:hidden">
	<div id="sidebar-collapse">
		<ul class="nav" id="side-menu">
			<li><a href="zbmhoHome1.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-in"></i> Access Branch</span></a></li>
			<li><a href="BMinfo.php"><span class="nav-label"><i style="color:#990000" class="fa fa-user-circle-o"></i> BMs Info</span></a></li>
			<li><a href="zbilllStatus.php"><span class="nav-label"><i style="color:#990000" class="fa fa-id-card-o"></i> Bills</span></a></li>
			<li><a href="zrelseasestatus.php"><span class="nav-label"><i style="color:#990000" class="fa fa-envelope-open-o"></i> Release</span></a></li>			
			<li><a href="xviewExpense.php"><span class="nav-label"><i style="color:#990000" class="fa fa-money"></i> Expense</span></a></li>
			<li><a href="zenquiryvm.php"><span class="nav-label"><i style="color:#990000" class="fa fa-comments-o"></i> Enquiry</span></a></li>
			<li><a href="vmIssue.php"><span class="nav-label"><i style="color:#990000" class="fa fa-ticket"></i> VM Issues</span></a></li>
			<!--<li><a href="vmLoginOTP.php"><span class="nav-label"><i style="color:#990000" class="fa fa-send-o"></i> OTP</span></a></li>-->
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> Logout</span></a></li>
		</ul>
	</div>
</aside>