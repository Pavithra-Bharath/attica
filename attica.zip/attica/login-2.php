<?php

    header("Location: https://www.atticagold.biz/login.php");
    exit();

?>