<?php
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	$type = $_SESSION['usertype'];
	if($type=='Software'){
		include("header.php");
		include("menuSoftware.php");
	}
	else{
		include("logout.php");
	}
?>
<style>
	#wrapper h3{
	text-transform:uppercase;
	font-weight:600;
	font-size: 20px;
	color:#123C69;
	}
	.hpanel .panel-body {
	background-color: #f5f5f5;
	box-shadow: 10px 15px 15px #999;
	border-radius: 3px;
	padding: 15px;
	}
	.text-success{
	color:#123C69;
	text-transform:uppercase;
	font-weight:bold;
	font-size: 12px;
	}
	.btn-primary{
	background-color:#123C69;
	}
	.theadRow {
	text-transform:uppercase;
	background-color:#123C69!important;
	color: #f2f2f2;
	font-size:11px;
	}
	.btn-success{
	display:inline-block;
	padding:0.7em 1.4em;
	margin:0 0.3em 0.3em 0;
	border-radius:0.15em;
	box-sizing: border-box;
	text-decoration:none;
	font-size: 11px;
	font-family:'Roboto',sans-serif;
	text-transform:uppercase;
	color:#fffafa;
	background-color:#123C69;
	box-shadow:inset 0 -0.6em 0 -0.35em rgba(0,0,0,0.17);
	text-align:center;
	position:relative;
	}
	.fa_Icon {
	color:#990000;
	}
	.fa-reject{
	color: #123C69;
	font-size: 20px;
	}
	.fa-delete{
	color: #990000;
	font-size: 20px;
	}
</style>
<div id="wrapper">
	<div class="row content">
	
		<div class="col-lg-6">
			<div class="hpanel">
				<div class="panel-heading hbuilt">
					<div class="panel-tools">
						<a class="showhide"><i class="fa fa-chevron-up"></i></a>
						<a class="closebox"><i class="fa fa-times"></i></a>
					</div>
					Download trans Table
				</div>
				<div class="panel-body text-center">
					<div class="text-center m-b-md">
						<h3>Trans</h3>						
					</div>
					<form method="POST" action="downloadSQL.php">
						<div class="input-group">
							<input type="date" class="form-control" name="from" required>
							<span class="input-group-addon">to</span>
							<input type="date" class="form-control" name="to" required>
						</div>
						<button type="submit" name="transDownload" class="form-control btn-success btn" style="margin-top: 20px; width: 150px;"><span class="fa fa-download"></span> Download</button>
					</form>
				</div>
			</div>
		</div>
		
		<div class="col-lg-6">
			<div class="hpanel">
				<div class="panel-heading hbuilt">
					<div class="panel-tools">
						<a class="showhide"><i class="fa fa-chevron-up"></i></a>
						<a class="closebox"><i class="fa fa-times"></i></a>
					</div>
					Download walkin Table
				</div>
				<div class="panel-body text-center">
					<div class="text-center m-b-md">
						<h3>Walkin</h3>						
					</div>
					<form method="POST" action="downloadSQL.php">
						<div class="input-group">
							<input type="date" class="form-control" name="from" required>
							<span class="input-group-addon">to</span>
							<input type="date" class="form-control" name="to" required>
						</div>
						<button type="submit" name="walkinDownload" class="form-control btn-success btn" style="margin-top: 20px; width: 150px;"><span class="fa fa-download"></span> Download</button>
					</form>
				</div>
			</div>
		</div>
		
	</div>
<?php include("footer.php"); ?>