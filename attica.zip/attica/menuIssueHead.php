<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">        
			<li><a href="issues.php"><span class="nav-label"><span style="color:#990000;width:20px;" class="fa fa-clipboard"></span> Enquiry</span></a></li>	
			<li><a href="allCustomerReport.php"><span class="nav-label"><span style="color:#990000;width:20px;" class="fa fa-hourglass-half"></span> Waiting</span></a></li>
			<li><a href="logout.php"><span class="nav-label"><span style="color:#990000;width:20px;" class="fa fa-sign-out"></span> Logout</span></a></li>
        </ul>
    </div>
</aside>