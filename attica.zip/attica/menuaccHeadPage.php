<aside id="menu" style="overflow:scroll;overflow-x:hidden">
    <div id="sidebar-collapse">
        <ul class="nav" id="side-menu">
            <li class="active"><a href="acHdDashboard.php"><span class="nav-label"><i style="color:#990000" class="fa fa-dashboard"></i> Dashboard</span></a></li>
            <li><a href="viewGoldRate.php"><span class="nav-label"><i style="color:#990000" class="fa fa-calendar"></i> Today's Rate</span></a></li>
            <li><a href="addCustomerZonal.php"><i style="color:#990000" class="fa fa-user-plus"></i> Add Customer</a></li>
			<li><a href="inbox.php"><span class="nav-label"><i style="color:#990000" class="fa fa-envelope"></i> MailBox</span></a></li>
			<li><a href="zonal.php"><span class="nav-label"><i style="color:#990000" class="fa fa-lock"></i> Authorize Access</span></a></li>
				<li><a href="issues.php"><span class="nav-label"><i style="color:#990000" class="fa fa-users"></i> Walk-Ins</span></a></li>	
			<li><a href="viewbill.php"><span class="nav-label"><i style="color:#990000" class="fa fa-pencil-square"></i> Today's Bills</span></a></li>
			<li><a href="expenseApproval.php"><span class="nav-label"><i style="color:#990000" class="fa fa-edit"></i> Expense</span></a></li>
			<li><a href="goldBuyerInfo.php"><span class="nav-label"><i style="color:#990000; width:20px" class="fa fa-share-alt"></i> Account</span></a></li>
			<li><a href="#"><span class="nav-label"><b><i style="color:#990000" class="fa fa-rupee"></i> Funds</b></span><b><span class="fa arrow"></span></b></a>
				<ul class="nav nav-second-level">
					<li><a href="approveFund.php">Approve Funds </a></li>
					<li><a href="approveTFund.php">Approve Transfers </a></li>
				</ul>
			</li>
			<li><a><span class="nav-label"><b><i style="color:#990000" class="fa fa-file-text"></i> Reports</b></span><b><span class="fa arrow"></span></b></a>
				<ul class="nav nav-second-level">
					<li><a href="dailyClosingR.php">Branch Report</a></li>
					<li><a href="transactionReports.php">Transaction Reports </a></li>
					<li><a href="ReleaseReports.php">Release Reports </a></li>
					<li><a href="SendingReport.php">Sending Report</a></li>
					<li><a href="fundReports.php">Funds Reports</a></li>
					<li><a href="dailyReports.php">Daily Closing</a></li>
					<li><a href="dailyExpense.php">Daily Expense</a></li>
					<li><a href="melting.php">Melting Report</a></li>
					<li><a href="viewBranch.php">Branch Details</a></li>
				</ul>
			</li>
			<li><a href="logout.php"><span class="nav-label"><i style="color:#990000" class="fa fa-sign-out"></i> Logout</span></a></li>
		</ul>
	</div>
</aside>