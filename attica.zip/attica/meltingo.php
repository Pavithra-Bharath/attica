<?php
session_start();
if($type=='Branch')
{
    include("logout.php");
}
else
{
include("headersir.php");
include("dbConnection.php");
}
$date=date('Y-m-d');
	   ?>
<div id="wrapper">
<div class="content">
                <div class="hpanel"><b><h4 align="right" class="font-extra-bold no-margins text-success"><i style="color:#990000" class="fa fa-clock-o"></i> Melting Date: <?php echo $date;?></b></h4>
                <div class="panel-body" style="box-shadow:10px 15px 15px #999;">
                	<div class="col-lg-12">
                    <div class="form-group">
				<form id="frm1" action=""  method="GET" onSubmit="return validate();">
                <table id="example2" class="table table-striped table-bordered table-hover">
                <thead>
                <tr class="text-success">
                    <th>SNo</th>
					<th>Branch</th>
					<th>Branch Net Wt</th>
					<th>After Stone</th>
					<th>Difference</th>
					<th>Gatti Weight</th>
					<th>Melting Loss</th>
					<th>Branch Purity</th>
					<th>Melting Purity</th>
					<th>Purity Loss</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    $query=mysqli_query($con,"SELECT * FROM melting where date = '$date'");
					$count=mysqli_num_rows($query);
					for($i=1;$i<=$count;$i++)
                    {
                        if($count>0)
                        {
                            $row=mysqli_fetch_array($query);
                            $branch=$row['branch'];
                            $sql="select branchName from branch where branchId='$branch'";
                            $res=mysqli_query($con,$sql);
                            $row1=mysqli_fetch_array($res);
                            $empid=$row['empid'];
                            $sql1="select name from employee where empId='$empid'";
                            $res1=mysqli_query($con,$sql1);
                            $row2=mysqli_fetch_array($res1);
                            echo "<tr><td>" . $i .  "</td>";
						    echo "<td>" . $row1['branchName'] . "</td>";
							echo "<td>" . $row['branchnetwt'] ."</td>";
							echo "<td>" . $row['afterstone'] ."</td>";
							if($row['difference'] < 0)
                            {
							    echo "<td style='color:#f00;font-weight:bold;'>" . $row['difference'] ."</td>";
                            }
                            else
                            {
                                echo "<td>" . $row['difference'] ."</td>";
                            }
							echo "<td>" . $row['gattiwt'] ."</td>";
							if($row['meltingwt'] < 0)
                            {
							    echo "<td style='color:#f00;font-weight:bold;'>" . $row['meltingwt'] ."</td>";
                            }
                            else
                            {
                                echo "<td>" . $row['meltingwt'] ."</td>";
                            }
							echo "<td>" . $row['branchpurity'] ."</td>";
							echo "<td>" . $row['afterpurity'] ."</td>";
							if($row['purityloss'] < 0)
                            {
							    echo "<td style='color:#f00;font-weight:bold;'>" . $row['purityloss'] ."</td></tr>";
                            }
                            else
                            {
                                echo "<td>" . $row['purityloss'] ."</td></tr>";
                            }
						}
					}
				?>
				</tbody>				
			</table>
		</form>
	</div>
</div>
      </div>  
	<?php include("footer.php");?>
	<div style="clear:both"></div>
</div>